# Basic Electricity Tutor - Interactive Web Application

## Project Overview

This project aims to create an interactive web application for teaching basic electricity concepts based on existing educational content in "Basic_Electricity_Tutor_Content.md". The application features:

1. A split-screen layout with educational content on the left and an AI chatbot on the right
2. Highly interactive, visual demonstrations of electrical concepts
3. Integrated AI tutor that can answer questions about the content
4. Modern, responsive design with excellent user experience

## Technical Architecture

### Frontend Framework
- **Next.js (v14+)**: Core framework for the application
- **React (v18+)**: Component library
- **TypeScript**: For type safety and improved developer experience

### UI/UX Design
- **Tailwind CSS**: For styling with a custom color palette focused on electrical themes
- **Shadcn UI** or **Material UI**: For consistent component design
- **Responsive design**: Must work on desktop and tablets

### Design & Accessibility Requirements
- **Typography**: LEXEND font as default for improved reading proficiency
- **Accessibility Features**: Font size selection, dyslexia-friendly fonts, high contrast mode
- **Progress Tracking**: Visual progress indicators, achievement system, completion tracking
- **Design Inspiration**: Based on https://linux.emmi.zone with modern dark theme
- **WCAG 2.1 AA+ Compliance**: Full accessibility compliance with automated testing
- **Visual Learning**: Highly interactive visualizations with gamification elements
- See `DESIGN_ACCESSIBILITY_REQUIREMENTS.md` for complete specifications

### Interactive Visualizations
1. **D3.js**: For data visualizations (charts, graphs)
2. **Three.js**: For 3D visualizations (atomic structures, electromagnetic fields)
3. **CircuitJS** or **EasyEDA API**: For interactive circuit simulations
4. **Custom SVG animations**: For demonstrating current flow, electrical fields, etc.

### AI Chatbot Integration
1. **OpenAI API** (GPT-4 or newer) or **Anthropic's Claude API**
2. **Custom system prompt**: Must incorporate electrical engineering expertise
3. **Context-awareness**: AI should understand what section the user is viewing
4. **Session management**: For chat history
5. **Retrieval-augmented generation**: For accurate electrical information

### Content Management
1. Parse Markdown content into structured JSON
2. Implement dynamic navigation based on content headers
3. Include search functionality across all content
4. Store user progress and allow bookmarking

## Project Structure

```
/
├── .windsurf/             # Windsurf IDE configuration
├── public/                # Static assets
├── src/
│   ├── app/               # Next.js app directory
│   ├── components/        # Reusable UI components
│   │   ├── layout/        # Layout components
│   │   ├── ui/            # Basic UI components
│   │   ├── visualizations/ # Interactive visualization components
│   │   └── ai/            # AI chat components
│   ├── lib/               # Utility functions and libraries
│   ├── data/              # Parsed content and data structures
│   ├── styles/            # Global styles
│   └── types/             # TypeScript type definitions
└── content/               # Source content files
    └── Basic_Electricity_Tutor_Content.md  # Original content
```

## Implementation Phases

### Phase 1: Setup & Content Structuring
1. Initialize Next.js project with TypeScript
2. Set up the basic split-screen layout
3. Parse Markdown content into structured format
4. Implement basic navigation and content display

### Phase 2: Visualization Components
1. Develop core visualization components for:
   - Circuit diagrams
   - Atomic structures
   - Current flow animations
   - Interactive measurement tools
   - Component behavior models
   - Waveform displays

2. Create interactive elements for each section based on visual aid instructions

### Phase 3: AI Chatbot Integration
1. Set up API connections to chosen AI provider
2. Design and test specialized system prompts
3. Implement chat interface with proper context passing
4. Add session management and history

### Phase 4: Integration & Refinement
1. Connect content with appropriate visualizations
2. Ensure the AI chatbot can reference and explain visualizations
3. Implement user progress tracking
4. Add final polish to UI/UX
5. Optimize for performance

## Key Features

1. **Interactive Circuit Builder**:
   - Drag-and-drop interface for building circuits
   - Real-time simulation with adjustable parameters
   - Measurement tools (virtual multimeter, oscilloscope)

2. **Concept Visualizations**:
   - Animated electron flow in conductors
   - Interactive Ohm's Law triangle
   - 3D visualizations of electromagnetic fields
   - Power triangle with adjustable parameters

3. **Learning Tools**:
   - Interactive quizzes after each section
   - Practice problems with step-by-step solutions
   - "Explain this" button that prompts the AI to explain complex concepts
   - Virtual lab experiments with guided instructions

4. **AI Chatbot Features**:
   - Question answering about electrical concepts
   - Circuit analysis assistance
   - Step-by-step problem solving
   - Personalized learning suggestions
   - Ability to reference specific visualizations

## Development Guidelines

### Code Style
- Use consistent naming conventions (camelCase for variables, PascalCase for components)
- Follow ESLint and Prettier configurations
- Write self-documenting code with meaningful variable and function names
- Comment complex logic and algorithms

### Component Structure
- Each visualization should be a self-contained component
- Use React hooks for state management
- Implement proper error handling and loading states

### AI Integration
- Keep API keys secure using environment variables
- Implement rate limiting and error handling for API calls
- Create a well-structured system prompt that captures electrical domain knowledge

### Testing
- Write unit tests for components using Jest and React Testing Library
- Implement end-to-end tests for critical user flows using Cypress
- Test AI responses for accuracy and helpfulness

## Deployment Considerations
- Deploy on Vercel for optimal Next.js performance
- Implement proper caching strategies
- Monitor API usage and costs
- Set up analytics to track user engagement

## Dependencies
- Next.js
- React
- TypeScript
- Tailwind CSS
- D3.js
- Three.js
- Circuit simulation library (CircuitJS/EasyEDA)
- OpenAI API or Claude API
- react-markdown
- gray-matter (for parsing markdown)
- @radix-ui/react-* (accessible UI primitives)
- react-aria (ARIA patterns)
- framer-motion (animations)
- @fontsource/lexend (LEXEND font family)
- axe-core (accessibility testing)

## Getting Started

1. Clone this repository
2. Install dependencies: `npm install`
3. Set up environment variables (see `.env.example`)
4. Run development server: `npm run dev`
5. Open [http://localhost:3111](http://localhost:3111) in your browser

## Resources

- [Next.js Documentation](https://nextjs.org/docs)
- [D3.js Documentation](https://d3js.org/)
- [Three.js Documentation](https://threejs.org/docs/)
- [OpenAI API Documentation](https://platform.openai.com/docs/)
- [Claude API Documentation](https://docs.anthropic.com/claude/reference/getting-started-with-the-api)
- AI tutor system prompt in `system_prompt_electricity_tutor.md`
- Complete design specifications in `DESIGN_ACCESSIBILITY_REQUIREMENTS.md`
