# Basic Electricity: A Comprehensive Guide for AI Tutor Training

## Introduction

Electricity powers our modern world, from household appliances to advanced technologies. Understanding its basic principles is essential for safety, efficiency, and innovation. This comprehensive guide covers fundamental concepts of electricity, designed specifically to train an AI chatbot that will serve as a tutor to help students understand basic electricity concepts.

**This document has been enhanced to serve as a "Tutor's Playbook."** Each section includes:
- **Tutor's Playbook:** Socratic prompts to guide students to discover concepts on their own.
- **Interactive Visual Prompts:** Instructions framed as interactive tasks for the student.
- **Guided Solutions & Hints:** A structured hint path for each practice problem to help the tutor guide students without giving away the answer.

## Table of Contents

1.  **Atomic Structure and Electrical Fundamentals**
2.  **Basic Electrical Units and Properties**
3.  **Circuit Components and Analysis**
4.  **Measurement Techniques and Tools**
5.  **Power and Energy Relationships**
6.  **Electrical Safety Principles**
7.  **Practical Applications and Examples**
8.  **Teaching Resources and Methods**

---

## Section 1: Atomic Structure and Electrical Fundamentals

### Understanding the Atom

#### Core Concepts
All matter is composed of atoms, which contain three primary subatomic particles:
1.  **Protons**: Positively charged particles in the nucleus.
2.  **Neutrons**: Neutral particles in the nucleus.
3.  **Electrons**: Negatively charged particles orbiting the nucleus.
An atom is electrically neutral when it has an equal number of protons and electrons. The movement of these particles, particularly electrons, is the basis of all electrical phenomena.

> #### Tutor's Playbook: Understanding the Atom
> -   **Initial Prompt:** "Everything around us, from the air we breathe to the phone in your hand, is made of the same basic building blocks. Do you know what they're called?" (Expected answer: Atoms)
> -   **Follow-up:** "Exactly! And inside these tiny atoms are even smaller particles. Have you heard of protons, neutrons, and electrons? What can you tell me about them?"
> -   **Guidance on Charge:** "You're right that they have charges. Protons are positive, and electrons are negative. What do you think happens if an atom has the same number of protons and electrons? What would its total charge be?" (Expected answer: Neutral/Zero)
> -   **Check for Understanding:** "So, if all electrical phenomena come from these particles, which one do you think is most likely to move around and create what we call electricity? The ones deep inside, or the ones on the outer edges?" (Hint: The ones on the outside).

### Electron Shells and Valence Properties

#### Core Concepts
Electrons exist in shells around the nucleus. The outermost shell is the **valence shell**, and the electrons in it are **valence electrons**. The number of valence electrons determines a material's electrical properties.
-   **Conductors** (1-3 valence electrons): Electrons are held loosely and can move freely. Examples: Copper, Aluminum.
-   **Insulators** (5-8 valence electrons): Electrons are held tightly and cannot move easily. Examples: Rubber, Glass.
-   **Semiconductors** (4 valence electrons): Have properties between conductors and insulators. Examples: Silicon, Germanium.

> #### Interactive Visual Prompt: Atom Explorer
> **Tutor Prompt:** "Let's look at an interactive 3D model of an atom. You can see the nucleus in the center and electrons in shells around it. I've highlighted the outermost shell—the valence shell.
> 1.  First, select the 'Copper' model. How many electrons do you see in that outer shell?
> 2.  Now, switch to the 'Rubber' model. What's the big difference you notice in its outer shell compared to copper?
> 3.  Based on that, which material do you think would let electrons move more easily?"

> #### Analogy: The Flea and the Dog
> **Tutor Prompt:** "Here's a fun way to think about it. Imagine atoms are dogs and electrons are fleas. In an **insulator**, the atoms hold their electrons tightly, like well-behaved dogs in a fenced yard. The fleas (electrons) can't easily jump from one dog to another. How would you describe a **conductor** using this analogy?"

### Electrical Charge and Charge Interaction

#### Core Concepts
**Electrical charge** is a property of matter caused by an excess or deficiency of electrons.
-   **Losing electrons** results in a **positive** charge.
-   **Gaining electrons** results in a **negative** charge.
The fundamental rules of interaction are:
1.  **Like charges repel.** (Positive repels positive, negative repels negative).
2.  **Opposite charges attract.** (Positive attracts negative).

> #### Tutor's Playbook: Charge Interaction
> -   **Initial Prompt:** "Have you ever rubbed a balloon on your hair and had it stick? You've created static electricity! What do you think is actually happening between the balloon and your hair?"
> -   **Guidance on Electron Transfer:** "You're on the right track. Tiny particles called electrons are actually moving from your hair to the balloon. Your hair now has *fewer* electrons than it started with. Is it positively or negatively charged? What about the balloon?"
> -   **Check for Understanding:** "So the hair is positive and the balloon is negative. And they stick together! What does that tell you about how positive and negative charges interact?"

### Coulomb's Law and Charge Quantification

#### Core Concepts
**Coulomb's Law** describes the force (F) between two charges ($q_1$, $q_2$) separated by a distance (r). The force is proportional to the product of the charges and inversely proportional to the square of the distance.
$F = k\frac{|q_1 q_2|}{r^2}$
The standard unit of charge is the **coulomb (C)**. One coulomb is the charge of approximately 6.25 x 10¹⁸ electrons.

> #### Interactive Visual Prompt: Force Simulator
> **Tutor Prompt:** "Here's a simulation with two charged objects. You can use the sliders to change their charge (positive or negative) and the distance between them.
> 1.  Set both charges to be positive. What do the force arrows show?
> 2.  Now, make one charge negative. What happens to the arrows?
> 3.  Keeping the charges the same, move the objects farther apart. What happens to the force? This demonstrates the 'inverse square' relationship."

### Section 1: Practice Problems with Guided Solutions

**1. If an atom has 8 protons, 8 neutrons, and 8 electrons, what is its net electrical charge?**
> **Tutor's Hint Path:**
> -   *Hint 1:* "Let's think about the charges of each particle. What is the charge of a proton? What about an electron?"
> -   *Hint 2:* "The problem states there are 8 positive charges (protons) and 8 negative charges (electrons). What happens when you add +8 and -8 together?"
> -   *Solution:* The net charge is zero. Since there are equal numbers of protons (+8) and electrons (-8), their charges cancel each other out, making the atom electrically neutral.

**2. Why are metals good conductors of electricity? Explain in terms of electron shells.**
> **Tutor's Hint Path:**
> -   *Hint 1:* "Remember what we learned about the 'valence shell'. Is that the inner shell or the outer shell?"
> -   *Hint 2:* "Good conductors have electrons that can move easily. Do you think atoms in a conductor hold on to their valence electrons tightly or loosely?"
> -   *Hint 3:* "How many valence electrons do conductors usually have? Is it a small number or a large number?"
> -   *Solution:* Metals are good conductors because they have only 1-3 electrons in their outer (valence) shell. These electrons are not held tightly by the atom and are free to move from one atom to another, allowing current to flow easily.

**3. Calculate the electrostatic force between two charges of 3 × 10⁻⁶ C and 5 × 10⁻⁶ C separated by a distance of 0.02 meters. (k = 8.99 × 10⁹ Nm²/C²)**
> **Tutor's Hint Path:**
> -   *Hint 1:* "Which formula connects force, charge, and distance?"
> -   *Hint 2:* "The formula is Coulomb's Law: F = k * |q1*q2| / r². What are the values for q1, q2, and r in this problem?"
> -   *Hint 3:* "Remember to square the distance (r) in the denominator. So you'll have (0.02 * 0.02) on the bottom."
> -   *Solution:* F = (8.99 × 10⁹) * |(3 × 10⁻⁶) * (5 × 10⁻⁶)| / (0.02)² = (8.99 × 10⁹) * (15 × 10⁻¹²) / 0.0004 = 337.125 N.

**4. When a plastic comb is rubbed against dry hair, the comb becomes negatively charged. Explain why this happens in terms of electron transfer.**
> **Tutor's Hint Path:**
> -   *Hint 1:* "For the comb to become *negative*, did it have to gain something negative or lose something negative?"
> -   *Hint 2:* "The only mobile charge carriers are electrons. So, did the electrons move from the hair to the comb, or from the comb to the hair?"
> -   *Solution:* The comb becomes negatively charged because it has gained an excess of electrons. The friction from rubbing transferred electrons from the hair to the comb.

**5. If 2.5 × 10²⁰ electrons move from one object to another, what is the magnitude of charge transferred in coulombs?**
> **Tutor's Hint Path:**
> -   *Hint 1:* "We need to relate the number of electrons to the unit of charge, the coulomb. Do you remember how many electrons are in one coulomb?"
> -   *Hint 2:* "One coulomb is the charge of 6.25 x 10¹⁸ electrons. To find the total charge, should you multiply or divide the number of electrons by this value?"
> -   *Solution:* Q = (Number of electrons) / (6.25 × 10¹⁸) = (2.5 × 10²⁰) / (6.25 × 10¹⁸) = 40 C.

---

## Section 2: Basic Electrical Units and Properties

### Voltage: The Driving Force of Electricity

#### Core Concepts
**Voltage** is the electrical "pressure" or potential difference that pushes electrons through a circuit. It is the driving force. It is measured in **Volts (V)**. Voltage does not flow; it *causes* current to flow.

> #### Analogy: The Waterfall
> **Tutor Prompt:** "Think of voltage like the height of a waterfall. The higher the waterfall (higher voltage), the more 'push' the water has when it falls. Does the height itself 'flow' down the waterfall, or does it *cause* the water to flow?"

> #### Tutor's Playbook: Voltage
> -   **Initial Prompt:** "We know electrons flow to make a current. But they don't move on their own. What do you think is needed to 'push' them along a wire?"
> -   **Use Analogy:** "Let's use our waterfall analogy. What gives the water the energy to crash down? It's the height difference, right? Voltage is like that height difference for electricity. It's a potential to do work."
> -   **Check for Understanding:** "So, if we increase the 'electrical pressure' (the voltage), what do you predict will happen to the flow of electrons (the current), assuming nothing else changes?"

### Current: The Flow of Electrical Charge

#### Core Concepts
**Current** is the rate of flow of electrical charge. It measures *how many* electrons are flowing past a point per second. It is measured in **Amperes (A)**, or "amps".

> #### Analogy: The River
> **Tutor Prompt:** "If voltage is the steepness of the riverbed making the water move, what is current? Is it the amount of water, the speed, or how much water flows past you every second?" (Expected answer: how much flows per second).

> #### Tutor's Playbook: Current vs. Electron Flow
> -   **Tutor Note:** A key point of confusion is **conventional current** vs. **electron flow**.
> -   **Prompt:** "Here's a tricky historical fact. Scientists defined the direction of current flow *before* they discovered the electron. They guessed that positive charges moved. So, by convention, we draw arrows showing current flowing from **positive to negative**."
> -   **Clarification:** "However, we now know it's the negatively-charged electrons that actually move. Which way would they flow? From negative to positive, or positive to negative?" (Answer: negative to positive, because they are repelled by negative and attracted to positive).
> -   **Reinforcement:** "It's confusing, but in circuit diagrams, we always use the *conventional* flow (positive to negative). Just remember that the electrons are actually flowing the other way!"

### Resistance: Opposition to Current Flow

#### Core Concepts
**Resistance** is the opposition to current flow. It measures how much a material resists the flow of electrons. It is measured in **Ohms (Ω)**.

> #### Analogy: The Clogged Pipe
> **Tutor Prompt:** "Imagine our water pipe again. What could we do to make it harder for water to flow?" (Expected answers: make it narrower, put rocks in it, etc.). "Exactly! That's what resistance is in a circuit. It's anything that restricts the flow."

> #### Tutor's Playbook: Resistance
> -   **Initial Prompt:** "If you have two wires of the same material, but one is very long and one is very short, which one do you think would be harder for electrons to travel through? Why?"
> -   **Follow-up:** "What if the wires are the same length, but one is very thick and one is very thin? Which one provides more 'lanes' for the electrons to flow through? Which one has lower resistance?"
> -   **Check for Understanding:** "So, what are the two physical factors of a wire that affect its resistance?" (Answer: Length and cross-sectional area/thickness).

> #### Interactive Visual Prompt: Ohm's Law
> **Tutor Prompt:** "This interactive diagram shows the relationship between Voltage (V), Current (I), and Resistance (R).
> 1.  First, slide the Voltage up while keeping Resistance the same. What happens to the Current?
> 2.  Now, reset it. Slide the Resistance up while keeping Voltage the same. What happens to the Current?
> 3.  From this, can you describe the relationship between these three things in your own words?"

### Methods of Voltage Production

#### Core Concepts
Voltage can be produced by converting other forms of energy into electrical energy. The six main methods are:
1.  **Friction (Triboelectric Effect):** Rubbing two materials together (static electricity).
2.  **Chemical (Ionization):** Chemical reactions in batteries.
3.  **Pressure (Piezoelectricity):** Squeezing certain crystals.
4.  **Heat (Thermoelectric Effect):** Heating the junction of two different metals.
5.  **Light (Photovoltaic Effect):** Light striking a solar cell.
6.  **Magnetism (Electromagnetic Induction):** Moving a conductor through a magnetic field. This is how most of our electricity is generated.

> #### Tutor's Playbook: Voltage Production
> -   **Initial Prompt:** "We know a battery provides voltage using chemicals. Can you think of any other ways we might be able to create a voltage? Where does the power in our homes come from?"
> -   **Guidance:** "Think about a hydroelectric dam or a wind turbine. What do they have in common? (They both spin!). That spinning motion is the key. It uses magnetism to generate voltage. Can you think of a small-scale example of getting electricity from light?" (Solar-powered calculator).

### Section 2: Practice Problems with Guided Solutions

**1. A circuit has 12 volts applied across a 100-ohm resistor. Calculate the current flowing through the resistor.**
> **Tutor's Hint Path:**
> -   *Hint 1:* "We need to find the relationship between voltage, resistance, and current. Do you remember the name of the law that connects them?"
> -   *Hint 2:* "It's Ohm's Law. The formula is V = I × R. How can we rearrange that formula to solve for current (I)?"
> -   *Solution:* I = V / R = 12V / 100Ω = 0.12 A (or 120 mA).

**2. If the current in a circuit increases from 2 amperes to 6 amperes while the resistance remains constant at 5 ohms, what is the change in voltage?**
> **Tutor's Hint Path:**
> -   *Hint 1:* "This is a two-part problem. First, we need to find the starting voltage, then the ending voltage."
> -   *Hint 2:* "Use Ohm's Law (V = I × R) to calculate the voltage when the current is 2A. Then, calculate it again for when the current is 6A."
> -   *Hint 3:* "Once you have the starting voltage and the ending voltage, how do you find the 'change' between them?"
> -   *Solution:* 
>     -   Initial Voltage (V1) = 2A × 5Ω = 10V.
>     -   Final Voltage (V2) = 6A × 5Ω = 30V.
>     -   The change in voltage is V2 - V1 = 30V - 10V = 20V.

**3. A 50-foot length of copper wire has a resistance of 0.5 ohms. If you double the length of the wire to 100 feet (keeping all other factors the same), what will be its new resistance?**
> **Tutor's Hint Path:**
> -   *Hint 1:* "Think about the relationship between a wire's length and its resistance. Is it a direct relationship (more length, more resistance) or an inverse one?"
> -   *Hint 2:* "Resistance is directly proportional to length. If you double the length, what do you think happens to the resistance?"
> -   *Solution:* Since resistance is directly proportional to length, doubling the length from 50 feet to 100 feet will also double the resistance. The new resistance will be 0.5Ω × 2 = 1.0Ω.

**4. Identify the color code bands of a 470 ohm resistor with ±10% tolerance using the four-band system.**
> **Tutor's Hint Path:**
> -   *Hint 1:* "Let's break it down. The first two bands are the digits. What are the first two digits in 470?"
> -   *Hint 2:* "The third band is the 'multiplier'—the number of zeros to add. How many zeros are in 470?" (Answer: one). "So the multiplier is 10¹."
> -   *Hint 3:* "Now look up a resistor color code chart. What color corresponds to 4? What color for 7? What color for a multiplier of 10? And what color for 10% tolerance?"
> -   *Solution:* 
>     -   1st band (digit 4): Yellow
>     -   2nd band (digit 7): Violet
>     -   3rd band (multiplier x10): Brown
>     -   4th band (tolerance ±10%): Silver

**5. Which voltage generation method is most commonly used in large-scale power plants? Explain how it works.**
> **Tutor's Hint Path:**
> -   *Hint 1:* "Think about power plants you've seen or heard of (like hydroelectric dams or coal plants). What are they usually doing? Are they using friction? Chemicals? Or are they spinning something really big?"
> -   *Hint 2:* "They are spinning turbines! This spinning motion is used to move a conductor through a magnetic field. What is this method of generating voltage called?"
> -   *Solution:* Magnetism (or Electromagnetic Induction) is the most common method. It works by rotating a conductor (like a coil of wire) within a magnetic field. The interaction between the moving wire and the magnetic field forces electrons to move, generating a voltage.

---
## Section 3: Circuit Components and Analysis

### Basic Circuit Components

#### Core Concepts
Every functional electrical circuit has four basic parts:
1.  **Power Source:** Provides the voltage (e.g., battery, generator).
2.  **Conductor:** Provides the path for current (e.g., wire).
3.  **Load:** The device that does the work (e.g., light bulb, motor).
4.  **Control Device:** A switch to open or close the circuit.

> #### Tutor's Playbook: Circuit Components
> -   **Initial Prompt:** "Let's think about a simple flashlight. What are all the parts inside it that make it work?" (Guide them to identify the batteries, the bulb, the switch, and the metal strips connecting them).
> -   **Connect to Concepts:** "Great! You've just identified the four main parts of any circuit. Which part is the 'Power Source'? The 'Load'? The 'Conductor'? The 'Control Device'?"
> -   **Check for Understanding:** "What do you think would happen if we took the switch out and just connected the wires directly? Would the flashlight work? What would be the downside?"

### Series Circuit Analysis

#### Core Concepts
A **series circuit** provides only **one path** for the current.
-   **Current:** Is the **same** at all points in the circuit. ($I_T = I_1 = I_2 = ...$)
-   **Resistance:** The total resistance is the **sum** of all individual resistances. ($R_T = R_1 + R_2 + ...$)
-   **Voltage:** The source voltage is **divided** among the components. ($V_T = V_1 + V_2 + ...$)

> #### Analogy: One-Lane Road
> **Tutor Prompt:** "A series circuit is like a one-lane road. All the cars (current) have to follow the same path. If there's a crash (a broken component), what happens to the traffic flow everywhere on the road?"

> #### Tutor's Playbook: Series Circuits
> -   **Initial Prompt:** "Imagine you have a string of old holiday lights. If one bulb burns out, the whole string goes dark. Based on what we just discussed, do you think those lights are wired in series or some other way? Why?"
> -   **Check for Understanding:** "In that one-lane road, all the cars are traveling at the same speed (current). But if there are hills (resistors), the car has to use some of its energy to get over each one. How does this relate to how voltage behaves in a series circuit?"

### Parallel Circuit Analysis

#### Core Concepts
A **parallel circuit** provides **multiple paths** for the current.
-   **Voltage:** Is the **same** across all parallel branches. ($V_T = V_1 = V_2 = ...$)
-   **Current:** The total current is the **sum** of the currents in each branch. ($I_T = I_1 + I_2 + ...$)
-   **Resistance:** The total resistance is found using the reciprocal formula: $1/R_T = 1/R_1 + 1/R_2 + ...$ **Adding a new path *decreases* the total resistance.**

> #### Analogy: Multi-Lane Highway
> **Tutor Prompt:** "A parallel circuit is like a multi-lane highway. The cars (current) can choose different lanes to travel in. If one lane gets blocked, what happens to the traffic in the other lanes?"

> #### Tutor's Playbook: Parallel Circuits
> -   **Initial Prompt:** "Think about the outlets in your house. If you unplug your TV, does your lamp in the same room turn off? What does this tell you about how the outlets are wired?"
> -   **Sticking Point:** "Here's a tricky one. If we add another lane to our highway, does that make it easier or harder for traffic to get through overall? How does this relate to what happens to the *total resistance* when we add another branch to a parallel circuit?"

### Series-Parallel Circuits

#### Core Concepts
These circuits are combinations of series and parallel parts. To analyze them, simplify the circuit in steps:
1.  Identify sections that are purely series or purely parallel.
2.  Calculate the equivalent resistance for one of those sections.
3.  Redraw the circuit with the simplified "block."
4.  Repeat until you have one equivalent resistance for the whole circuit.

> #### Tutor's Playbook: Series-Parallel
> -   **Initial Prompt:** "Now for the fun part: mixing them! Look at this circuit diagram. Can you spot a group of resistors that are in parallel with each other? What about any that are in series?"
> -   **Guidance:** "The key is to simplify it piece by piece. Let's start with that parallel block you identified. If we calculate its equivalent resistance, we can replace that whole section with a single imaginary resistor. What would the circuit look like then?"

### Section 3: Practice Problems with Guided Solutions

**1. In a series-parallel circuit, a 12V source powers two parallel branches. Branch 1 has a single 8Ω resistor. Branch 2 has two 6Ω resistors in series. Calculate the total current from the source.**
> **Tutor's Hint Path:**
> -   *Hint 1:* "Let's simplify this first. Look at Branch 2. What is the total resistance of those two 6Ω resistors in series?"
> -   *Hint 2:* "Okay, so now you have a simpler circuit: a 12V source connected to two resistors in parallel. One is 8Ω, and the other is the 12Ω you just calculated. What's the next step?"
> -   *Hint 3:* "Now you need to find the total equivalent resistance of the 8Ω and 12Ω resistors in parallel. Then you can use Ohm's law with the source voltage to find the total current."
> -   *Solution:*
>     -   Resistance of Branch 2 = 6Ω + 6Ω = 12Ω.
>     -   Total Resistance (RT) for parallel branches: 1/RT = 1/8Ω + 1/12Ω = 3/24Ω + 2/24Ω = 5/24Ω. So, RT = 24/5 = 4.8Ω.
>     -   Total Current = V / RT = 12V / 4.8Ω = 2.5 A.

**2. A 100Ω resistor is in series with a parallel combination of a 200Ω resistor and a 300Ω resistor. If the circuit is connected to a 24V source, what is the voltage across the 100Ω resistor?**
> **Tutor's Hint Path:**
> -   *Hint 1:* "This is a multi-step problem. To find the voltage across the 100Ω resistor, we first need to know the *total current* flowing through it."
> -   *Hint 2:* "To find the total current, we need the *total resistance* of the entire circuit. Where should you start simplifying?"
> -   *Hint 3:* "Start by finding the equivalent resistance of the 200Ω and 300Ω parallel section. Then add that result to the 100Ω series resistor to get the total resistance. From there, you can find the total current."
> -   *Solution:*
>     -   Parallel section: 1/Rp = 1/200 + 1/300 = 3/600 + 2/600 = 5/600. So, Rp = 600/5 = 120Ω.
>     -   Total Resistance RT = 100Ω + 120Ω = 220Ω.
>     -   Total Current IT = 24V / 220Ω = 0.109 A.
>     -   Voltage across 100Ω resistor = IT × R1 = 0.109A × 100Ω = 10.9V.

---
## Section 4: Measurement Techniques and Tools

### Electrical Meters and Safety Precautions

#### Core Concepts
The **Digital Multimeter (DMM)** is the most common tool. It can measure Voltage, Current, and Resistance. Safety is the #1 priority when taking measurements.
-   **NEVER** touch the metal tips of the probes.
-   **ALWAYS** inspect your meter and leads for damage before use.
-   **ALWAYS** connect the ammeter in **SERIES**.
-   **ALWAYS** connect the voltmeter in **PARALLEL**.
-   **ALWAYS** de-energize the circuit before measuring **RESISTANCE**.

> #### Tutor's Playbook: Meter Safety
> -   **Initial Prompt:** "We're about to measure a live circuit. What is the very first thing you should do with your multimeter before you even touch the circuit?" (Expected: Inspect it for damage).
> -   **Scenario:** "I want to measure the current flowing through this light bulb. Should I place my meter probes on both sides of the bulb, or do I need to break the circuit and insert the meter into the path? Why?"
> -   **Sticking Point:** "A very common and dangerous mistake is to try and measure current by putting the meter in parallel, like a voltmeter. This creates a short circuit through the meter! Why is that? Think about the internal resistance of an ammeter—is it very high or very low?" (Answer: Very low, so it acts like a plain wire).

### Measuring Voltage, Current, and Resistance

#### Core Concepts
-   **Voltage Measurement:** Connect the meter in **parallel** (across) the component. The circuit should be **ON**.
-   **Current Measurement:** Connect the meter in **series** (breaking the circuit to insert the meter). The circuit must be **ON**.
-   **Resistance Measurement:** Connect the meter in **parallel** (across) the component. The circuit must be **OFF** and the component should be isolated if possible.

> #### Interactive Visual Prompt: Meter Placement
> **Tutor Prompt:** "Here is a diagram of a simple circuit with a battery, switch, and lamp.
> 1.  Show me where you would place the voltmeter probes to measure the voltage across the lamp.
> 2.  Now, show me how you would have to change the circuit to measure the current flowing *through* the lamp with an ammeter.
> 3.  If you wanted to measure the resistance of just the lamp, what is the first thing you MUST do?" (Answer: Turn off the power/remove the battery).

### Section 4: Practice Problems with Guided Solutions

**1. When measuring the current flowing through an LED in a circuit, would you place the multimeter in series or in parallel with the LED? Explain your answer.**
> **Tutor's Hint Path:**
> -   *Hint 1:* "Remember the rule for measuring current. Are we measuring a *difference across* something, or the *flow through* something?"
> -   *Hint 2:* "To measure flow *through* a point, the meter has to become part of the path itself. Does that sound like series or parallel?"
> -   *Solution:* You must place the multimeter in **series**. To measure current, the entire flow of electrons must pass through the meter. This requires breaking the circuit and inserting the ammeter into the current's path.

**2. A technician needs to measure the voltage drop across a resistor in a powered circuit. Describe the proper procedure.**
> **Tutor's Hint Path:**
> -   *Hint 1:* "First, what function should the multimeter be set to? AC or DC volts?"
> -   *Hint 2:* "Next, how should the probes be connected relative to the resistor? In series or in parallel?"
> -   *Hint 3:* "What about safety? Should the circuit be on or off? Where should the technician's hands be?"
> -   *Solution:* 1. Set the DMM to the appropriate voltage setting (AC or DC). 2. Ensure the circuit is powered ON. 3. Place the red and black probes on opposite sides of the resistor (in parallel). 4. Read the voltage on the meter.

**3. When troubleshooting a circuit with no power, a technician measures 120V at the power source but 0V at the load. List three potential problems.**
> **Tutor's Hint Path:**
> -   *Hint 1:* "The power is good at the start but gone at the end. This means there must be a break somewhere in between."
> -   *Hint 2:* "What are the components that connect the source to the load? Think about the path."
> -   *Hint 3:* "Consider the control devices and the conductors themselves."
> -   *Solution:* 1. **An open switch:** The switch is off or broken. 2. **A blown fuse or tripped circuit breaker:** The protection device has opened the circuit. 3. **A broken wire:** The conductor itself has a break somewhere between the source and the load.

---
## Section 5: Power and Energy Relationships

### Calculating Electrical Power

#### Core Concepts
**Power (P)** is the rate at which energy is used. It's measured in **Watts (W)**.
There are three key formulas, all derived from Ohm's Law:
1.  $P = V \times I$ (The main one)
2.  $P = I^2 \times R$ (Useful if you don't know V)
3.  $P = V^2 / R$ (Useful if you don't know I)

> #### Analogy: Speedometer vs. Odometer
> **Tutor Prompt:** "Think of a car. Power is like your speedometer—it tells you how fast you are using energy *right now*. Energy is like your odometer—it tells you how much total fuel you have used over your whole trip. What are the units for electrical power? And for electrical energy?" (Watts and Watt-hours).

### Energy Consumption and Efficiency

#### Core Concepts
**Energy (E)** is power used over a period of time. It's what the utility company bills you for.
-   $E = P \times t$ (Energy = Power × time)
-   The common unit is the **kilowatt-hour (kWh)**.
**Efficiency** is the ratio of useful output power to total input power, always less than 100%.
-   $Efficiency (\%) = (P_{out} / P_{in}) \times 100$

> #### Tutor's Playbook: Efficiency
> -   **Initial Prompt:** "Think about an old incandescent light bulb. When it's on, it produces light, but what else does it produce?" (Heat).
> -   **Guidance:** "Is the heat a 'useful' output for a light bulb? (No). So, the energy converted to heat is lost. Efficiency tells us how much of the input energy becomes useful output, versus how much is lost."

### Section 5: Practice Problems with Guided Solutions

**1. A 1,200W microwave oven operates at 120V. Calculate the current it draws.**
> **Tutor's Hint Path:**
> -   *Hint 1:* "We know Power (P) and Voltage (V), and we need to find Current (I). Which of the three power formulas should we use?"
> -   *Hint 2:* "The formula is P = V × I. How can you rearrange that to solve for I?"
> -   *Solution:* I = P / V = 1,200W / 120V = 10 A.

**2. A household uses a 3,500W air conditioner for 8 hours per day. Calculate the monthly energy consumption in kWh.**
> **Tutor's Hint Path:**
> -   *Hint 1:* "The formula for energy is E = P × t. But first, we need to make sure the units are correct. What should the unit for power be?" (Kilowatts).
> -   *Hint 2:* "How do you convert 3,500 watts to kilowatts?" (Divide by 1000).
> -   *Hint 3:* "Once you have the daily energy use in kWh, how do you find the monthly usage? (Assume 30 days in a month)."
> -   *Solution:*
>     -   Power in kW = 3,500W / 1000 = 3.5 kW.
>     -   Daily Energy = 3.5 kW × 8 hours = 28 kWh.
>     -   Monthly Energy = 28 kWh/day × 30 days = 840 kWh.

**3. If a DC motor draws 5A at 24V but produces only 105W of mechanical power output, calculate its efficiency.**
> **Tutor's Hint Path:**
> -   *Hint 1:* "Efficiency is Output Power / Input Power. We are given the output power. How can we calculate the input power?"
> -   *Hint 2:* "Use the power formula P = V × I to find the input power."
> -   *Solution:*
>     -   Input Power (Pin) = 24V × 5A = 120 W.
>     -   Efficiency = (Pout / Pin) × 100 = (105W / 120W) × 100 = 0.875 × 100 = 87.5%.

---
## Section 6: Electrical Safety Principles

### Understanding Electric Shock

#### Core Concepts
Electric shock severity depends on three main factors:
1.  **Current Magnitude:** The amount of current flowing through the body. As little as 50-100mA (0.05A) can be fatal.
2.  **Current Path:** A path across the heart (e.g., hand-to-hand) is most dangerous.
3.  **Duration:** The longer the contact, the more damage is done.
**It is the CURRENT, not the voltage, that causes injury.** High voltage is dangerous because it can push a lethal current through the body's resistance.

> #### Tutor's Playbook: Shock
> -   **Initial Prompt:** "We often hear 'Danger: High Voltage!' But is it the voltage itself that harms you, or something else?"
> -   **Guidance:** "Let's use Ohm's Law (I = V/R). Your body has resistance. If the voltage is very high, what does that do to the current that can be pushed through your body? And what have we learned is the thing that actually causes the shock?"

### Grounding and Protection Mechanisms

#### Core Concepts
-   **Grounding:** Provides a safe path for fault current to flow to the earth, preventing a person from becoming that path.
-   **Fuses/Circuit Breakers:** Detect overcurrent (too much current) and open the circuit to stop the flow.
-   **Ground Fault Circuit Interrupters (GFCIs):** Detect very small currents leaking to ground (like through a person) and shut off power extremely quickly. They are essential for safety in wet locations.

> #### Analogy: Safety Spillway
> **Tutor Prompt:** "Think of a grounding system like an emergency spillway on a dam. Normally, no water flows through it. But if there's a flood (an electrical fault), it provides a safe, easy path for the water (current) to go, so it doesn't overflow and destroy the village (electrocute you)."

### Safe Practices for Working with Electricity

#### Core Concepts
The most important rule is **Lockout/Tagout (LOTO)**.
1.  **Turn off** the power.
2.  **Lock** the disconnect so no one can turn it back on.
3.  **Verify** with a meter that the circuit is truly de-energized before touching anything.
Always use insulated tools and wear appropriate Personal Protective Equipment (PPE).

> #### Tutor's Playbook: Safe Practices
> -   **Initial Prompt:** "If you need to work on an electrical circuit, what is the absolute first and most important step?" (Turn off the power).
> -   **Follow-up:** "What if you turn it off, but someone else in another room doesn't know you're working on it and turns it back on? What's a procedure we can use to prevent that?" (This leads to Lockout/Tagout).

### Section 6: Practice Problems with Guided Solutions

**1. Calculate the current that would flow through a person with 5,000 ohms of body resistance if they contacted a 120V circuit. Is this dangerous?**
> **Tutor's Hint Path:**
> -   *Hint 1:* "We have voltage and resistance. What law can we use to find the current?"
> -   *Hint 2:* "Use I = V/R. The result will be in Amperes. It's often easier to think about shock in milliamperes (mA). How do you convert Amps to milliamps?" (Multiply by 1000).
> -   *Hint 3:* "Look at the chart of physiological effects. Where does your calculated current fall?"
> -   *Solution:*
>     -   Current (I) = 120V / 5,000Ω = 0.024 A.
>     -   In milliamps, this is 0.024 A × 1000 = 24 mA.
>     -   This is very dangerous. It is above the "let-go" threshold (meaning you can't let go of the wire) and can cause respiratory paralysis.

**2. Explain the primary purpose of equipment grounding.**
> **Tutor's Hint Path:**
> -   *Hint 1:* "Imagine a faulty toaster where the live wire inside accidentally touches the metal case. What would happen if you touched the toaster if it wasn't grounded?"
> -   *Hint 2:* "Now, imagine that toaster has a ground wire connecting the metal case to the earth. Where would the electricity prefer to flow: through the low-resistance ground wire, or through your high-resistance body?"
> -   *Solution:* The primary purpose is to protect people from shock. If a fault causes the metal frame of a device to become energized, the ground wire provides a low-resistance path for the current to flow to the earth. This large current flow will trip the circuit breaker, de-energizing the circuit and removing the hazard.

---
*The remaining sections (Practical Applications, Teaching Resources) would be similarly reformatted to maintain the Socratic, guided-learning structure.*