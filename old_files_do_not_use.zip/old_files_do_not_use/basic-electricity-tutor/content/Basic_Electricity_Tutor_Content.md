# Basic Electricity: A Comprehensive Guide for AI Tutor Training

## Introduction

Electricity powers our modern world, from household appliances to advanced technologies. Understanding its basic principles is essential for safety, efficiency, and innovation. This comprehensive guide covers fundamental concepts of electricity, designed specifically to train an AI chatbot that will serve as a tutor to help students understand basic electricity concepts.

The content is structured to build knowledge progressively, starting with atomic structure and moving through to practical applications and safety. Each section includes clear explanations, analogies to aid understanding, and practice questions to reinforce learning.

## Table of Contents

1. **Atomic Structure and Electrical Fundamentals**
   - Understanding the Atom
   - Electron Shells and Valence Properties
   - Electrical Charge and Charge Interaction
   - Coulomb's Law and Charge Quantification

## Section 1: Atomic Structure and Electrical Fundamentals

### Understanding the Atom

Electricity is a phenomenon we encounter daily through home appliances, cellular phones, computers, and vehicles. To comprehend what electricity truly is, we must examine the fundamental building blocks of all matter: atoms. The **atom** represents the smallest particle of any matter, and everything around us consists of these microscopic components. Understanding atomic structure provides the foundation for grasping electrical concepts, as all electrical phenomena originate from the behavior of subatomic particles.

**Atomic structure** provides the fundamental basis for understanding electricity.[^15] [^20] All matter is composed of atoms, which contain three primary subatomic particles:

1. **Protons**: Positively charged particles located in the nucleus of the atom. Each proton carries one elementary unit of positive charge.[^18]

2. **Neutrons**: Uncharged (neutral) particles found alongside protons in the nucleus. They contribute to the atomic mass but not to the electrical properties.[^18] [^19]

3. **Electrons**: Negatively charged particles that orbit the nucleus in shells or energy levels. Each electron carries one elementary unit of negative charge.[^33]

The arrangement of these particles creates an electrically neutral atom under normal conditions. Atoms maintain electrical neutrality because they contain equal numbers of protons and electrons, causing the positive and negative charges to cancel each other out. However, this balance can be disrupted through various processes, leading to the formation of ions—atoms with electrons added or removed. The fundamental charge of an electron is 1.602 × 10^-19 coulombs, establishing the basic unit of electrical charge.

> **Teaching Note**: When explaining atomic structure to beginners, the planetary model (electrons orbiting the nucleus like planets around the sun) provides an accessible visualization, even though the electron cloud model more accurately represents quantum mechanical behavior. Start simple, then build complexity.

### Electron Shells and Valence Properties

Electrons arrange themselves in specific energy levels or shells surrounding the nucleus. Each shell can accommodate a maximum number of electrons:

- First shell: 2 electrons
- Second shell: 8 electrons
- Third shell: 18 electrons
- Fourth shell: 32 electrons
- Fifth shell: 50 electrons

While these specific numbers are important for understanding atomic structure, electricians primarily focus on the outermost shell, known as the **valence shell**. The valence shell determines a material's electrical properties and can contain a maximum of 8 valence electrons. The number of valence electrons categorizes materials into three fundamental types based on their electrical conductivity:

> **Visual Aid Instruction:** Generate an interactive 3D model of an atom showing: nucleus (protons and neutrons) at center, electron shells/orbitals as concentric spheres, highlighting the valence electrons in the outermost shell. Create three variations side by side: copper (conductor), silicon (semiconductor), and rubber (insulator). Label each shell with its electron capacity (2, 8, 18, 32).

- **Conductors** possess 1-3 valence electrons, allowing electrons to move freely through the material under the influence of an electric field.[^23] [^34] Common conductors include metals like copper and aluminum, which are extensively used in electrical wiring due to their low resistance to electron flow.

- **Semiconductors** contain exactly 4 valence electrons, exhibiting electrical properties between conductors and insulators.[^34] These materials, such as silicon and germanium, form the foundation of modern electronics and can be modified through doping to enhance their conductivity.

- **Insulators** have 5-8 valence electrons, with their electrons tightly bound to atoms, preventing easy current flow.[^23] [^34] Materials like rubber, glass, and ceramics serve as insulators in electrical systems, providing safety and preventing unwanted current paths.

> **Visual Aid Instruction:** Create an animation showing how electrons move freely in a conductor under electric field influence, how electrons are tightly bound in insulators, and how semiconductors exhibit properties between conductors and insulators. Use arrows and color coding to indicate electron movement patterns.

> **Analogy**: A helpful way to understand conductors versus insulators is to compare atoms to pet dogs and electrons to fleas. In an insulator, the atoms hold their electrons tightly, like well-behaved dogs kept inside fenced yards—the fleas (electrons) can't easily jump from one dog to another. In a conductor, the atoms hold their electrons loosely, like a group of stray dogs roaming freely—the fleas (electrons) can easily jump from dog to dog, spreading quickly.

### Electrical Charge and Charge Interaction

**Electrical charge** represents the electrical characteristic of matter caused by an excess or deficiency of electrons. When objects gain or lose electrons, they develop an electrical charge that creates forces between charged particles. This fundamental concept explains many everyday electrical phenomena, from static electricity to the operation of electronic devices.

A practical demonstration of electrical charge involves rubbing a balloon against hair. During this process, electrons transfer from the hair to the balloon, creating an imbalance of charge. The hair, having lost electrons, becomes positively charged due to an excess of protons, while the balloon becomes negatively charged due to an excess of electrons. This charge separation creates an attractive force between the hair and balloon, demonstrating the fundamental principle that opposite charges attract.

Three fundamental rules govern the behavior of electrical charges:

1. **Like positive charges repel each other**, creating a force that pushes like charges apart.
2. **Like negative charges also repel each other**, following the same principle of like-charge repulsion.
3. **Opposite charges attract each other**, with positive charges drawn to negative charges and vice versa.

These principles form the foundation for understanding electrical phenomena, from the behavior of electrons in circuits to the operation of electrical devices.

**Applications of Static Electricity**:
- **Electrostatic Painting**: In automotive manufacturing, paint particles are given a static charge, and the car body is given the opposite charge. This ensures the paint is strongly attracted to the body, creating a smooth, even coat with minimal waste.
- **Air Purification**: Electrostatic precipitators in air purifiers and industrial smokestacks charge particles of dust and smoke, which are then collected on oppositely charged plates, removing them from the air.
- **Photocopiers and Laser Printers**: These devices use static electricity to attract powdered ink (toner) to a charged drum, which then transfers the image onto paper.

### Coulomb's Law and Charge Quantification

In the 18th century, French physicist Charles-Augustin de Coulomb formulated a law to describe the force between charged objects. **Coulomb's Law** states that a force exists between two point-source charges that is directly proportional to the product of the two charges and inversely proportional to the square of the distance between them.[^21] [^66] This relationship can be expressed mathematically as:

> **Visual Aid Instruction:** Create an interactive visualization showing how electrostatic force changes between two charged objects. Include adjustable sliders for charge values (positive and negative) and distance between charges. Show force vectors changing in real-time as parameters are adjusted. Demonstrate the inverse square relationship with a graph plotting force vs. distance.

$F = k\frac{|q_1 q_2|}{r^2}$

where $F$ represents the electrostatic force, $q_1$ and $q_2$ are the charges, $r$ is the distance between charges, and $k$ is Coulomb's constant (approximately 8.99 × 10^9 Nm²/C²).

A **coulomb (C)** serves as the standard unit of electrical charge. One coulomb equals the total charge carried by 6.25 × 10^18 electrons. This enormous number demonstrates the incredibly small charge carried by individual electrons. To calculate the charge in coulombs for a specific number of electrons, we use the formula:

$Q = \frac{\text{Number of electrons}}{6.25 × 10^{18}}$

**Example**:  
How many coulombs of charge do 65.5 × 10^31 electrons have?

$Q = \frac{65.5 × 10^{31}}{6.25 × 10^{18}} = 10.48 × 10^{13}$ coulombs

This quantification of charge provides the foundation for understanding current, which measures the flow of charge over time.

> **Teaching Note**: When explaining Coulomb's Law, use visual demonstrations with magnets or balloons to provide a tangible experience of attraction and repulsion forces. Visual simulations can also effectively demonstrate how force changes with distance.

**Practice Questions**:

1. If an atom has 8 protons, 8 neutrons, and 8 electrons, what is its net electrical charge?

2. Why are metals good conductors of electricity? Explain in terms of electron shells.

3. Calculate the electrostatic force between two charges of 3 × 10^-6 C and 5 × 10^-6 C separated by a distance of 0.02 meters.

4. When a plastic comb is rubbed against dry hair, the comb becomes negatively charged. Explain why this happens in terms of electron transfer.

5. If 2.5 × 10^20 electrons move from one object to another, what is the magnitude of charge transferred in coulombs?

2. **Basic Electrical Units and Properties**
   - Voltage: The Driving Force of Electricity
   - Current: The Flow of Electrical Charge
   - Resistance: Opposition to Current Flow
   - Methods of Voltage Production

## Section 2: Basic Electrical Units and Properties

### Voltage: The Driving Force of Electricity

**Voltage** represents the fundamental driving force in electrical systems, defined as the potential difference between two points in a conducting path.[^24] [^25] [^26] [^27] Voltage measures the electromotive force (EMF) or potential difference that creates the "pressure" necessary to move electrons through a circuit. This electrical pressure can be compared to water pressure in a hydraulic system—just as water pressure pushes water through pipes, voltage pushes electrons through conductors.

One volt represents the amount of potential necessary to cause one coulomb of charge to produce one joule of work. This relationship establishes voltage as a measure of energy per unit charge, quantifying the work required to move electrical charges between two points. Voltage does not flow through circuits; instead, it provides the force that causes current to flow. The presence of voltage is essential for current flow—without voltage, electrons move randomly within conductors and no useful current can be established.

The relationship between voltage and current demonstrates a fundamental electrical principle: current is directly proportional to voltage. When voltage increases in a circuit, current increases proportionally, assuming resistance remains constant. Conversely, when voltage decreases, current decreases accordingly. This proportional relationship forms part of Ohm's Law, one of the most important principles in electrical theory.

Voltage is designated by the symbols **E** or **V** in electrical formulas and circuit diagrams. The letter E originates from "electromotive force," reflecting voltage's historical terminology, while V directly represents the unit of measurement. In modern electrical practice, both symbols are commonly used, with V more prevalent in contemporary applications.

> **Visual Aid Instruction:** Create an interactive Ohm's Law triangle diagram that shows the relationship between V, I, and R. Design it to allow students to cover one variable to see how to calculate it. Include formula variations: V=IR, I=V/R, R=V/I. Add visual examples of how changing one variable affects others (slider controls).

> **Analogy**: A useful analogy for understanding voltage is to think of it as the height of a waterfall. The higher the waterfall, the more potential energy the water has, and the more work it can do as it falls. Similarly, higher voltage means more electrical "pressure" and more potential to do work when the electrons flow through a circuit.

### Current: The Flow of Electrical Charge

**Current** represents the rate of charge flow in electrical systems, measuring how much electrical charge passes a specific point over a given time period.[^29] [^30] In mathematical terms, current equals charge divided by time: $I = Q/t$. This fundamental relationship establishes current as a measure of electron movement through conductors.

Under normal conditions, free electrons in conductors move randomly without creating useful current. However, when voltage is applied to a material, electrons begin moving in a directed manner from negative toward positive potential. Since electrons carry negative charge, they are repelled by the negative terminal of a voltage source and attracted to the positive terminal. This directed electron movement constitutes electrical current.

An **ampere** (commonly called an amp) serves as the standard unit for measuring current. One ampere represents the flow of one coulomb of charge past a point in one second. To put this in perspective, one ampere means that 6.24 × 10^18 electrons (6.24 billion billion electrons) flow past a single point in a circuit every second. This enormous number illustrates the incredible quantity of electrons involved in even modest electrical currents.

Current measurement uses various submultiples for different applications:
- **Milliamperes (mA)** represent thousandths of an ampere (0.001 A) and are commonly used for measuring current in electronic circuits.
- **Microamperes (µA)** represent millionths of an ampere (0.000001 A) and are used for very small currents in sensitive electronic applications.

In electrical formulas such as Ohm's Law, current is represented by the symbol **I**, which stands for "intensity." The unit "ampere" honors French mathematician and physicist André-Marie Ampère (1775-1836), who made fundamental discoveries about the relationship between electricity and magnetism.

> **Analogy**: Current can be compared to the flow rate of water in a pipe. Just as we might measure water flow in gallons or liters per minute, electrical current measures the flow of electrons past a point in coulombs per second. A larger pipe allows more water to flow, just as a larger conductor allows more current to flow.

> **Teaching Note**: When explaining current, it's important to address the difference between conventional current flow (positive to negative) and actual electron flow (negative to positive). Conventional current direction was established before the discovery of electrons and remains the standard for circuit analysis, even though we now know electrons flow in the opposite direction.

### Resistance: Opposition to Current Flow

**Resistance** represents the opposition to electron flow in electrical circuits.[^28] [^70] Just as rocks and debris in a river reduce water flow speed and energy, resistance in electrical circuits impedes current flow and dissipates electrical energy. This fundamental property affects how electrical circuits operate and determines how much current flows for a given voltage.

The relationship between resistance and current demonstrates an inverse proportionality: as resistance increases in a circuit, current decreases proportionally. Conversely, when resistance decreases, current increases. This relationship, combined with voltage and current relationships, forms the foundation of Ohm's Law, which states that voltage equals current multiplied by resistance ($V = I × R$).[^70] [^73]

Resistance is designated by the symbol **R** and measured in **ohms**, represented by the Greek letter omega (Ω). One ohm of resistance allows one ampere of current to flow when one volt is applied across it. This relationship provides a practical way to understand the interaction between voltage, current, and resistance in electrical circuits.

The resistance of materials depends on several factors:

1. **Material composition**: The atomic structure of the material determines its intrinsic resistance.
2. **Length**: Longer conductors have higher resistance because electrons must travel farther, encountering more opposition.
3. **Cross-sectional area**: Thicker conductors have lower resistance because they provide more paths for electrons to flow.
4. **Temperature**: For most metals, resistance increases with temperature due to increased atomic vibration.

**Resistors** are devices specifically designed to introduce controlled amounts of resistance into circuits. They serve multiple purposes: limiting current flow, dividing voltage, and generating heat for specific applications. Resistors are categorized into two main types: fixed resistors and variable resistors.

**Fixed resistors** have predetermined resistance values that cannot be changed during normal operation. They are available in a wide range of resistance values and are manufactured using various technologies, including carbon-composite, metal film, and chip array configurations. The most commonly used type is the carbon-composite resistor, which uses color-coded bands to indicate its resistance value and tolerance.

The color coding system for resistors provides a standardized method for identifying resistance values:

- Four-band resistors use the first two bands to represent digits, the third band as a multiplier (number of zeros), and the fourth band to indicate tolerance.
- Five-band resistors use the first three bands for digits, the fourth band as a multiplier, and the fifth band for tolerance.

For example, a four-band resistor with red (2), green (5), brown (×10), and gold (±5%) bands would have a resistance of 250 ohms with ±5% tolerance.

**Variable resistors** allow resistance values to be adjusted during operation. They serve two primary functions:
- **Potentiometers** for voltage division (three-terminal devices) 
- **Rheostats** for current control (typically two-terminal devices)

A potentiometer has three terminals and uses a moving contact (wiper) to tap different voltages from a fixed resistance element. Potentiometers are commonly used in volume controls, speed controls for DC motors, and various adjustment circuits.

### Methods of Voltage Production

Electrical systems require sources of electromotive force to create the voltage necessary for current flow. Six primary methods exist for producing voltage, each converting different forms of energy into electrical energy. Understanding these methods provides insight into how various electrical devices and power generation systems operate.

1. **Friction EMF (Triboelectric Effect)** operates on the principle that rubbing two dissimilar materials together causes electron transfer between them. This process creates a charge imbalance, with one material becoming negatively charged (electron surplus) and the other positively charged (electron deficiency). The resulting electrostatic discharge can create dramatic effects, such as lightning, where charge buildup in clouds creates an electric field strong enough to ionize air and create a conducting path to earth.

2. **Chemical EMF** forms the basis of battery operation through ionization processes. Batteries contain chemicals that create particles with positive and negative charges (ions). Metal plates within the battery take on these charges, creating a potential difference between the battery terminals. This process enables portable electrical energy storage and provides power for countless electronic devices.

3. **Pressure EMF (Piezoelectricity)** generates voltage when mechanical stress is applied to certain materials. The word "piezoelectricity" literally means "electricity from pressure." When pressure displaces positive and negative charges in otherwise neutral materials, a voltage is created. Common applications include electric cigarette lighters, where a spring-loaded hammer strikes a piezoelectric crystal to generate sufficient voltage for ignition. Microphones and guitar pickups also utilize this principle, converting sound waves or vibrations into electrical signals.

4. **Heat EMF (Thermoelectric Effect)** utilizes the thermoelectric effect, where two dissimilar metals at different temperatures generate voltage. This occurs because electrons from the hot metal (negative side) tend to migrate toward the cold metal (positive side). Thermocouples in furnaces exemplify this principle—when the pilot light heats the thermocouple, it generates voltage that enables a safety relay to control gas flow. If the pilot light extinguishes, no voltage is produced, and the safety system prevents gas flow.

5. **Light EMF (Photovoltaic Effect)** employs the photovoltaic effect to convert light energy directly into electrical energy.[^64] Photovoltaic cells use semiconductor materials, typically silicon, which has four valence electrons. When light strikes these cells, the energy knocks electrons loose, allowing them to flow freely and create current. This technology has become increasingly important for renewable energy generation, as it produces electricity without requiring fossil fuels.

6. **Magnetism EMF (Electromagnetic Induction)** represents the primary source of electrical energy in modern power systems.[^47] [^48] When magnetic field lines are cut by a conductor, an EMF is generated. This principle powers steam turbines, hydroelectric dams, wind generators, and other large-scale electrical generation systems. The mechanical energy that moves conductors through magnetic fields gets converted into electrical energy that powers our electrical infrastructure.

> **Visual Aid Instruction:** Create an interactive animation showing electromagnetic induction with: 1) A magnet moving through a coil with visible magnetic field lines and resulting electron movement/current flow, 2) A coil moving through a static magnetic field, 3) A visualization of Lenz's Law showing induced current creating an opposing magnetic field, and 4) A simplified cutaway of a generator showing how rotation creates AC current. Include controls to adjust magnetic field strength and movement speed, with corresponding changes in induced voltage.

All six voltage production methods achieve the same fundamental goals: they impart energy to electrons, push electrons against electrostatic fields, and create electron surplus at one terminal while creating electron deficiency at another terminal. This charge separation stores energy that can later be used to perform useful work in electrical circuits.

> **Teaching Note**: Hands-on demonstrations of different voltage production methods can make these concepts more tangible for students. Simple experiments like creating a lemon battery (chemical), using a small solar cell (light), or demonstrating static electricity with balloons (friction) can help students connect theory with observable phenomena.

**Practice Questions**:

1. A circuit has 12 volts applied across a 100-ohm resistor. Calculate the current flowing through the resistor.

2. If the current in a circuit increases from 2 amperes to 6 amperes while the resistance remains constant at 5 ohms, what is the change in voltage?

3. A 50-foot length of copper wire has a resistance of 0.5 ohms. If you double the length of the wire to 100 feet (keeping all other factors the same), what will be its new resistance?

4. Identify the color code bands of a 470 ohm resistor with ±10% tolerance using the four-band system.

5. Which voltage generation method is most commonly used in large-scale power plants? Explain how it works.

3. **Circuit Components and Analysis**
   - Basic Circuit Components
   - Series Circuit Analysis
   - Parallel Circuit Analysis
   - Series-Parallel Circuits

## Section 3: Circuit Components and Analysis

### Basic Circuit Components

Electrical circuits consist of interconnected components that work together to perform specific functions. Understanding the purpose and behavior of these components provides the foundation for analyzing and designing electrical systems. The four basic elements found in virtually all electrical circuits include power sources, loads, conductors, and control devices.

**Power Sources** generate the voltage necessary for circuit operation. They convert various forms of energy into electrical energy and maintain potential difference within circuits. Common power sources include:

- **Batteries** create voltage through chemical reactions. They provide direct current (DC) that flows in only one direction. Batteries range from small button cells for watches to large industrial units for backup power systems.

- **Generators** produce voltage through electromagnetic induction. Large generators in power plants use steam, water, or wind to rotate conductors through magnetic fields, inducing substantial voltages that power entire cities.

- **Solar cells** convert light energy directly into electrical energy through the photovoltaic effect. These are increasingly used in sustainable energy applications, from small calculator cells to large-scale solar farms.

**Loads** consume electrical energy, converting it into other energy forms. These components represent the "work" part of electrical circuits, where electrical energy transforms into desired outputs. Common loads include:

- **Resistive loads** convert electrical energy directly into heat. Examples include heating elements, light bulbs, and toasters.

- **Inductive loads** create and store energy in magnetic fields. Examples include motors, transformers, and relays. These devices often contain wire coils that generate magnetic fields when current flows through them.

- **Capacitive loads** store electrical energy in electric fields. Examples include timing circuits and power factor correction systems. These devices consist of conductive plates separated by insulating materials.

**Conductors** provide paths for current flow between components. These materials offer minimal resistance to current flow and maintain circuit continuity. Common conductors include:

- **Copper wire** serves as the standard electrical conductor in most applications due to its excellent conductivity, reasonable cost, and good mechanical properties.

- **Aluminum wire** provides a lighter, less expensive alternative to copper, although it has higher resistance and requires special connection techniques.

- **Printed circuit traces** consist of copper foil bonded to insulating substrates, creating conductive paths for electronic devices.

**Control Devices** regulate current flow within circuits, enabling or disabling specific paths based on desired operations. These components provide the means to control electrical systems. Common control devices include:

- **Switches** create or break circuit paths manually or automatically. They range from simple toggle switches to complex relays and contactors for industrial applications.

- **Circuit breakers** protect circuits by automatically interrupting current flow during overload or fault conditions. Unlike fuses, they can be reset after addressing the cause of the overcurrent.

- **Fuses** sacrifice themselves to protect circuits.[^55] [^57] These safety devices contain metal elements that melt when current exceeds their rating, permanently breaking the circuit path until replaced.

Beyond these four basic elements, practical circuits often incorporate specialized components to achieve specific functions:

> **Visual Aid Instruction:** Create a visual reference chart showing common circuit components (resistors, capacitors, inductors, diodes, transistors), their schematic symbols, their physical appearance, color code interpretations for resistors, and polarity markings for capacitors and diodes.

- **Diodes** allow current flow in only one direction. These semiconductor devices enable AC-to-DC conversion in power supplies and signal rectification in electronics.

- **Transistors** amplify or switch electronic signals. These three-terminal semiconductor devices serve as the foundation of modern electronics, enabling computers, smartphones, and countless other devices.

- **Integrated circuits** combine multiple electronic components on single semiconductor chips. These range from simple operational amplifiers to complex microprocessors containing billions of transistors.

> **Teaching Note**: When introducing circuit components, physical demonstrations with real components help students connect abstract concepts with tangible objects. Creating a "parts identification" exercise with actual components can significantly enhance learning retention.

### Series Circuit Analysis

A **series circuit** provides exactly one path for current flow, with all components connected end-to-end in a single continuous loop.[^50] [^52] [^74] This configuration creates a dependency where all components share the same current throughout the entire circuit. Understanding series circuit characteristics and analysis techniques enables proper design and troubleshooting of these fundamental circuit arrangements.

In series circuits, several key properties determine overall behavior:

**Current** remains constant throughout a series circuit. Since there is only one path for electrons to follow, the same number of electrons must pass through each component in a given time period. This principle can be expressed as:

$I_T = I_1 = I_2 = I_3 = ... = I_n$

where $I_T$ represents the total circuit current, and $I_1$, $I_2$, etc., represent current through individual components.

**Voltage** divides across components in a series circuit. The source voltage distributes across all components proportionally to their resistance. This voltage division follows the principle that the sum of voltage drops across all components equals the total source voltage:

$V_T = V_1 + V_2 + V_3 + ... + V_n$

where $V_T$ represents the total source voltage, and $V_1$, $V_2$, etc., represent voltage drops across individual components.

**Resistance** in series circuits combines additively. The total resistance equals the sum of all individual resistances in the circuit:

$R_T = R_1 + R_2 + R_3 + ... + R_n$

where $R_T$ represents the total circuit resistance, and $R_1$, $R_2$, etc., represent individual component resistances.

These three relationships form the foundation for analyzing series circuits. For example, if we know the source voltage and the value of each resistor in a series circuit, we can calculate the total resistance, the current through the circuit, and the voltage drop across each resistor.

**Example Problem**:  
Consider a series circuit containing a 24V battery and three resistors: $R_1 = 100 \Omega$, $R_2 = 220 \Omega$, and $R_3 = 330 \Omega$.

1. Calculate the total resistance:  
   $R_T = R_1 + R_2 + R_3 = 100\Omega + 220\Omega + 330\Omega = 650\Omega$

2. Calculate the circuit current:  
   $I = V_T / R_T = 24V / 650\Omega = 0.037A = 37mA$

3. Calculate the voltage drop across each resistor:  
   $V_1 = I \times R_1 = 0.037A \times 100\Omega = 3.7V$  
   $V_2 = I \times R_2 = 0.037A \times 220\Omega = 8.14V$  
   $V_3 = I \times R_3 = 0.037A \times 330\Omega = 12.21V$

4. Verify that voltage drops sum to source voltage:  
   $V_1 + V_2 + V_3 = 3.7V + 8.14V + 12.21V = 24.05V$ (approximately 24V, with slight rounding error)

Series circuits demonstrate predictable behaviors that impact their practical applications:

- **If one component fails open**: The entire circuit becomes non-functional because the path for current flow is broken. This behavior explains why traditional Christmas lights (wired in series) would completely fail if one bulb burned out.

- **Adding components to a series circuit**: Each additional component increases total resistance, resulting in decreased circuit current. This relationship explains why adding too many devices in series can result in insufficient current for proper operation.

- **Voltage divider applications**: Series circuits can intentionally divide voltage for specific applications, such as creating reference voltages or level-shifting in electronic circuits.

> **Analogy**: A series circuit can be compared to a single-lane mountain road. All traffic must follow the same path, and if there's a blockage anywhere (like a fallen tree), no vehicles can get through. Similarly, all current must follow the single path in a series circuit, and if any component fails open, no current can flow anywhere in the circuit.

### Parallel Circuit Analysis

A **parallel circuit** provides multiple paths for current flow, with components connected across the same two points in a circuit.[^51] [^52] [^74] This configuration creates independence between pathways, allowing current to divide among available paths. Understanding parallel circuit characteristics enables proper design and troubleshooting of these widely used circuit arrangements.

> **Visual Aid Instruction:** Create an interactive comparison of series vs. parallel circuits showing: 1) Side-by-side circuit diagrams with identical components in both configurations, 2) Animated current flow with arrows showing the single path in series circuits vs. multiple paths in parallel circuits, 3) Voltage and current distribution visualization with color intensity showing relative values at different points, 4) Interactive simulation where students can add/remove components or modify component values and immediately see effects on current, voltage, and power in each component, and 5) Fault scenarios showing what happens when components fail open or short in each configuration. Include equivalent circuit calculations with step-by-step visual representations.

In parallel circuits, several key properties determine overall behavior:

**Voltage** remains the same across all components in a parallel circuit. Since each component connects directly across the same two points, each experiences the same potential difference. This principle can be expressed as:

$V_T = V_1 = V_2 = V_3 = ... = V_n$

where $V_T$ represents the source voltage, and $V_1$, $V_2$, etc., represent voltage across individual components.

**Current** divides among the parallel paths proportionally to the conductance of each path. The total current equals the sum of currents through all parallel branches:

$I_T = I_1 + I_2 + I_3 + ... + I_n$

where $I_T$ represents the total circuit current, and $I_1$, $I_2$, etc., represent current through individual components.

**Resistance** in parallel circuits combines according to the reciprocal relationship. The reciprocal of total resistance equals the sum of reciprocals of all individual resistances:

$\frac{1}{R_T} = \frac{1}{R_1} + \frac{1}{R_2} + \frac{1}{R_3} + ... + \frac{1}{R_n}$

For the special case of just two resistors in parallel, the formula simplifies to:

$R_T = \frac{R_1 \times R_2}{R_1 + R_2}$

These three relationships form the foundation for analyzing parallel circuits. For example, if we know the source voltage and the value of each resistor in a parallel circuit, we can calculate the total resistance, the total current, and the current through each branch.

**Example Problem**:  
Consider a parallel circuit containing a 12V battery and three resistors: $R_1 = 30 \Omega$, $R_2 = 60 \Omega$, and $R_3 = 120 \Omega$.

1. Calculate the total resistance:  
   $\frac{1}{R_T} = \frac{1}{30\Omega} + \frac{1}{60\Omega} + \frac{1}{120\Omega} = \frac{4}{120\Omega} + \frac{2}{120\Omega} + \frac{1}{120\Omega} = \frac{7}{120\Omega}$  
   $R_T = \frac{120\Omega}{7} = 17.14\Omega$

2. Calculate the total current:  
   $I_T = V_T / R_T = 12V / 17.14\Omega = 0.7A = 700mA$

3. Calculate the current through each resistor:  
   $I_1 = V / R_1 = 12V / 30\Omega = 0.4A = 400mA$  
   $I_2 = V / R_2 = 12V / 60\Omega = 0.2A = 200mA$  
   $I_3 = V / R_3 = 12V / 120\Omega = 0.1A = 100mA$

4. Verify that branch currents sum to total current:  
   $I_1 + I_2 + I_3 = 400mA + 200mA + 100mA = 700mA = I_T$

Parallel circuits demonstrate predictable behaviors that impact their practical applications:

- **If one component fails open**: The other components continue to function normally because current still has alternative paths. This behavior explains why household outlets can operate independently—each represents a parallel branch in your home's electrical system.

- **Adding components to a parallel circuit**: Each additional component decreases total resistance, resulting in increased circuit current. This relationship explains why adding too many devices in parallel can overload a circuit.

- **Current divider applications**: Parallel circuits can intentionally divide current for specific applications, such as creating current shunts for measurement or protection.

**Parallel circuits offer several advantages over series circuits**:

1. **Reliability**: If one component fails, others continue to operate.
2. **Independent operation**: Components can be switched on or off individually without affecting others.
3. **Consistent voltage**: All components receive the same voltage, ensuring proper operation regardless of their position in the circuit.

**However, parallel circuits also present challenges**:

1. **Higher current requirements**: The total current drawn from the source increases with each parallel branch.
2. **Potential overloading**: Power sources must be rated to handle the combined current of all parallel branches.
3. **Short circuit risk**: A short circuit across any branch can draw excessive current and damage the power source.

> **Analogy**: A parallel circuit resembles a multi-lane highway where traffic can choose different routes to reach the same destination. If one lane closes (component fails), traffic can still flow through the other lanes. Similarly, current in a parallel circuit has multiple paths, and if one path is blocked, current continues to flow through the other available paths.

### Series-Parallel Circuits

**Series-parallel circuits** combine series and parallel connections within a single circuit, creating configurations where some components connect in series while others connect in parallel. These complex arrangements appear in most practical electrical and electronic systems, from household wiring to sophisticated electronic devices. Analyzing these circuits requires a systematic approach that breaks down the circuit into manageable sections.

When analyzing series-parallel circuits, the key strategies involve:

1. **Circuit Reduction**: Simplify the circuit by identifying and reducing pure series or parallel sections one step at a time.

2. **Block Analysis**: Treat sections of the circuit as "blocks" with equivalent resistance values, then analyze how these blocks connect to each other.

3. **Step-by-Step Calculation**: Start with the innermost combinations and work outward, applying series and parallel formulas as appropriate.

**Example Analysis**:  
Consider a circuit with a 24V source and the following configuration:
- Resistor R1 (10Ω) in series with a parallel combination of R2 (30Ω) and R3 (60Ω)

To analyze this circuit, we follow these steps:

1. Calculate the equivalent resistance of the parallel combination of R2 and R3:  
   $R_{23} = \frac{R_2 \times R_3}{R_2 + R_3} = \frac{30\Omega \times 60\Omega}{30\Omega + 60\Omega} = \frac{1800\Omega}{90\Omega} = 20\Omega$

2. Calculate the total resistance by adding R1 to the equivalent resistance R23:  
   $R_T = R_1 + R_{23} = 10\Omega + 20\Omega = 30\Omega$

3. Calculate the total current:  
   $I_T = \frac{V}{R_T} = \frac{24V}{30\Omega} = 0.8A = 800mA$

4. Since R1 is in series with the rest of the circuit, the current through R1 equals the total current:  
   $I_1 = I_T = 800mA$

5. Calculate the voltage drop across R1:  
   $V_1 = I_1 \times R_1 = 0.8A \times 10\Omega = 8V$

6. Calculate the voltage across the parallel section (R2 and R3):  
   $V_{23} = I_T \times R_{23} = 0.8A \times 20\Omega = 16V$
   Alternatively, $V_{23} = V_T - V_1 = 24V - 8V = 16V$

7. Calculate the current through each parallel resistor:  
   $I_2 = \frac{V_{23}}{R_2} = \frac{16V}{30\Omega} = 0.533A = 533mA$  
   $I_3 = \frac{V_{23}}{R_3} = \frac{16V}{60\Omega} = 0.267A = 267mA$

8. Verify that parallel branch currents sum to the current entering the parallel section:  
   $I_2 + I_3 = 533mA + 267mA = 800mA = I_T$

Series-parallel circuits appear in many practical applications:

- **Voltage Divider with Load**: A series voltage divider feeding a load creates a series-parallel circuit. The load appears in parallel with part of the divider, affecting the division ratio.

- **Wheatstone Bridge**: This circuit uses series-parallel arrangements to detect small resistance changes in sensors and measurement devices.

- **Audio Crossover Networks**: These circuits use series-parallel arrangements of capacitors and inductors to direct different frequencies to appropriate speakers.

- **Power Distribution Systems**: Electrical panels distribute power in parallel to different circuits, but each circuit may have multiple devices wired in series or series-parallel arrangements.

When troubleshooting series-parallel circuits, a systematic approach helps identify faults efficiently:

1. **Voltage Measurements**: Check voltages at key points, comparing against expected values.

2. **Current Path Tracing**: Identify the paths current should follow and verify continuity.

3. **Component Isolation**: When possible, isolate sections for individual testing.

4. **Effects Analysis**: Understand how a failure in one section would affect measurements in other sections.

> **Teaching Note**: When teaching series-parallel circuits, using color-coded diagrams helps students visualize current paths. Start with simple configurations and gradually introduce more complex arrangements. Physical circuit demonstrations with measurement tools provide hands-on experience that reinforces conceptual understanding.

**Practice Questions**:

1. In a series-parallel circuit, a 12V source powers two parallel branches. Branch 1 has a single 8Ω resistor, while Branch 2 has two 6Ω resistors in series. Calculate the total current from the source.

2. A 100Ω resistor is in series with a parallel combination of a 200Ω resistor and a 300Ω resistor. If the circuit is connected to a 24V source, what is the voltage across the 100Ω resistor?

3. Draw a series-parallel circuit with at least 5 resistors that has an equivalent resistance of exactly 50Ω. Label all resistor values and show your calculations.

4. In a household circuit, a lamp (60Ω), a heater (20Ω), and a fan (40Ω) are connected in parallel. This parallel combination is protected by a 15A fuse. Will the fuse blow if all devices are turned on simultaneously with a 120V supply? Show your calculations.

4. **Measurement Techniques and Tools**
   - Electrical Meters and Safety Precautions
   - Measuring Voltage, Current, and Resistance
   - Troubleshooting Common Circuit Problems

## Section 4: Measurement Techniques and Tools

### Electrical Meters and Safety Precautions

Electrical measurement tools allow technicians to observe and quantify circuit parameters that would otherwise remain invisible. These tools provide critical data for circuit analysis, troubleshooting, and maintenance. Before examining specific measurement techniques, understanding the basic tools and the safety precautions for using them is essential.

**Digital Multimeters (DMMs)** represent the most versatile and commonly used measurement tools in electrical work.[^54] [^56] These portable devices combine multiple measurement functions in a single unit, including:

> **Visual Aid Instruction:** Generate a series of images demonstrating proper DMM probe placement for voltage measurement (parallel), proper DMM probe placement for current measurement (series), proper DMM probe placement for resistance measurement (isolated component), safety precautions (hand positions, insulation requirements), and common mistakes to avoid (with X marks).

- **Voltmeter**: Measures potential difference between two points
- **Ammeter**: Measures current flow through a circuit
- **Ohmmeter**: Measures resistance of components or circuits
- **Continuity Tester**: Verifies the presence of a complete electrical path
- **Diode Tester**: Checks semiconductor junction functionality
- **Capacitance Meter**: Measures capacitor values

Modern DMMs offer additional features like frequency measurement, temperature sensing, and transistor testing. They typically display readings on digital screens and may include advanced functions like data logging, auto-ranging, and maximum/minimum value tracking.

**Safety Precautions** for electrical measurements are critical because improper use of meters can result in equipment damage, inaccurate readings, electric shock, or even fatalities. The following safety guidelines should always be observed:

1. **Verify meter ratings**: Ensure the meter's voltage, current, and category ratings exceed the circuit parameters being measured. Measurement categories (CAT I through CAT IV) indicate the meter's ability to withstand transient voltages—always match or exceed the environment's category rating.

2. **Inspect equipment**: Before use, check meters and test leads for damage, including cracked cases, exposed metal, frayed wires, or damaged insulation. Never use damaged equipment.

3. **Use appropriate test leads**: Ensure test leads have the correct voltage rating, are properly insulated, and have shrouded connectors to prevent accidental contact with live parts.

4. **Observe proper connection sequence**:
   - Connect leads to the meter first
   - Select the proper function and range
   - Then connect to the circuit being tested
   - When disconnecting, remove leads from the circuit first, then from the meter

5. **Use one hand when practical**: The "one-hand rule" involves keeping one hand behind your back or in your pocket when making measurements, reducing the risk of current passing through your heart if accidental contact occurs.

6. **Position the body correctly**: Stand on an insulated surface, avoid contact with grounded objects, and maintain stable footing to prevent falls that could result in contact with live circuits.

7. **De-energize circuits when possible**: Whenever practical, turn off power before connecting or disconnecting test equipment. When working on circuits that cannot be de-energized, use extreme caution and appropriate personal protective equipment (PPE).

8. **Never measure current in parallel**: Always connect ammeters in series with the circuit being tested, never across a voltage source. This improper connection creates a short circuit that can damage the meter and cause injury.

9. **Use appropriate meter functions**: When measuring unknown values, start with the highest range and work down to avoid overloading the meter. When finished with current measurements, switch to voltage mode to prevent accidental insertion of the ammeter into a voltage source.

10. **Discharge capacitors**: Before testing in circuits containing capacitors, ensure they are fully discharged to prevent unexpected high currents or voltages.

> **Teaching Note**: Create a "safety checklist" that students must review before performing any electrical measurements. Consider role-playing scenarios where students identify safety violations in example setups. Emphasize that no measurement is worth risking personal safety.

### Measuring Voltage, Current, and Resistance

Accurate electrical measurements require not just the correct tools but also proper measurement techniques. Understanding how to properly connect meters and interpret readings enables effective circuit analysis and troubleshooting.

**Voltage Measurement** involves determining the electrical potential difference between two points in a circuit.[^24] [^69] Proper voltage measurement techniques include:

1. **Select the appropriate function and range**: Choose AC or DC voltage mode based on the circuit type. If the approximate voltage is unknown, start with the highest range and work down to avoid damage to the meter.

2. **Connect the meter in parallel**: Voltmeters must always connect across (in parallel with) the component or circuit section being measured. This arrangement subjects the meter to the voltage being measured without significantly affecting circuit operation.

3. **Maintain correct polarity for DC**: For DC measurements, the red lead connects to the positive point and the black lead to the negative point. Incorrect polarity will result in negative readings on most digital meters.

4. **Consider the meter's loading effect**: While voltmeters are designed with high internal resistance to minimize their impact on circuits, some high-impedance circuits may still be affected. For these circuits, high-impedance meters (typically 10 megohms or greater) are preferable.

**Current Measurement** determines the rate of charge flow through a specific point in a circuit. Proper current measurement techniques include:

> **Visual Aid Instruction:** Create a comparative visualization of measurement techniques showing: 1) Proper DMM connections for measuring voltage (parallel), current (series), and resistance (isolated component) with circuit diagrams and real-world setup photos side-by-side, 2) Common mistakes to avoid with clear X marks and explanations of potential damage, 3) Step-by-step animated procedure for safely measuring each quantity, and 4) Clamp meter usage for non-invasive current measurement. Include a troubleshooting decision tree for interpreting unexpected measurement results.

1. **Break the circuit**: Unlike voltage measurements, current measurements require breaking the circuit and inserting the meter in the path where current flows.

2. **Connect the meter in series**: Place the ammeter in line with the current path, ensuring all current flows through the meter.

3. **Select the appropriate function and range**: Choose AC or DC current mode based on the circuit type. If the approximate current is unknown, start with the highest range and work down.

4. **Be mindful of the meter's burden voltage**: Ammeters introduce a small voltage drop (burden voltage) that can affect low-voltage circuits. High-quality meters minimize this effect.

5. **Consider alternative methods**: For very high currents or when breaking the circuit is impractical, consider using a clamp meter, which measures current by sensing the magnetic field around a conductor without requiring circuit interruption.

**Resistance Measurement** determines the opposition to current flow in components or circuit sections. Proper resistance measurement techniques include:

1. **Ensure the circuit is de-energized**: Always disconnect power and discharge capacitors before measuring resistance. Attempting to measure resistance in a live circuit can damage the meter and provide inaccurate readings.

2. **Isolate the component**: When possible, disconnect at least one end of the component being measured from the circuit to prevent parallel paths from affecting the reading.

3. **Select the appropriate range**: Choose a range that will provide a reading near the middle of the scale for maximum accuracy. Most digital multimeters now feature auto-ranging, which automatically selects the optimal range.

4. **Check for zero and infinity**: Before taking critical measurements, verify the meter's calibration by shorting the test leads together (should read zero ohms) and then separating them (should read overload or infinity).

5. **Consider the effect of temperature**: Remember that resistance in many materials, particularly metals, changes with temperature. For precision measurements, note the ambient temperature or use temperature-compensated methods.

6. **Be aware of capacitor effects**: When measuring resistance in circuits with capacitors, the reading may start low and gradually increase as the capacitor charges through the meter's internal voltage source.

> **Analogy**: Voltage, current, and resistance measurements can be compared to water flow measurements:
> - Measuring voltage is like measuring water pressure between two points with a pressure gauge (without affecting the flow).
> - Measuring current is like inserting a flow meter into the pipe that all water must pass through.
> - Measuring resistance is like measuring how restricted a pipe is, which must be done without water flowing through it.

### Troubleshooting Common Circuit Problems

Troubleshooting involves systematically identifying and resolving electrical problems using a combination of knowledge, measurement techniques, and logical deduction.[^52] [^53] An effective troubleshooting approach follows a structured methodology while adapting to specific situations.

**The Troubleshooting Process** typically involves these steps:

1. **Gather information**: Collect details about the problem, including when it started, any unusual sounds or smells, intermittent nature, and operating conditions. For complex equipment, consult documentation or schematics.

2. **Verify the problem**: Confirm that a problem actually exists and understand its exact nature through direct observation or testing.

3. **Identify possible causes**: Based on symptoms and circuit knowledge, develop a list of potential causes, from most to least likely.

4. **Test and narrow possibilities**: Use appropriate measurements to systematically eliminate possibilities until the cause is identified.

5. **Implement solution**: Repair, replace, or adjust components as needed to resolve the problem.

6. **Verify repair**: Test the circuit under normal operating conditions to ensure the problem is fully resolved.

**Common Circuit Problems** and their troubleshooting approaches include:

1. **No power or function**:
   - Check for voltage at the power source
   - Verify continuity of power conductors
   - Test switches and circuit protection devices
   - Measure voltage at the load
   - Look for broken connections or open components

   *Measurement approach*: Start with voltage measurements at various points along the power path to identify where voltage is lost.

2. **Overheating components**:
   - Check for current draw exceeding component ratings
   - Verify proper ventilation and cooling
   - Look for signs of physical damage or discoloration
   - Test for partial short circuits causing excessive current paths

   *Measurement approach*: Measure current draw and compare to specifications. Use a thermal camera or temperature probe if available.

3. **Intermittent operation**:
   - Look for loose connections that may make or break contact
   - Check for components that might be temperature sensitive
   - Test for voltage fluctuations under varying loads
   - Inspect for corroded or contaminated contacts

   *Measurement approach*: Monitor voltage or resistance over time, potentially while flexing or tapping components to reveal intermittent connections.

4. **Incorrect output values**:
   - Verify input signals are correct
   - Check power supply voltages for proper regulation
   - Test components in the signal path for proper operation
   - Look for interference or loading effects

   *Measurement approach*: Trace signals through the circuit, measuring at each stage to identify where values deviate from expected readings.

**Diagnostic Tools and Techniques** beyond basic multimeter measurements include:[^54] [^56]

> **Visual Aid Instruction:** Create an interactive decision tree for troubleshooting that starts with symptoms (no power, intermittent operation, etc.), branches to possible causes, suggests measurement points and expected readings, provides recommended solutions, and allows clicking through different paths.

1. **Signal generators** provide controlled inputs to test circuit response under various conditions. They can produce various waveforms (sine, square, triangle) at different frequencies and amplitudes.

2. **Oscilloscopes** display voltage waveforms over time, allowing visualization of signal characteristics, including shape, amplitude, frequency, and noise. Modern digital oscilloscopes offer advanced features like automatic measurements, triggering options, and data storage.

3. **Logic analyzers** capture and display multiple digital signals simultaneously, essential for troubleshooting digital circuits and microprocessor-based systems.

4. **Thermal imaging** identifies hot spots that might indicate excessive current flow or high-resistance connections before they cause complete failure.

5. **Network analyzers** measure the network parameters of electrical networks, particularly useful for high-frequency circuit testing and RF applications.

**Documentation and Record-Keeping** play crucial roles in effective troubleshooting. Maintaining detailed records of problems, tests performed, and solutions implemented creates valuable resources for future troubleshooting and can reveal patterns indicating systemic issues rather than isolated failures.

> **Teaching Note**: Develop troubleshooting exercises where students identify deliberately introduced faults in simple circuits. Start with single faults and progress to multiple issues. Encourage students to document their thought process and measurements rather than focusing solely on finding the solution.

**Practice Questions**:

1. When measuring the current flowing through an LED in a circuit, would you place the multimeter in series or in parallel with the LED? Explain your answer.

2. A technician needs to measure the voltage drop across a resistor in a powered circuit. Describe the proper procedure, including safety precautions and meter settings.

3. When troubleshooting a circuit with no power, a technician measures 120V at the power source but 0V at the load. List three potential problems that could cause this symptom and describe how you would test for each one.

4. Describe how you would safely measure the resistance of a capacitor in a circuit. What precautions must be taken, and what would you expect to observe on the meter during the measurement?

5. **Power and Energy Relationships**
   - Calculating Electrical Power
   - Energy Consumption and Efficiency
   - Power Loss in Circuits

## Section 5: Power and Energy Relationships

### Calculating Electrical Power

**Electrical power** represents the rate at which electrical energy is transferred or converted in a circuit.[^30] [^32] It measures how quickly electrical energy is used by a component or supplied by a source. Understanding power concepts is essential for designing systems that can safely and efficiently deliver the required energy.

The standard unit of electrical power is the **watt (W)**, named after Scottish inventor James Watt. One watt represents the rate at which work is done when one ampere of current flows through a potential difference of one volt. For larger power values, kilowatts (kW = 1,000 watts) and megawatts (MW = 1,000,000 watts) are commonly used.

There are three fundamental equations for calculating electrical power, each useful in different situations:[^30] [^33]

> **Visual Aid Instruction:** Create an interactive power triangle showing the relationship between real power (P), reactive power (Q), and apparent power (S), power factor angle, and vector representation. Include sliders to adjust values and see how others change.

1. **Power from voltage and current**: The most basic power calculation multiplies voltage and current:
   $P = V \times I$

   Where:
   - $P$ is power in watts
   - $V$ is voltage in volts
   - $I$ is current in amperes

   This equation applies to both AC and DC circuits and components of any type (resistive, inductive, or capacitive).

2. **Power from current and resistance**: In purely resistive circuits, power can be calculated from current and resistance:
   $P = I^2 \times R$

   Where:
   - $P$ is power in watts
   - $I$ is current in amperes
   - $R$ is resistance in ohms

   This formula is particularly useful when voltage is unknown but current and resistance values are available.

3. **Power from voltage and resistance**: Alternatively, power can be calculated from voltage and resistance:
   $P = \frac{V^2}{R}$

   Where:
   - $P$ is power in watts
   - $V$ is voltage in volts
   - $R$ is resistance in ohms

   This formula is convenient when current is unknown but voltage and resistance values are available.

**Example Problem**:  
A 120V hair dryer draws 8.3 amperes of current. Calculate:

a) The power consumption in watts
   $P = V \times I = 120V \times 8.3A = 996W$

b) The resistance of the heating element
   $R = \frac{V}{I} = \frac{120V}{8.3A} = 14.46\Omega$

c) Verify the power using the resistance formula
   $P = \frac{V^2}{R} = \frac{(120V)^2}{14.46\Omega} = \frac{14,400V^2}{14.46\Omega} = 996W$

In AC circuits, **power factor** becomes important in power calculations because voltage and current may not be in phase. The power factor (PF) represents the ratio of real power (that performs work) to apparent power (the product of voltage and current):

> **Visual Aid Instruction:** Create an interactive AC power visualization showing: 1) Animated sine waves of voltage and current with adjustable phase shift, 2) Real-time calculation of real power, reactive power, and apparent power as waveforms change, 3) Dynamic power triangle that updates as phase angle changes with vectors showing the relationship between power types, 4) Split-screen comparison of purely resistive (PF=1), inductive, and capacitive loads with corresponding waveforms and power triangles, 5) Phasor diagrams showing voltage and current relationships, and 6) Interactive slider to demonstrate power factor correction with capacitors and its effect on system efficiency. Include animated power flow showing useful vs. non-useful energy transfer.

$PF = \frac{\text{Real Power (watts)}}{\text{Apparent Power (volt-amperes)}} = \cos\theta$

Where $\theta$ is the phase angle between voltage and current. For purely resistive loads, the power factor equals 1.0 (or 100%), meaning all power is used productively. Inductive or capacitive loads have lower power factors, resulting in some power being unusable.

With power factor considered, the AC power equation becomes:
$P = V \times I \times PF$

> **Teaching Note**: Power calculations offer excellent opportunities to reinforce Ohm's Law relationships. Create exercises where students must determine which power formula to use based on available information, reinforcing their ability to manipulate equations appropriately.

### Energy Consumption and Efficiency

**Electrical energy** represents the capacity to do work through electrical means. It measures the total amount of electrical work performed over a specific time period. While power indicates the rate of energy transfer at any moment, energy quantifies the total electrical work done over time.

The standard unit of electrical energy is the **joule (J)**. However, for practical electrical applications, the **kilowatt-hour (kWh)** is more commonly used, especially in utility billing. One kilowatt-hour represents the energy consumed when one kilowatt of power is used for one hour.

To calculate electrical energy consumption:

$E = P \times t$

Where:
- $E$ is energy in watt-hours (or kilowatt-hours if power is in kilowatts)
- $P$ is power in watts (or kilowatts)
- $t$ is time in hours

**Example Problem**:  
A 1,500W space heater operates for 3 hours each day during winter months. Calculate:

a) The daily energy consumption
   $E = P \times t = 1.5kW \times 3h = 4.5kWh$

b) The monthly energy consumption (30 days)
   $E_{monthly} = 4.5kWh \times 30 = 135kWh$

c) The monthly cost at $0.12 per kWh
   $Cost = Energy \times Rate = 135kWh \times \$0.12/kWh = \$16.20$

**Electrical efficiency** measures how effectively electrical energy is converted into the desired output form (light, heat, mechanical motion, etc.). It compares useful output energy to the total input energy, expressed as a percentage:

$Efficiency = \frac{Output\,Energy}{Input\,Energy} \times 100\%$

For electrical devices, this often becomes:

$Efficiency = \frac{Output\,Power}{Input\,Power} \times 100\%$

All electrical conversions involve some energy loss, typically as heat. Modern electrical devices have widely varying efficiencies:

- Incandescent light bulbs: 5-10% (90-95% of energy becomes heat, not light)
- LED lighting: 75-90% (much more energy becomes light)
- Electric motors: 60-96% (varies by size and design)
- Power transformers: 95-99% (very efficient energy transfer)

**Energy conservation** involves reducing energy consumption through more efficient devices or altered usage patterns. Conservation strategies include:

1. **Replacing inefficient devices**: Upgrading to LED lighting, Energy Star appliances, or variable-frequency drive motors.

2. **Using controls and automation**: Implementing timers, occupancy sensors, or smart power management systems to operate equipment only when needed.

3. **Proper maintenance**: Keeping equipment clean, lubricated, and properly adjusted to maintain optimal efficiency.

4. **Load management**: Scheduling energy-intensive operations during off-peak hours or distributing loads to prevent excessive demand charges.

5. **Power factor correction**: Installing capacitors or other compensation devices to improve power factor in industrial settings, reducing wasted energy.

**Practical considerations for energy consumption** include understanding demand charges, peak rates, and power quality issues that can affect both energy costs and equipment longevity. Many utility companies charge commercial customers not just for total energy consumed but also for their peak power demand during a billing cycle, making load management economically significant.

> **Analogy**: The relationship between power and energy is like the speedometer and odometer in a car. The speedometer shows your current rate of travel (like power shows your current rate of energy use), while the odometer accumulates the total distance traveled (like energy measures the total electrical work done over time).

### Power Loss in Circuits

**Power loss** in electrical systems often manifests as heat generation, where electrical energy converts to thermal energy through resistance.[^36] [^38] This phenomenon, known as I²R loss or Joule heating, affects everything from transmission lines to household appliances. Understanding power loss helps engineers design efficient systems that minimize wasted energy.

In purely resistive components, all electrical energy converts to heat through a process called **Joule heating** or **I²R losses**. This power dissipation can be calculated using any of the power formulas:

$P_{loss} = I^2 \times R = V \times I = \frac{V^2}{R}$

Where:
- $P_{loss}$ is power loss in watts
- $I$ is current in amperes
- $R$ is resistance in ohms
- $V$ is voltage across the resistance in volts

For conductors like wires and cables, power loss is often undesirable but unavoidable. Key factors affecting conductor power loss include:

1. **Conductor material**: Different materials have different resistivities. Copper has lower resistivity than aluminum, resulting in less power loss for the same size conductor.

2. **Conductor length**: Longer conductors have proportionally higher resistance and greater power loss, following the relationship $R = \rho \times \frac{L}{A}$ where $\rho$ is resistivity, $L$ is length, and $A$ is cross-sectional area.

3. **Conductor diameter**: Larger diameter conductors have lower resistance per unit length, reducing power loss. Doubling a conductor's diameter reduces its resistance by a factor of four.

4. **Temperature**: Most metals' resistance increases with temperature, creating a compounding effect where initial heating causes increased resistance, leading to more heating.

5. **Current magnitude**: Since power loss is proportional to the square of current ($P = I^2R$), doubling current quadruples power loss.

This relationship explains why high-voltage transmission lines are used for long-distance power distribution. By increasing voltage and proportionally decreasing current for the same power level, transmission losses are significantly reduced.

**Example Calculation**:  
A 100-foot length of 12 AWG copper wire has approximately 0.16 ohms of resistance. If this wire carries 15 amperes:

Power loss = $I^2 \times R = (15A)^2 \times 0.16\Omega = 225 \times 0.16 = 36$ watts

For the same power transfer with a 240V circuit using 3.125A:

Power loss = $I^2 \times R = (3.125A)^2 \times 0.16\Omega = 9.77 \times 0.16 = 1.56$ watts

This demonstrates how higher voltage systems dramatically reduce power loss.

**In transformers and inductive components**, additional loss mechanisms include:[^45] [^71]

1. **Core losses** occur in the magnetic material and include:
   - **Hysteresis losses** from repeatedly magnetizing and demagnetizing the core material
   - **Eddy current losses** from circulating currents induced within the core material

2. **Copper losses** from the resistance of the wire windings (I²R losses)

Transformers are designed to minimize these losses through proper core material selection, lamination techniques, and appropriate conductor sizing. High-efficiency transformers achieve total losses of 1-2% of the power they transfer.

**Power loss management** techniques include:

1. **Proper conductor sizing**: Selecting conductors based on current requirements, acceptable voltage drop, and thermal considerations.

2. **Using higher voltages**: Transmitting power at higher voltages to reduce current and associated I²R losses.

3. **Reducing resistance**: Using materials with lower resistivity or operating components at lower temperatures.

4. **Thermal management**: Implementing cooling systems to dissipate heat and prevent temperature-related resistance increases.

5. **Power factor correction**: In AC systems, improving power factor reduces current magnitude for the same useful power, reducing I²R losses.

**Practical implications** of power loss extend beyond efficiency considerations:

1. **Heat generation**: Power loss manifests as heat, requiring proper ventilation, heat sinks, or cooling systems for components with significant losses.

2. **Voltage drop**: Power loss in conductors causes voltage to decrease along the conductor length, potentially leading to improper operation of connected equipment.

3. **Fire risk**: Excessive power loss can create dangerous thermal conditions, particularly with undersized conductors or loose connections.

4. **Economic impact**: Power losses represent wasted energy that must be paid for but performs no useful work.

> **Teaching Note**: Demonstrate power loss visually by showing how conductors heat up with current flow. A simple demonstration using different gauge wires connected to a battery can show how thinner wires heat up more quickly and dramatically than thicker ones carrying the same current.

**Practice Questions**:

1. A 1,200W microwave oven operates at 120V. Calculate the current it draws and the resistance of its heating element.

2. A household uses a 3,500W air conditioner for 8 hours per day. Calculate the monthly energy consumption and cost at $0.15/kWh.

3. If a DC motor draws 5A at 24V but produces only 105W of mechanical power output, calculate its efficiency.

4. Two conductors have the same length but different diameters; one is twice the diameter of the other. How do their resistances compare, and how would power loss compare if they carried the same current?

6. **Electrical Safety Principles**
   - Understanding Electric Shock
   - Grounding and Protection Mechanisms
   - Safe Practices for Working with Electricity

## Section 6: Electrical Safety Principles

### Understanding Electric Shock

**Electrical shock** occurs when a person becomes part of an electrical circuit, allowing current to flow through their body. This phenomenon can range from a barely perceptible sensation to a fatal event, depending on several factors. Understanding the physiological effects of electric shock provides crucial context for implementing safety measures.

The human body conducts electricity because it contains water and electrolytes that allow current flow. When current passes through the body, it can affect muscles, nerves, and vital organs, especially the heart. The severity of an electric shock depends primarily on three factors:

> **Visual Aid Instruction:** Create an interactive human body electrical safety visualization showing: 1) Human figure with common shock paths highlighted and color-coded by danger level (hand-to-hand through heart being red/most dangerous), 2) Effects of increasing current levels with physiological responses at each threshold (perception, pain, let-go, fibrillation) mapped directly on the body, 3) Comparative resistance values of wet vs. dry skin with current flow visualization, 4) Time-effect relationship showing how longer exposure increases damage severity, and 5) Interactive voltage/resistance calculator demonstrating how changes in skin condition and contact voltage affect resultant current through the body. Include medical illustrations of tissue damage at different current levels.

1. **Current magnitude**: The amount of current flowing through the body largely determines shock severity. Generally accepted physiological effects include:
   - 1 mA: Threshold of perception; barely detectable tingling sensation
   - 5-10 mA: Painful shock; muscular control maintained
   - 10-30 mA: "Let-go threshold" exceeded; cannot release grip from energized conductor
   - 30-50 mA: Respiratory paralysis possible; breathing may stop
   - 50-100 mA: Ventricular fibrillation possible; potentially fatal
   - 100+ mA: Ventricular fibrillation likely; severe burns and tissue damage
   - 1-5 A: Cardiac arrest, severe burns, and likely death

2. **Current path**: The path current takes through the body significantly affects the danger level. Currents passing through the heart or brain are particularly hazardous. Hand-to-hand or hand-to-foot paths are especially dangerous because they typically cross the chest cavity, potentially affecting the heart.

3. **Duration of contact**: Longer exposure to electrical current increases the damage, as electrical energy converts to heat in body tissues, causing burns and increasing the likelihood of cardiac effects.

Additional factors influencing electric shock severity include:

- **Frequency**: AC current at power frequencies (50-60 Hz) can be more dangerous than DC current of equal magnitude because AC can cause muscle tetanization (continuous contraction) and may interfere with heart rhythm. Very high-frequency currents tend to travel along the skin rather than through the body (skin effect).

- **Skin condition**: Dry skin has relatively high resistance (up to 100,000 ohms), while wet or broken skin has much lower resistance (as low as 1,000 ohms). Lower skin resistance allows more current to flow for a given voltage.

- **Voltage level**: While current causes the damage, higher voltage can push more current through body resistance. Contact with 120V household circuits can be fatal under the right circumstances, while contact with higher voltages significantly increases the danger.

Ohm's Law applies to the human body just as it does to any conductor. The current passing through a person can be calculated as:

$I = \frac{V}{R_{body}}$

where $R_{body}$ is the total resistance of the current path through the body, including skin resistance at contact points.

**Types of electrical injuries** include:

1. **Electrical burns**: These burns occur when electrical energy converts to heat in body tissues. They can be particularly severe because they damage tissue beneath the skin.

2. **Arc burns**: These occur when electrical current flows through the air between conductors or to ground, creating extremely high temperatures (up to 35,000°F/19,400°C).

3. **Thermal contact burns**: These result from contact with surfaces heated by electrical energy.

4. **Internal injuries**: Electrical current can cause serious internal damage not immediately visible from the outside.

> **Teaching Note**: To demonstrate the concept of body resistance without endangering students, use conductivity meters on various surfaces (dry vs. wet skin, callused vs. soft skin) to show resistance differences. Never apply voltage to students in demonstrations.

### Grounding and Protection Mechanisms

**Grounding** and protection systems redirect potentially dangerous currents away from people and sensitive equipment. These systems represent the first line of defense against electrical hazards and are required by electrical codes in most countries.

**Grounding** involves connecting electrical systems to the Earth, which serves as a reference point at zero potential. There are two primary types of grounding:

1. **System grounding** connects one conductor of an electrical system (typically the neutral) to Earth. This:
   - Stabilizes voltage levels within the system
   - Provides a path for fault current
   - Enables proper operation of overcurrent protective devices
   - Limits voltage rise during lightning strikes or utility faults

2. **Equipment grounding** connects non-current-carrying metal parts of electrical equipment to Earth. This:
   - Prevents dangerous voltage on equipment housings
   - Creates a low-resistance path for fault current
   - Enables protective devices to detect and clear faults

In residential and commercial electrical systems, the typical grounding system includes:

- A **grounding electrode** (often a rod driven into the earth or connection to a metal water pipe)
- A **grounding electrode conductor** connecting the electrode to the system
- A **main bonding jumper** connecting the neutral to the grounding system
- **Equipment grounding conductors** (typically green or bare copper) connecting equipment to the grounding system

**Protection mechanisms** work with proper grounding to detect abnormal conditions and prevent or minimize shock hazards.[^55] [^57] Key protective devices include:

> **Visual Aid Instruction:** Create visuals of essential safety equipment: insulated tools with ratings, personal protective equipment (gloves, face shields), warning signs and lockout/tagout devices, GFCIs and AFCIs with internal mechanism exposed, and proper grounding techniques with color-coded wires.

1. **Circuit breakers** detect overcurrent conditions (overloads or short circuits) and automatically disconnect the circuit. They operate on electromagnetic or thermal principles and can be reset after the fault is cleared.

2. **Fuses** provide similar overcurrent protection but function by melting a metal element when current exceeds their rating. Once activated, fuses must be replaced.

3. **Ground Fault Circuit Interrupters (GFCIs)** monitor the current balance between hot and neutral conductors.[^57] When a ground fault occurs (current taking an unintended path to ground, possibly through a person), the GFCI detects the imbalance and quickly interrupts the circuit, typically within 1/40th of a second. GFCIs are particularly important in wet locations like bathrooms, kitchens, and outdoor areas.

4. **Arc Fault Circuit Interrupters (AFCIs)** detect dangerous arcing conditions that might not trip standard breakers. They analyze the current waveform for patterns characteristic of arcs and interrupt the circuit when these patterns are detected, helping prevent fires.

5. **Isolation transformers** separate circuits electrically, preventing direct current flow between primary and secondary sides while maintaining energy transfer. This isolation can provide an additional safety margin in sensitive applications.

6. **Double insulation** incorporates two layers of insulating material in equipment design, eliminating the need for a separate equipment ground in some cases. Double-insulated devices are marked with a "square within a square" symbol.

The **effectiveness of grounding systems** depends on several factors:

1. **Low impedance**: The grounding system must provide a low-impedance path for fault current to ensure sufficient current flow to activate protective devices.

2. **Adequate capacity**: Grounding conductors must be large enough to carry the maximum fault current without failure.

3. **Continuity**: All grounding connections must remain intact; loose or corroded connections compromise protection.

4. **Regular testing**: Ground resistance testing and visual inspection should occur periodically to verify system integrity.

> **Analogy**: A grounding system functions like a safety spillway on a dam. Under normal conditions, the spillway isn't used, but during flood conditions (electrical faults), it provides a safe path for excess water (current) away from areas where it could cause damage.

### Safe Practices for Working with Electricity

**Electrical safety procedures** protect workers from shock, arc flash, and other electrical hazards.[^35] [^58] These practices combine administrative controls, engineering solutions, and personal protective equipment to create multiple layers of protection.

**Basic safety principles** that should be followed when working with electricity include:

1. **De-energize before working**: Whenever possible, turn off power, verify power is off, and lock out/tag out before beginning work. Follow these essential steps:
   - Turn off the power source
   - Verify absence of voltage using a properly rated test instrument
   - Apply lockout/tagout devices to prevent unintentional energization
   - Re-verify absence of voltage before beginning work

2. **Assume circuits are energized**: When verification is not possible, always treat circuits as if they are energized, and use appropriate PPE and insulated tools.

3. **Use appropriate tools**: Only use tools designed for electrical work, including:
   - Insulated hand tools rated for the voltage being worked on
   - Voltage testers of the correct category rating
   - Properly rated meters and test equipment

4. **Wear proper PPE**: Personal protective equipment should be selected based on the specific hazard and may include:
   - Insulating gloves with leather protectors
   - Arc-rated face shields or flash suits
   - Safety glasses or goggles
   - Insulating mats
   - Non-conductive hard hats
   - Flame-resistant clothing

5. **Maintain awareness of surroundings**: Be conscious of:
   - Potential conductive paths to ground through the body
   - Presence of water or moisture
   - Metal surfaces that could become energized
   - Clearance requirements for energized equipment

**The hierarchy of electrical safety controls** prioritizes protection methods from most to least effective:

1. **Elimination**: Remove the hazard completely (e.g., permanently de-energize unused circuits)

2. **Substitution**: Replace with less hazardous alternatives (e.g., use lower voltage equipment)

3. **Engineering controls**: Design features that reduce hazards (e.g., guarding, interlocks, remote operation)

4. **Administrative controls**: Procedures, training, warnings (e.g., permit systems, safety protocols)

5. **Personal protective equipment**: Last line of defense (e.g., insulating gloves, arc flash protection)

**Special safety considerations** apply to specific situations:

1. **Working on energized equipment**: When equipment cannot be de-energized:
   - Obtain proper authorization through an energized work permit
   - Use insulated barriers to prevent accidental contact
   - Remove conductive items (watches, rings, etc.)
   - Never work alone
   - Position the body to minimize exposure to potential arc flash

2. **Capacitive systems**: Equipment with capacitors can store dangerous energy even when disconnected:
   - Allow sufficient discharge time
   - Verify de-energization
   - Actively discharge capacitors through appropriate resistive paths

3. **High-voltage work**: Additional precautions include:
   - Establishing safety boundaries
   - Using hot sticks and other specialized tools
   - Implementing specific approach distance requirements

4. **Emergency response**: All electrical workers should be familiar with:
   - The location of emergency disconnects
   - Proper procedures for disconnecting power in emergencies
   - First aid for electrical injuries, including CPR
   - Fire extinguisher locations and proper types for electrical fires

**Rescue procedures** should be well understood before working with electricity:

1. **Never directly touch a person in contact with an energized circuit**
2. **De-energize the circuit if possible**
3. **If de-energization is not immediately possible, use non-conductive materials to separate the victim from the energy source**
4. **Call for emergency medical assistance**
5. **Provide first aid, including CPR if needed, once the victim is separated from the energy source**

**Regulatory framework** for electrical safety in the United States includes:

- OSHA regulations (29 CFR 1910.269, 1910.301-399, and others)
- NFPA 70 (National Electrical Code) for installations
- NFPA 70E (Standard for Electrical Safety in the Workplace) for work practices

These standards provide specific requirements for training, work procedures, equipment ratings, and installation methods.

> **Teaching Note**: Safety training should include hands-on practice with lockout/tagout procedures, proper meter usage, and emergency response. Consider bringing in actual PPE items for students to examine and practice donning correctly.

**Practice Questions**:

1. Calculate the current that would flow through a person with 5,000 ohms of body resistance if they contacted a 120V circuit. Which physiological effects would this current likely cause?

2. Explain the primary purpose of equipment grounding and how it helps protect against electric shock hazards.

3. A worker needs to troubleshoot a 480V electrical panel with the covers removed. List the appropriate PPE they should wear and explain the specific protection each item provides.

4. Describe the proper procedure for verifying that a circuit has been de-energized before beginning work.

7. **Practical Applications and Examples**
   - Household Electrical Systems
   - Electronic Devices and Components
   - Renewable Energy Systems

## Section 7: Practical Applications and Examples

### Household Electrical Systems

**Residential electrical systems** apply fundamental electrical principles to safely distribute power throughout homes.[^50] [^51] Understanding these systems helps with troubleshooting, maintenance, and safe operation of household electrical equipment.

**Electrical service entrance** is where utility power enters the home and typically includes:

> **Visual Aid Instruction:** Create a comprehensive diagram of residential electrical service showing: overhead service drop, service entrance conductors, meter, main service panel with main breaker, distribution panel with branch circuits, color-coded wiring (black/red/white/green), GFCI and AFCI protection, and properly grounded outlets. Include cutaway views of walls showing proper wiring methods.

1. **Service drop or lateral**: Overhead wires (drop) or underground cables (lateral) bring power from the utility lines to the building.

2. **Electric meter**: Measures electricity consumption in kilowatt-hours (kWh). Modern smart meters may provide additional data like peak usage times and power quality information.

3. **Main disconnect**: A switch or circuit breaker that can cut all power to the building, typically rated at 100-200 amperes for residential applications.

4. **Service panel** (breaker box): Contains circuit breakers or fuses that protect individual circuits throughout the home. Main components include:
   - Main breaker: Controls power to all branch circuits
   - Branch circuit breakers: Protect individual circuits
   - Neutral bus bar: Connection point for all neutral conductors
   - Ground bus bar: Connection point for equipment grounding conductors

**Residential circuits** distribute power according to specific needs and safety requirements:

1. **General-purpose circuits** (lighting and receptacles):
   - Typically 15A or 20A circuits with 14 AWG or 12 AWG conductors respectively
   - Supply multiple outlets and fixtures throughout specific areas of the home
   - Limited to a maximum of 12 outlets per circuit in modern installations

2. **Dedicated appliance circuits**:
   - Higher-current circuits (20-50A) reserved for specific appliances
   - Examples include: refrigerator, dishwasher, garbage disposal, microwave, washing machine
   - Typically use 12 AWG to 6 AWG conductors, depending on the load

3. **Special circuits**:
   - 240V circuits for heavy appliances like electric ranges, dryers, water heaters
   - HVAC circuits for heating and cooling equipment
   - Outdoor circuits with weather-resistant components and GFCI protection

**Wiring methods** in residential construction include:

1. **Nonmetallic sheathed cable** (NM or "Romex"):
   - Most common in residential construction
   - Contains insulated conductors and a bare equipment grounding conductor in a flexible plastic sheath
   - Color-coded for different applications (white for 14 AWG, yellow for 12 AWG, orange for 10 AWG)

2. **Armored cable** (AC or BX):
   - Flexible metal armor protects conductors
   - Provides additional physical protection and some electromagnetic shielding
   - The armor itself often serves as the equipment grounding path

3. **Conduit systems**:
   - EMT (Electrical Metallic Tubing), PVC, or flexible conduit with individual conductors pulled through
   - Used in unfinished spaces, outdoor applications, or where local codes require
   - Provides superior protection and facilitates future wire changes

**Residential electrical safety devices** protect against specific hazards:

1. **Ground Fault Circuit Interrupters (GFCIs)**:[^57] [^58]
   - Required in wet locations: bathrooms, kitchens, outdoors, garages, basements
   - Trip when they detect current leakage as small as 4-6 milliamperes
   - Can be circuit breakers, receptacles, or portable units

2. **Arc Fault Circuit Interrupters (AFCIs)**:[^59]
   - Detect dangerous arcing conditions that conventional breakers might miss
   - Required in bedrooms, living rooms, family rooms, dining rooms, and similar areas
   - Help prevent electrical fires by detecting arc faults in damaged wiring

3. **Surge Protectors**:
   - Whole-house units installed at the service panel protect all circuits
   - Point-of-use devices protect specific sensitive electronics
   - Divert excess voltage during power surges to the grounding system

**Typical electrical consumption** in households varies widely but follows general patterns:

1. **Heating and cooling**: 40-50% of total energy usage
   - Electric heating: 10,000-20,000 watts when operating
   - Central air conditioning: 3,000-5,000 watts
   - Heat pumps: 1,500-5,000 watts

2. **Water heating**: 13-15% of total energy usage
   - Electric water heater: 3,000-5,000 watts

3. **Large appliances**: 15-20% of total energy usage
   - Electric range: 2,000-12,000 watts (varies by elements in use)
   - Clothes dryer: 1,800-5,000 watts
   - Refrigerator: 150-400 watts when running

4. **Lighting and small appliances**: 15-20% of total energy usage
   - LED light bulb: 5-15 watts
   - Microwave: 600-1,200 watts
   - Television: 50-200 watts

**Energy monitoring and management** systems allow homeowners to track usage and identify savings opportunities:

1. **Smart meters** communicate directly with utility companies and may offer detailed usage data.

2. **Home energy monitors** connect to the service panel and provide real-time consumption information, often accessible via smartphone apps.

3. **Smart home systems** can control lighting, HVAC, and appliances to optimize energy use based on occupancy, time of day, or utility rates.

**Troubleshooting residential electrical problems** follows a systematic approach:

1. **No power to entire house**:
   - Check utility service status
   - Verify main breaker position
   - Inspect incoming service connections

2. **No power to a circuit**:
   - Check circuit breaker position
   - Test GFCI outlets and reset if tripped
   - Look for signs of overload (warm breakers or outlets)

3. **Intermittent power issues**:
   - Inspect for loose connections
   - Check for damaged insulation or worn-out devices
   - Look for pest damage or water intrusion

4. **Fixture or appliance problems**:
   - Isolate whether the issue is with the device or the power supply
   - Check for appropriate voltage at the outlet
   - Verify proper grounding

> **Teaching Note**: Create a model electrical service panel for classroom demonstrations. Use clear plastic to show internal components, and include working circuit breakers students can safely operate. Develop troubleshooting scenarios where students diagnose common household electrical problems.

### Electronic Devices and Components

**Electronic devices** use electrical principles to process signals, control equipment, and perform a wide range of functions. Understanding basic electronic components and their functions provides essential knowledge for troubleshooting and designing electronic circuits.

**Passive components** do not require an external power source to operate and cannot amplify signals:

1. **Resistors** limit current flow according to Ohm's Law and are characterized by:
   - **Resistance value**: Measured in ohms (Ω)
   - **Power rating**: Maximum power they can dissipate without damage
   - **Tolerance**: Allowed deviation from nominal value (e.g., ±1%, ±5%)
   - **Temperature coefficient**: How resistance changes with temperature
   
   Common resistor types include carbon film, metal film, wirewound, and surface mount. Applications include current limiting, voltage division, and biasing of active components.

2. **Capacitors** store electrical energy in an electric field between two conductive plates separated by an insulator (dielectric).[^42] [^43] Key characteristics include:

> **Visual Aid Instruction:** Create an animated cross-section diagram showing capacitor charging and discharging. Show: 1) Electrons accumulating on plates during charging with visible electric field lines building up, 2) Energy storage visualization with increasing potential, 3) Discharge cycle with current flow direction, and 4) Side-by-side comparison of different capacitor types (electrolytic, ceramic, film, variable) with internal construction details and symbols. Include a time-domain graph showing voltage and current relationships during charge/discharge cycles.

   - **Capacitance**: Measured in farads (F), typically microfarads (μF) or picofarads (pF)
   - **Voltage rating**: Maximum voltage they can withstand
   - **Dielectric material**: Determines capacitor properties and applications
   - **Leakage current**: Small current that flows through the dielectric
   
   Common capacitor types include ceramic, electrolytic, tantalum, and film. Applications include filtering, coupling/decoupling, timing circuits, and power supply smoothing.

3. **Inductors** store energy in a magnetic field created by current flow through a conductor, typically a coil of wire.[^44] [^46] Key characteristics include:

> **Visual Aid Instruction:** Create an animated visualization of inductor operation showing: 1) Current flowing through a coil with the resulting magnetic field lines forming and expanding, 2) The relationship between coil turns, core material, and induced magnetic field strength, 3) Energy storage in the magnetic field during current increase and release during current decrease, 4) Demonstration of Lenz's Law showing how inductor opposes changes in current, and 5) Comparison of different inductor types (air core, iron core, toroidal) with their respective field patterns. Include a time-domain graph showing the phase relationship between voltage and current in an inductor.

   - **Inductance**: Measured in henries (H), often millihenries (mH) or microhenries (μH)
   - **Current rating**: Maximum current before core saturation or overheating
   - **Core material**: Air, iron, ferrite, or other materials affecting inductance
   - **Quality factor (Q)**: Ratio of inductive reactance to resistance
   
   Applications include filtering, energy storage in switching power supplies, and forming resonant circuits when combined with capacitors.

4. **Transformers** transfer electrical energy between circuits through electromagnetic induction. They consist of two or more coils wound around a common core. Key characteristics include:

> **Visual Aid Instruction:** Create an interactive transformer visualization showing: 1) Primary and secondary windings with adjustable turns ratios, 2) Animated magnetic flux lines in the core connecting both windings, 3) Energy transfer process from primary to secondary with no direct electrical connection, 4) Step-up and step-down operation with voltage and current relationships clearly visible, and 5) Different transformer types (power, isolation, instrument) with their construction features. Include real-time graphs showing how changing the turns ratio affects output voltage and current while maintaining power (ignoring losses).

   - **Turns ratio**: Relationship between primary and secondary windings
   - **Power rating**: Maximum power transfer capability
   - **Frequency range**: Optimal operating frequency
   - **Core type**: Material and construction affecting efficiency and frequency response
   
   Applications include voltage transformation, impedance matching, and isolation between circuits.

**Active components** require an external power source and can amplify or process signals:

1. **Diodes** allow current flow in one direction while blocking it in the reverse direction.[^60] [^62] Key types include:

> **Visual Aid Instruction:** Create an interactive visualization of diode operation showing: 1) P-N junction atomic structure with depletion region, 2) Forward bias operation with electrons and holes crossing the junction and current flowing, 3) Reverse bias operation showing widened depletion region and blocked current, 4) I-V characteristic curve with forward voltage drop and breakdown voltage regions clearly labeled, and 5) Side-by-side comparison of specialty diodes (Zener, LED, Schottky, photodiode) with their unique properties highlighted. Include a simple rectifier circuit showing how AC is converted to pulsating DC with animations of current flow.

   - **Rectifier diodes**: Convert AC to DC in power supplies
   - **Zener diodes**: Maintain specific voltage levels for regulation
   - **Light-emitting diodes (LEDs)**: Convert electrical energy to light
   - **Schottky diodes**: Low forward voltage drop for high-efficiency applications
   - **Photodiodes**: Generate current when exposed to light

2. **Transistors** are semiconductor devices that can amplify signals or function as electronic switches.[^61] [^63] Main types include:

> **Visual Aid Instruction:** Create an interactive comparison of transistor types with: 1) Cross-sectional views of BJT and FET semiconductor structures showing doping regions and current flow paths, 2) Circuit symbols for each transistor type side-by-side, 3) Animated illustrations of how each transistor operates in switching vs. amplification mode with visible current/carrier flow, and 4) Characteristic curves showing input/output relationships. Include a simple circuit demonstration where students can adjust input levels and observe transistor behavior in real-time.

   - **Bipolar Junction Transistors (BJTs)**: Current-controlled devices with NPN or PNP configurations
   - **Field-Effect Transistors (FETs)**: Voltage-controlled devices with less power consumption than BJTs
   - **Metal-Oxide-Semiconductor FETs (MOSFETs)**: Common in modern digital circuits and power applications
   - **Insulated-Gate Bipolar Transistors (IGBTs)**: Combine features of BJTs and MOSFETs for power applications

3. **Integrated Circuits (ICs)** contain numerous electronic components on a single semiconductor substrate. Common types include:
   - **Operational amplifiers (op-amps)**: Versatile amplifiers used in analog signal processing
   - **Logic gates**: Basic building blocks of digital circuits (AND, OR, NOT, etc.)
   - **Microcontrollers**: Programmable devices with processor, memory, and I/O capabilities
   - **Application-specific ICs (ASICs)**: Designed for particular applications
   - **Power management ICs**: Regulate and control power in electronic systems

**Basic electronic circuits** demonstrate fundamental principles and have practical applications:

1. **Power supply circuits** convert AC power to regulated DC voltage:

> **Visual Aid Instruction:** Create an interactive power supply visualization showing: 1) Complete signal flow through each stage (transformer, rectifier, filter, regulator) with animated waveforms at each point, 2) Side-by-side comparison of half-wave vs. full-wave vs. bridge rectification with current paths highlighted during both half-cycles, 3) Filter capacitor operation showing charge/discharge cycles and ripple reduction, 4) Interactive component value manipulation showing effects on output quality (e.g., larger capacitors reducing ripple), 5) Linear vs. switching regulator operation with efficiency comparisons and thermal considerations, and 6) Common voltage regulator circuits (7800 series, LM317, buck converters) with their internal functional blocks. Include oscilloscope traces at different test points and troubleshooting indicators for common failure modes.

   - **Transformer** reduces voltage to appropriate level
   - **Rectifier** (diodes) converts AC to pulsating DC
   - **Filter** (capacitors) smooths pulsating DC
   - **Regulator** (IC or discrete components) maintains stable output voltage

   Modern switch-mode power supplies use high-frequency switching techniques for greater efficiency and smaller size compared to linear power supplies.

2. **Amplifier circuits** increase signal strength and come in various configurations:

> **Visual Aid Instruction:** Create an interactive amplifier visualization showing: 1) Common amplifier topologies with animated signal flow and gain visualization (common emitter/source, common collector/drain, differential pairs), 2) Operational amplifier in various configurations with virtual ground concept demonstrated and feedback paths highlighted, 3) Frequency response characteristics with interactive Bode plots showing how component values affect bandwidth, 4) Signal distortion visualization comparing input vs output waveforms at different gain levels, 5) Biasing techniques with DC operating points clearly marked on load lines, and 6) Class A, B, AB power amplifier operation with crossover distortion illustrated. Include interactive troubleshooting scenarios where students can identify issues from signal patterns at test points.

   - **Voltage amplifiers**: Increase signal voltage
   - **Current amplifiers**: Increase signal current
   - **Power amplifiers**: Increase both voltage and current
   - **Operational amplifier circuits**: Versatile configurations including inverting, non-inverting, summing, and differential amplifiers

3. **Oscillator circuits** generate repetitive waveforms without external input signals:

> **Visual Aid Instruction:** Create an interactive oscillator visualization showing: 1) Side-by-side comparison of different oscillator types (RC, LC, crystal) with their circuit diagrams and component roles, 2) Animated energy transfer process in LC oscillators showing how energy oscillates between magnetic field (inductor) and electric field (capacitor), 3) Frequency-determining components with interactive controls to adjust values and see real-time changes in output frequency and waveform, 4) Comparison of output stability between different oscillator types with drift visualization under temperature and voltage variations, and 5) Common oscillator configurations (Colpitts, Hartley, Wien bridge, Pierce) with animations showing signal path and feedback mechanisms. Include actual scope traces of waveforms produced by each type.

   - **RC oscillators**: Use resistor-capacitor timing networks
   - **LC oscillators**: Use inductor-capacitor resonant circuits
   - **Crystal oscillators**: Use quartz crystals for high frequency stability
   - **Function generators**: Produce various waveforms (sine, square, triangle)

4. **Digital logic circuits** process binary signals (0 and 1) using logic gates:
   - **Combinational logic**: Output depends only on current inputs
   - **Sequential logic**: Output depends on current inputs and previous states
   - **Memory circuits**: Store binary information
   - **Counters and timers**: Track events or generate timing signals

**Electronic measurements and testing** involve specialized instruments:

1. **Oscilloscopes** display signal waveforms over time, showing:
   - Voltage amplitude
   - Frequency and period
   - Rise and fall times
   - Signal distortion

2. **Function generators** produce various waveforms for testing circuit response

3. **Logic analyzers** capture and display multiple digital signals simultaneously

4. **Component testers** measure specific component parameters:
   - Transistor testers
   - Capacitance meters
   - LCR meters for inductance, capacitance, and resistance

**Modern electronics trends** include:

1. **Miniaturization**: Increasingly compact components and surface-mount technology

2. **Integrated systems**: Combining multiple functions in single-chip solutions

3. **Low power consumption**: Energy-efficient designs for battery-powered and portable devices

4. **Wireless connectivity**: Incorporation of RF and communication capabilities

5. **Smart devices**: Integration of sensing, processing, and communication functions

> **Teaching Note**: Use circuit simulation software to demonstrate electronic principles without risk of component damage. Have students build and test basic circuits like power supplies, amplifiers, and oscillators to reinforce theoretical concepts with hands-on experience.

### Renewable Energy Systems

**Renewable energy systems** harness naturally replenishing energy sources to generate electricity with minimal environmental impact. These systems apply electrical principles in innovative ways to capture, convert, and distribute sustainable power. Understanding renewable energy technologies provides valuable context for the practical application of electrical concepts.

**Solar photovoltaic (PV) systems** convert sunlight directly into electricity using semiconductor materials. Key components and principles include:

> **Visual Aid Instruction:** Create a comprehensive diagram of a grid-tied solar system showing solar panels (with cell structure enlarged), inverter, charge controller, battery bank (if applicable), grid connection point, metering and monitoring components, and energy flow under different conditions (day/night, high/low consumption).

1. **Photovoltaic cells**: The basic building blocks that generate electricity when exposed to sunlight. They operate based on the photovoltaic effect, where photons from sunlight knock electrons free in semiconductor material, creating current flow. Cell technologies include:
   - **Monocrystalline silicon**: Higher efficiency (15-22%), longer lifespan, more expensive
   - **Polycrystalline silicon**: Moderate efficiency (13-16%), less expensive
   - **Thin-film**: Lower efficiency (10-13%), flexible, better performance in low light

2. **Solar panels**: Multiple cells connected in series and parallel configurations to achieve desired voltage and current ratings.[^64] [^65] Panel specifications include:
   - **Power output**: Rated in watts-peak (Wp) under standard test conditions
   - **Voltage ratings**: Open circuit voltage (Voc) and maximum power voltage (Vmp)
   - **Current ratings**: Short circuit current (Isc) and maximum power current (Imp)
   - **Temperature coefficients**: How performance changes with temperature

3. **Inverters**: Convert DC power from solar panels to AC power compatible with the electrical grid or home systems. Types include:
   - **String inverters**: Connect to multiple panels in series, cost-effective but affected by panel shading
   - **Microinverters**: Installed on individual panels, optimize each panel independently
   - **Power optimizers**: DC-to-DC converters paired with string inverters for panel-level optimization
   - **Hybrid inverters**: Integrate battery storage functionality

4. **Charge controllers**: Regulate battery charging in off-grid or battery backup systems to prevent overcharging or excessive discharge. Types include:
   - **PWM (Pulse Width Modulation)**: Simpler, less expensive
   - **MPPT (Maximum Power Point Tracking)**: More efficient, extract maximum available power

**System configurations** include:

1. **Grid-tied**: Connected to the utility grid, can feed excess power back to the grid through net metering
2. **Off-grid**: Standalone systems with battery storage for areas without utility access
3. **Hybrid**: Connected to the grid but include battery storage for backup or self-consumption

**Wind energy systems** convert kinetic energy from moving air into electricity.[^66] [^67] Key components and principles include:

> **Visual Aid Instruction:** Generate a cutaway diagram of a wind turbine showing blade aerodynamics, gearbox, generator, nacelle components, tower structure, control systems, and power conversion equipment.

1. **Wind turbines** consist of:
   - **Rotor blades**: Capture wind energy through aerodynamic lift
   - **Nacelle**: Houses the generator, gearbox, and control systems
   - **Tower**: Elevates turbine to higher wind speeds at greater heights
   - **Foundation**: Provides structural support

2. **Generators** convert mechanical rotation to electricity through electromagnetic induction. Types include:
   - **Permanent magnet generators**: More efficient at variable speeds
   - **Doubly-fed induction generators**: Common in large utility-scale turbines
   - **Direct drive**: Eliminate gearboxes for improved reliability

3. **Power electronics** manage the variable frequency output from wind turbines and convert it to grid-compatible power. Components include:
   - **Rectifiers**: Convert variable AC to DC
   - **Inverters**: Convert DC to grid-frequency AC
   - **Controllers**: Optimize power output under varying wind conditions

**Wind turbine types** include:

1. **Horizontal axis**: Most common design, with blades rotating around a horizontal axis
2. **Vertical axis**: Less common design that can capture wind from any direction without needing to rotate the entire structure

**Hydroelectric power** harnesses the energy of flowing water to generate electricity.[^68] Systems include:

1. **Large-scale hydroelectric dams**: Create reservoirs that store potential energy, released through turbines
2. **Run-of-river systems**: Generate electricity from river flow without significant water storage
3. **Pumped storage**: Function as energy storage by pumping water uphill during low demand and releasing it during high demand

**Hydroelectric generators** follow the same electromagnetic induction principles as other generators but are optimized for the consistent, high-torque characteristics of water turbines.

**Energy storage systems** address the intermittent nature of many renewable sources. Technologies include:

> **Visual Aid Instruction:** Create a comprehensive comparison of energy storage technologies with: 1) Cross-sectional animations showing the internal working principles of different storage types (batteries, pumped hydro, compressed air, flywheels), 2) Energy density comparison chart with volume and weight considerations, 3) Discharge time vs. capacity plot showing which technologies are best for short-duration vs. long-duration storage, 4) Efficiency ratings and cycle life expectations, and 5) Interactive cost comparison tool that allows students to calculate storage costs for different scenarios and applications.

1. **Electrochemical batteries**:
   - **Lithium-ion**: High energy density, increasingly affordable
   - **Lead-acid**: Lower cost but shorter lifespan
   - **Flow batteries**: Separate power and energy capacity, scalable for grid applications

2. **Mechanical storage**:
   - **Pumped hydro**: Most widely deployed grid-scale storage
   - **Compressed air**: Stores energy by compressing air in underground caverns
   - **Flywheels**: Store energy as rotational kinetic energy

3. **Thermal storage**:
   - **Molten salt**: Common in concentrated solar power systems
   - **Ice storage**: Used for cooling applications

**Grid integration** of renewable energy involves:

1. **Smart grid technologies** that enable bidirectional power flow and communication between grid components

2. **Microgrids**: Localized grids that can disconnect from the traditional grid to operate autonomously

3. **Demand response systems**: Adjust electricity consumption based on supply availability

4. **Grid stability measures** to address the variability of renewable generation:
   - **Frequency regulation**: Maintain grid frequency within acceptable limits
   - **Voltage support**: Ensure proper voltage levels throughout the grid
   - **Spinning reserves**: Maintain backup capacity for sudden changes in generation or load

**Electrical challenges** specific to renewable energy systems include:

1. **Intermittency**: Power generation varies with weather conditions

2. **Power quality issues**: Inverter-based generation can introduce harmonics and require power conditioning

3. **Protection coordination**: Traditional protection schemes may need modification to accommodate bidirectional power flow

4. **Islanding detection**: Grid-tied systems must detect and respond to utility outages

**Renewable energy economics** increasingly favor sustainable technologies:

1. **Levelized cost of energy (LCOE)**: Solar and wind are now often less expensive than fossil fuels

2. **Installation costs**: Continue to decline through technological improvements and economies of scale

3. **Incentives and policies**: Support renewable deployment through tax credits, rebates, and renewable portfolio standards

> **Teaching Note**: Develop hands-on projects where students can build small-scale renewable energy systems, such as solar-powered battery chargers or wind turbines with DC generators. Use data logging to compare energy production under different conditions and reinforce concepts of power, voltage, and current measurement.

**Practice Questions**:

1. A 300W solar panel operates at its maximum power point with a voltage of 32V. Calculate the current at this operating point and explain how changing irradiance would affect both the current and voltage.

2. Compare and contrast grid-tied and off-grid solar PV systems, including the major components required for each and how electrical energy is managed differently.

3. Explain how a wind turbine converts kinetic energy to electrical energy, identifying the energy transformations and the electrical principles involved.

4. A homeowner has a 5kW solar array and wants to add battery storage to utilize excess daytime generation during evening hours. If the average evening electricity usage is 8kWh, what battery capacity would you recommend, and what electrical components would be needed to integrate the battery with the existing system?

## Section 8: Teaching Resources and Methods

### Effective Analogies for Electricity Concepts

**Using analogies** is one of the most powerful teaching methods for making abstract electrical concepts concrete and understandable. Effective analogies connect unfamiliar electrical principles to familiar everyday experiences, creating mental models that help students grasp challenging concepts.

**Water flow analogy** is the most widely used comparison for explaining basic electrical principles:

1. **Voltage (pressure)**: 
   - **Analogy**: Water pressure in pipes
   - **Explanation**: Just as water pressure pushes water through a pipe system, voltage is the electrical pressure that pushes electrons through a conductor. Higher water pressure results in stronger flow, just as higher voltage creates greater potential for current flow.
   - **Teaching Application**: Demonstrate with connected water containers at different heights; the greater the height difference (voltage), the faster water flows between them.

2. **Current (flow rate)**:
   - **Analogy**: Rate of water flowing through pipes
   - **Explanation**: Water flow rate (gallons per minute) corresponds to electrical current (amperes). Both measure the amount of substance (water molecules or electrons) passing a point per unit time.
   - **Teaching Application**: Use a flow meter on water pipes to visualize how narrowing a pipe (increasing resistance) reduces flow while maintaining the same pressure (voltage).

3. **Resistance (restriction)**:
   - **Analogy**: Pipe diameter or obstacles within pipes
   - **Explanation**: Narrow or clogged pipes restrict water flow just as resistors limit electrical current. In both cases, energy is converted to heat at points of restriction.
   - **Teaching Application**: Demonstrate with different diameter tubes or partially clogged pipes to show how flow changes with restriction while pressure remains constant.

4. **Ohm's Law relationship**:
   - **Analogy**: Water flow = Pressure ÷ Restriction
   - **Explanation**: This directly parallels I = V/R, showing how the three variables interact in a predictable, mathematical relationship.
   - **Teaching Application**: Create a demonstration with adjustable water pressure and variable pipe restrictions, measuring the resulting flow rate.

**Traffic flow analogy** offers an alternative perspective on electrical concepts:

1. **Voltage (driving force)**:
   - **Analogy**: Steepness of a road or strength of motivation to travel
   - **Explanation**: Cars on a steeper hill have greater potential energy and tendency to move, similar to how electrons at higher voltage potential have greater tendency to flow.

2. **Current (cars per hour)**:
   - **Analogy**: Number of vehicles passing a point per unit time
   - **Explanation**: Traffic volume represents electron flow rate, with each car analogous to charge carriers.

3. **Resistance (road conditions)**:
   - **Analogy**: Road width, speed limits, traffic signals, construction
   - **Explanation**: Poor road conditions slow traffic flow just as resistance impedes electron flow.

4. **Series and parallel paths**:
   - **Analogy**: Single-lane roads vs. multiple highway lanes
   - **Explanation**: Single routes channel all traffic through one path (series), while multiple lanes or route options divide traffic flow (parallel).

**Energy and power analogies** help clarify these critical concepts:

1. **Electrical energy**:
   - **Analogy**: Fuel consumed by vehicles
   - **Explanation**: Just as cars consume gallons of fuel to perform work over time, electrical systems use kilowatt-hours of energy to perform tasks.

2. **Power**:
   - **Analogy**: Rate of fuel consumption or engine horsepower
   - **Explanation**: A powerful engine uses fuel more quickly to generate more work per unit time, just as electrical power determines energy consumption rate.

**Advanced concept analogies** address more complex topics:

1. **Capacitance**:
   - **Analogy**: Water tank or elastic membrane
   - **Explanation**: A water tank stores water under pressure, releasing it when needed, similar to how capacitors store and release electrical charge. Alternatively, an elastic membrane that distorts when pressure is applied but returns to normal when pressure is removed mimics capacitor behavior.

2. **Inductance**:
   - **Analogy**: Flywheel or water wheel momentum
   - **Explanation**: A spinning flywheel resists changes to its rotational speed, storing energy in its motion, similar to how inductors resist changes in current and store energy in a magnetic field.

3. **Impedance**:
   - **Analogy**: Complex traffic patterns with changing restrictions
   - **Explanation**: Roads with variable conditions that change based on time of day or traffic volume create complex flow patterns similar to impedance in AC circuits.

4. **Diodes**:
   - **Analogy**: One-way valve or turnstile
   - **Explanation**: A one-way valve allows water flow in only one direction, just as diodes allow current to flow in only one direction.

**Guidelines for effective analogy use**:

1. **Match complexity to student level**: Simpler analogies for beginners, more nuanced comparisons for advanced students

2. **Acknowledge limitations**: Explicitly state where analogies break down to prevent misconceptions

3. **Use multiple analogies**: Different comparisons highlight different aspects of electrical concepts

4. **Build visual models**: Combine analogies with diagrams or physical demonstrations

5. **Connect to prior knowledge**: Reference students' existing experience with the analogous systems

6. **Progressive refinement**: Start with simple analogies and add complexity as understanding develops

### Common Misconceptions and Clarifications

**Addressing misconceptions** is critical in electricity education. Students often develop incorrect mental models that hinder their progress if not properly identified and corrected. This section catalogs common misunderstandings about electrical concepts and provides clear explanations to address them.

**Fundamental concept misconceptions**:

1. **Misconception**: Current is consumed in a circuit.
   - **Reality**: Current (electron flow) is conserved throughout a circuit and does not get "used up" by components.
   - **Clarification**: Demonstrate with a series circuit that the current measurement is the same at any point in the circuit. Energy is transferred, but charge carriers continue flowing.
   - **Teaching strategy**: Use a water circuit with a continuous flow or a bicycle chain analogy to show how the medium transfers energy without being consumed.

2. **Misconception**: Voltage is the same as current.
   - **Reality**: Voltage is electrical pressure/potential difference that drives current flow.
   - **Clarification**: Emphasize that voltage is the cause, current is the effect. Voltage can exist without current (open circuit), but current cannot flow without voltage.
   - **Teaching strategy**: Use a water tank analogy: water pressure (voltage) exists even when the valve is closed (no flow/current).

3. **Misconception**: Electricity always takes the path of least resistance.
   - **Reality**: Electricity takes all available paths in inverse proportion to their resistance.
   - **Clarification**: In parallel circuits, more current flows through lower-resistance paths, but some current flows through all paths.
   - **Teaching strategy**: Use a traffic analogy with multiple roads of different quality—more cars take better roads, but some take all available routes.

4. **Misconception**: Higher voltage is always more dangerous.
   - **Reality**: While higher voltage creates greater potential for current flow, it's actually current passing through the body that causes harm.
   - **Clarification**: Explain that as little as 50mA through the heart can be fatal, regardless of whether it's from a higher or lower voltage source. However, higher voltage more easily overcomes body resistance to create dangerous currents.
   - **Teaching strategy**: Use the analogy of a small but fast-moving object (high current) versus a large but slow-moving object (high voltage but low current) to illustrate different types of danger.

**Circuit-related misconceptions**:

1. **Misconception**: Opening a switch "releases" electricity that was "trapped" in the circuit.
   - **Reality**: Opening a switch simply stops the flow of electrons by breaking the path.
   - **Clarification**: Electrons aren't "stored" in wires waiting to flow; rather, they're already present throughout the conductor and move when a complete path exists.
   - **Teaching strategy**: Compare to turning off a water valve—water doesn't disappear from the pipes, it just stops flowing.

2. **Misconception**: Current flows from the positive terminal to the negative terminal.
   - **Reality**: Conventional current direction is defined as positive to negative, but actual electron flow is from negative to positive.
   - **Clarification**: Explain the historical context of this convention, established before the discovery of electron movement direction.
   - **Teaching strategy**: Acknowledge the confusion but emphasize consistent use of conventional current direction in circuit analysis.

3. **Misconception**: A wire's length significantly affects its resistance in most household applications.
   - **Reality**: For short household wiring, cross-sectional area is much more significant than length in determining resistance.
   - **Clarification**: While resistance is proportional to length (R = ρL/A), in practical applications with short runs of copper wire, the gauge (cross-sectional area) is the dominant factor.
   - **Teaching strategy**: Demonstrate with different gauge wires of the same length.

**Component-specific misconceptions**:

1. **Misconception**: Batteries provide constant current regardless of the circuit connected.
   - **Reality**: Batteries provide relatively constant voltage (until depleted), and the circuit's resistance determines the current drawn.
   - **Clarification**: A battery is more like a pressure source than a flow source.
   - **Teaching strategy**: Show measurements of battery voltage remaining relatively stable while current varies dramatically with different loads.

2. **Misconception**: Resistors "resist" voltage.
   - **Reality**: Resistors limit current flow and convert electrical energy to thermal energy.
   - **Clarification**: Voltage is a difference in potential across a component; resistors don't "resist" voltage but rather limit the current that flows due to that voltage.
   - **Teaching strategy**: Measure voltage and current across various resistors to demonstrate Ohm's Law relationships.

3. **Misconception**: Transformers change voltage into current or vice versa.
   - **Reality**: Transformers change voltage and current levels while maintaining power (V × I) through electromagnetic induction.
   - **Clarification**: Transformers don't convert between voltage and current; they change both in inverse proportion to maintain power (minus efficiency losses).
   - **Teaching strategy**: Use the gear ratio analogy—speed decreases as torque increases, but power remains constant.

**Safety misconceptions**:

> **Visual Aid Instruction:** Create a myth-busting visual series showing common electrical misconceptions and their corrections. Include side-by-side comparisons of: ordinary rubber gloves vs. rated electrical gloves (with voltage ratings visible); the path of electricity through a human body when touching live wires in various scenarios; visualization of why birds on power lines don't get shocked but humans touching overhead lines from ladders do; and proper vs. improper grounding techniques with clear safety indicators.

1. **Misconception**: Rubber gloves or shoes provide complete protection from electric shock.
   - **Reality**: Only specially rated insulating gloves and footwear designed for electrical work provide adequate protection.
   - **Clarification**: Ordinary rubber items may contain conductive materials or have tiny holes that compromise protection.
   - **Teaching strategy**: Show examples of properly rated electrical safety equipment versus everyday rubber items.

2. **Misconception**: Wood is always a good insulator.
   - **Reality**: Wet or damp wood can conduct electricity and pose shock hazards.
   - **Clarification**: Many materials' insulating properties depend on moisture content, temperature, and other environmental factors.
   - **Teaching strategy**: Demonstrate conductivity tests on dry versus damp wood.

3. **Misconception**: Low voltage systems are always safe to touch.
   - **Reality**: Even low voltages can be dangerous in certain conditions, especially with wet skin or large current capacity.
   - **Clarification**: Car batteries (12V) can deliver hundreds of amperes and cause severe burns if shorted.
   - **Teaching strategy**: Safely demonstrate the heating effect when a low-resistance wire bridges a car battery's terminals.

**Teaching strategies for addressing misconceptions**:

1. **Elicit prior knowledge**: Have students explain their understanding before teaching a concept

2. **Confront misconceptions directly**: Present evidence that challenges incorrect beliefs

3. **Provide accessible explanations**: Use multiple representations (verbal, visual, mathematical) to clarify concepts

4. **Hands-on validation**: Let students test their beliefs through controlled experiments

5. **Repetition and reinforcement**: Revisit corrected concepts throughout the course

6. **Connect to real-world applications**: Show how the correct understanding applies in practical situations

### Progressive Learning Pathways

**Building electrical knowledge** requires a strategic sequence that introduces concepts in a logical order, with each new idea building on previously mastered content. This section outlines effective learning pathways that help students develop a coherent understanding of electricity from basic principles to complex applications.

**Foundational knowledge pathway**:

1. **Basic atomic structure** (1-2 sessions)
   - Structure of atoms, electrons, protons, neutrons
   - Concept of electrical charge
   - Conductors versus insulators
   - Static electricity phenomena

2. **Fundamental electrical quantities** (2-3 sessions)
   - Electric charge and its unit (coulomb)
   - Electric current: definition and units (ampere)
   - Voltage/potential difference: definition and units (volt)
   - Resistance: definition and units (ohm)
   - Simple experiments that demonstrate each quantity

3. **Ohm's Law relationships** (2-3 sessions)
   - Mathematical relationship between V, I, and R
   - Graphical representations
   - Problem-solving with Ohm's Law
   - Practical verification through measurement

4. **Simple DC circuits** (3-4 sessions)
   - Circuit components and symbols
   - Complete circuit concept
   - Series circuits: characteristics and analysis
   - Parallel circuits: characteristics and analysis
   - Combined series-parallel arrangements

**Intermediate knowledge pathway**:

1. **Circuit analysis techniques** (3-4 sessions)
   - Kirchhoff's voltage and current laws
   - Voltage divider and current divider principles
   - Power calculations in circuits
   - Thévenin and Norton equivalent circuits

2. **Electrical measurements** (2-3 sessions)
   - Digital multimeter operation
   - Measuring voltage, current, and resistance
   - Interpreting measurement results
   - Troubleshooting techniques

3. **Magnetism and electromagnetism** (3-4 sessions)
   - Magnetic fields and flux
   - Electromagnetic induction
   - Motors and generators: principles of operation
   - Transformers and Faraday's Law

4. **Introduction to AC circuits** (3-4 sessions)
   - AC waveforms and terminology
   - RMS values and power calculations
   - Resistive, inductive, and capacitive components in AC circuits
   - Introduction to impedance concept

**Advanced knowledge pathway**:

1. **Complex AC circuit analysis** (4-5 sessions)
   - Phasor representation
   - Reactance and impedance
   - Power factor and power triangle
   - Resonant circuits

2. **Three-phase systems** (3-4 sessions)
   - Three-phase generation
   - Delta and wye connections
   - Line and phase voltages and currents
   - Three-phase power calculations

3. **Power distribution systems** (3-4 sessions)
   - Generation, transmission, distribution
   - Substations and transformers
   - Protection systems and coordination
   - Smart grid concepts

4. **Practical applications** (4-6 sessions)
   - Household electrical systems
   - Industrial electrical systems
   - Electronic devices and controls
   - Renewable energy integration

**Learning scaffolds for different student types**:

1. **Visual learners**:
   - Provide circuit diagrams with color-coded components
   - Use animated simulations of electron flow
   - Incorporate visual analogies that connect abstract concepts to familiar objects
   - Create graphic organizers that map relationships between concepts

2. **Auditory learners**:
   - Include verbal explanations with precise terminology
   - Use mnemonics for formulas and relationships
   - Encourage verbal repetition of key principles
   - Facilitate discussions about problem-solving approaches

3. **Kinesthetic learners**:
   - Incorporate hands-on lab activities for each major concept
   - Use physical models that can be manipulated
   - Create movement-based analogies for electrical phenomena
   - Develop interactive troubleshooting scenarios

4. **Reading/writing learners**:
   - Provide detailed written explanations
   - Assign written summaries and reflections
   - Include process descriptions for all procedures
   - Develop structured note-taking templates

**Assessment strategies along the pathway**:

1. **Diagnostic assessment** to identify prior knowledge and misconceptions
   - Pre-tests with common misconception items
   - Concept mapping exercises
   - Open-ended questions about electrical phenomena

2. **Formative assessment** to guide ongoing instruction
   - Quick response questions during instruction
   - Circuit analysis challenges with immediate feedback
   - Laboratory procedure checkpoints
   - Peer teaching opportunities

3. **Summative assessment** to verify mastery
   - Traditional tests with calculation problems
   - Circuit design projects with specific constraints
   - Troubleshooting scenarios with multiple issues
   - Real-world application case studies

**Integration of computational tools**:

1. **Circuit simulation software** introduction after basic circuit concepts
   - Begin with simple DC circuits
   - Progress to AC analysis
   - Compare simulation results with hand calculations
   - Advance to complex circuit design and optimization

2. **Spreadsheet applications** for electrical calculations
   - Ohm's Law calculators
   - Power consumption estimation
   - Component sizing worksheets
   - Data analysis from lab measurements

**Addressing diverse student needs**:

1. **Remedial pathways** for struggling students
   - Additional practice with fundamental concepts
   - One-on-one tutoring on specific challenges
   - Alternative explanations using different analogies
   - Simplified lab activities focusing on core principles

2. **Enrichment pathways** for advanced students
   - Open-ended design challenges
   - Research projects on emerging technologies
   - Mentoring opportunities with industry professionals
   - Competition participation (robotics, energy efficiency, etc.)

3. **English language learner supports**
   - Visual glossaries of technical terms
   - Multilingual reference materials
   - Hands-on demonstrations that reduce language dependency
   - Partner work with bilingual peers

**Learning progression milestones**:

1. **Conceptual understanding**: Student can explain electrical principles in their own words

2. **Mathematical application**: Student can perform calculations using electrical formulas

3. **Analysis ability**: Student can predict circuit behavior given specific changes

4. **Troubleshooting capability**: Student can identify problems in malfunctioning circuits

5. **Design competency**: Student can create circuits to meet specific requirements

6. **Integration mastery**: Student can combine electrical principles with other systems

### Practice Problems with Solutions

**Problem-based learning** reinforces electrical concepts through application and helps students develop analytical skills. This section provides a variety of practice problems covering key topics throughout the curriculum, with detailed solutions that explain the reasoning process.

#### Ohm's Law and Basic DC Circuits

**Problem 1**: A heating element in an electric stove draws 8.0 amperes when connected to a 240-volt source. Calculate its resistance and power consumption.

**Solution**:
- To find resistance, use Ohm's Law: R = V/I = 240 V / 8.0 A = 30 ohms
- To find power, use P = V × I = 240 V × 8.0 A = 1,920 watts or 1.92 kW

**Problem 2**: In the circuit below, find the total resistance and the current through each resistor.

```
      +---[R1: 6Ω]---+
      |               |
     12V              +---[R3: 12Ω]---+
      |               |                |
      +---[R2: 4Ω]---+                |
      |                                |
      +--------------------------------+
```

**Solution**:
- R1 and R2 are in parallel: 1/R₁₂ = 1/6 + 1/4 = 5/12 → R₁₂ = 2.4Ω
- R₁₂ and R3 are in series: R_total = 2.4Ω + 12Ω = 14.4Ω
- Total current: I_total = V/R_total = 12V/14.4Ω = 0.833A
- Voltage across R₁₂: V₁₂ = I_total × R₁₂ = 0.833A × 2.4Ω = 2V
- Current through R1: I₁ = V₁₂/R1 = 2V/6Ω = 0.333A
- Current through R2: I₂ = V₁₂/R2 = 2V/4Ω = 0.5A
- Current through R3: I₃ = I_total = 0.833A

**Problem 3**: A string of 24 holiday lights is connected in series to a 120V source. Each bulb has identical resistance. If one bulb burns out, causing the entire string to go dark, what is the voltage across each operational bulb?

**Solution**:
- When connected in series, voltage divides equally across identical components
- Each bulb receives: V_bulb = 120V / 24 = 5V
- When one bulb burns out, it creates an open circuit, so no current flows and the string goes dark

#### Power and Energy

**Problem 4**: A homeowner's monthly electricity bill shows consumption of 900 kWh. If electricity costs $0.12 per kWh, calculate:
a) The monthly cost
b) The average daily consumption in kWh
c) If the home primarily uses electricity for heating and the heating system operates at 15 kW, how many hours per day (on average) was the heating system running?

**Solution**:
a) Monthly cost = 900 kWh × $0.12/kWh = $108.00
b) Average daily consumption = 900 kWh / 30 days = 30 kWh/day
c) Hours of heating per day = 30 kWh/day ÷ 15 kW = 2 hours/day

**Problem 5**: A DC motor draws 3A from a 24V source. If its efficiency is 80%, calculate:
a) The input power
b) The output mechanical power
c) The power lost as heat

**Solution**:
a) Input power = V × I = 24V × 3A = 72 watts
b) Output mechanical power = Input power × efficiency = 72W × 0.80 = 57.6 watts
c) Power lost as heat = Input power - Output power = 72W - 57.6W = 14.4 watts

#### AC Circuit Analysis

**Problem 6**: In an AC circuit, a 40Ω resistor is connected in series with a 0.15H inductor. If the circuit is connected to a 120V, 60Hz source, calculate:
a) The inductive reactance
b) The total impedance
c) The circuit current
d) The voltage across each component
e) The phase angle between voltage and current
f) The power factor

**Solution**:
a) Inductive reactance: X_L = 2πfL = 2π × 60Hz × 0.15H = 56.5Ω
b) Impedance: Z = √(R² + X_L²) = √(40² + 56.5²) = 69.2Ω
c) Circuit current: I = V/Z = 120V/69.2Ω = 1.73A
d) Voltage across resistor: V_R = I × R = 1.73A × 40Ω = 69.2V
   Voltage across inductor: V_L = I × X_L = 1.73A × 56.5Ω = 97.7V
   Note that V_R and V_L are not in phase, so their sum is not 120V arithmetically
e) Phase angle: θ = tan⁻¹(X_L/R) = tan⁻¹(56.5/40) = 54.7°
f) Power factor = cos(θ) = cos(54.7°) = 0.577

#### Capacitor Circuits

**Problem 7**: A 100μF capacitor is initially uncharged. It is then connected to a 12V battery through a 2kΩ resistor.
a) What is the time constant of the circuit?
b) How long will it take for the capacitor to charge to 63.2% of the battery voltage?
c) What will the voltage across the capacitor be after 0.4 seconds?
d) How much energy is stored in the fully charged capacitor?

**Solution**:
a) Time constant: τ = R × C = 2,000Ω × 100 × 10⁻⁶F = 0.2 seconds
b) The capacitor charges to 63.2% of final value after one time constant, so t = 0.2 seconds
c) Voltage after 0.4s = V_final × (1 - e^(-t/τ)) = 12V × (1 - e^(-0.4/0.2)) = 12V × (1 - e^(-2)) = 12V × (1 - 0.135) = 10.38V
d) Energy stored = ½CV² = ½ × 100 × 10⁻⁶F × (12V)² = 7.2 × 10⁻³ joules = 7.2 mJ

#### Three-Phase Systems

> **Visual Aid Instruction:** Generate an interactive three-phase graph showing three sinusoidal waveforms offset by 120°. Color code each phase, allow toggling between wye and delta configurations, show vector diagrams corresponding to the waveforms, and include line-to-line and line-to-neutral voltage representations.

**Problem 8**: A balanced three-phase load is connected in delta configuration to a 208V (line-to-line) supply.[^48] [^49] Each phase of the load has an impedance of 30∠30° ohms.
a) Calculate the phase current in each impedance
b) Calculate the line currents
c) Calculate the total power consumed by the load

**Solution**:
a) Phase voltage = Line voltage = 208V
   Phase current = Phase voltage / Phase impedance = 208V / 30Ω = 6.93A
   This current lags the voltage by 30° due to the impedance angle
b) In a delta configuration, line current = √3 × phase current = √3 × 6.93A = 12A
c) Total power = 3 × V_phase × I_phase × cos(θ) = 3 × 208V × 6.93A × cos(30°) = 3 × 208 × 6.93 × 0.866 = 3,755 watts

#### Electrical Safety

**Problem 9**: A fault current of 120mA flows through a grounding system with a ground resistance of 10 ohms.[^35] [^58]
a) What voltage will appear on the equipment frame relative to true ground?
b) Is this voltage level considered safe for human contact? Explain why or why not.
c) If the safe touch potential limit is 50V, what is the maximum allowable ground resistance?

**Solution**:
a) Voltage = Current × Resistance = 0.120A × 10Ω = 1.2V
b) This voltage level (1.2V) is generally considered safe for human contact. The threshold for perception is around 5V, and dangerous electrical shock typically occurs at higher voltages given normal skin resistance.
c) Maximum allowable ground resistance = Safe voltage / Fault current = 50V / 0.120A = 416.7 ohms
   However, electrical codes typically require much lower resistance (25 ohms or less) for safety margins.

#### Circuit Troubleshooting

**Problem 10**: A technician is troubleshooting a malfunctioning circuit where a motor won't start. The following measurements were taken:
- Line voltage at service panel: 240V
- Voltage at motor terminals: 0V
- Continuity test of supply conductors: Good
- Circuit breaker position: On
- Overload relay status: Not tripped

Identify three possible causes of the problem and describe how to test each hypothesis.

**Solution**:
1. **Failed disconnect switch**
   - Test: Measure voltage at input and output terminals of disconnect switch
   - Expected result if failed: 240V at input, 0V at output while switch is in ON position
   - Resolution: Replace disconnect switch

2. **Open circuit in control wiring**
   - Test: Check continuity of control circuit components (e.g., start/stop buttons, control relays)
   - Expected result if failed: Infinite resistance across an open component
   - Resolution: Repair or replace the open component

3. **Failed motor contactor**
   - Test: Check if contactor coil is energized (measure voltage across coil); manually test contactor movement
   - Expected result if failed: Either coil not energized despite proper control signals or contactor not closing despite energized coil
   - Resolution: Replace contactor

#### Additional Practice Problem Types

**Problem 11**: Calculate the size of a circuit breaker and wire gauge needed for a 240V electric water heater rated at 4,500W, assuming copper conductors with 75°C insulation and no more than 3% voltage drop over a 50-foot run.

**Problem 12**: Design a voltage divider circuit to convert a 0-12V input signal to a 0-5V output signal for an analog-to-digital converter input.

**Problem 13**: A three-way switch lighting circuit is not working correctly. When switch A is up and switch B is down, the light is on. When both switches are up or both are down, the light is off. Explain what is wrong with the circuit and how to correct it.

**Problem 14**: Explain how to use a digital multimeter to determine which end of a transformer is the primary and which is the secondary if all labeling has been removed.

**Problem 15**: A PV solar system has 12 panels rated at 350W each. If the system receives an average of 5 hours of peak sunshine per day, calculate the expected monthly energy production in kWh.

> **Teaching Note**: Structure problem-solving sessions to emphasize process over answers. Have students explain their reasoning at each step, identify the appropriate formulas before calculation, and verify results through dimensional analysis. Consider having students create their own practice problems based on real-world scenarios to build applied understanding.

## References

[^23]: Khan Academy. (2023). "Electrical Properties of Materials." https://www.khanacademy.org/science/physics/circuits-topic/circuits-resistance/a/electrical-properties-of-materials

[^24]: National Institute of Standards and Technology. (2022). "Fundamental Electrical Measurements." https://www.nist.gov/pml/quantum-electrical-measurements/fundamental-electrical-measurements

[^28]: MIT OpenCourseWare. (2021). "Introduction to Electronics, Signals, and Measurement." https://ocw.mit.edu/courses/electrical-engineering-and-computer-science/6-071j-introduction-to-electronics-signals-and-measurement-spring-2006/

[^30]: Georgia State University. (2023). "HyperPhysics - Electrical Power." http://hyperphysics.phy-astr.gsu.edu/hbase/electric/elepow.html

[^32]: IEEE Power & Energy Society. (2022). "Understanding Electric Power Systems." https://www.ieee-pes.org/education-resources

[^33]: Electronics Tutorial. (2023). "Electric Power Formulas." https://www.electronics-tutorials.ws/dccircuits/dcp_2.html

[^34]: UC Davis ChemWiki. (2023). "Electrical Conductivity in Materials." https://chem.libretexts.org/Bookshelves/General_Chemistry/Book%3A_ChemPRIME_(Moore_et_al.)/08%3A_Electrons_in_Atoms/8.09%3A_Electrical_Conductivity

[^35]: Occupational Safety and Health Administration. (2022). "Electrical Safety in the Workplace." https://www.osha.gov/electrical/hazards/index.html

[^36]: IEEE Transactions on Power Delivery. (2023). "Power Loss Analysis in Electrical Systems." https://ieeexplore.ieee.org/xpl/RecentIssue.jsp?punumber=61

[^38]: Engineering Toolbox. (2022). "Electrical Power Loss and Joule Heating." https://www.engineeringtoolbox.com/electrical-resistance-power-loss-d_1897.html

[^42]: All About Circuits. (2023). "Capacitors and Capacitance." https://www.allaboutcircuits.com/textbook/direct-current/chpt-13/capacitors-capacitance/

[^43]: Electronics Notes. (2022). "Capacitor Theory and Operation." https://www.electronics-notes.com/articles/basic_concepts/capacitance/capacitors-theory-tutorial.php

[^44]: Electronics Tutorials. (2023). "Inductors and Inductance." https://www.electronics-tutorials.ws/inductor/inductor.html

[^45]: IEEE Transactions on Power Electronics. (2022). "Transformer Loss Analysis." https://ieeexplore.ieee.org/xpl/RecentIssue.jsp?punumber=63

[^46]: University of Colorado. (2023). "Physics of Inductors and Magnetic Materials." https://www.colorado.edu/physics/phys3330/phys3330_sp16/

[^47]: MIT OpenCourseWare. (2022). "Electromagnetic Energy: From Motors to Lasers." https://ocw.mit.edu/courses/electrical-engineering-and-computer-science/6-007-electromagnetic-energy-from-motors-to-lasers-spring-2011/

[^48]: Georgia Tech. (2023). "Three-Phase Electric Power Systems." https://ece.gatech.edu/research/areas/electric-power

[^49]: University of Minnesota. (2022). "Three-Phase Systems in Power Applications." https://cse.umn.edu/ece/power-systems-engineering

[^50]: National Electrical Code. (2023). "Residential Electrical Systems Requirements." https://www.nfpa.org/codes-and-standards/all-codes-and-standards/list-of-codes-and-standards/detail?code=70

[^51]: Electrical Construction & Maintenance. (2022). "Modern Residential Electrical Systems." https://www.ecmweb.com/residential

[^52]: IEEE Transactions on Industry Applications. (2023). "Systematic Approaches to Electrical Troubleshooting." https://ieeexplore.ieee.org/xpl/RecentIssue.jsp?punumber=28

[^53]: International Society of Automation. (2022). "Troubleshooting Electrical Systems." https://www.isa.org/training-and-certification/isa-training/instructor-led/course-descriptions/ti23-troubleshooting-electrical-systems

[^54]: Fluke Corporation. (2023). "Digital Multimeter Principles and Techniques." https://www.fluke.com/en-us/learn/best-practices/measurement-basics/electricity/digital-multimeter-principles

[^55]: Underwriters Laboratories. (2022). "Circuit Protection Devices Safety Standards." https://ul.org/standards-and-engagement/standards/ul-standards

[^56]: Tektronix. (2023). "Oscilloscope Fundamentals." https://www.tek.com/en/learn/oscilloscope-basics

[^57]: National Fire Protection Association. (2023). "Electrical Safety and Circuit Protection." https://www.nfpa.org/News-and-Research/Publications-and-media/NFPA-Journal/2020/May-June-2020/Features/Electrical-Safety

[^58]: Electrical Safety Foundation International. (2022). "Home Electrical Safety." https://www.esfi.org/electrical-safety/home-electrical-safety/

[^59]: Leviton. (2023). "Arc-Fault Circuit Interrupters Technology." https://www.leviton.com/en/products/gfci-afci-dual-function-circuit-breakers

[^60]: Philips Semiconductors. (2022). "Diodes and Rectifiers Handbook." https://www.nxp.com/docs/en/data-sheet/1N4148_1N4448.pdf

[^61]: Texas Instruments. (2023). "Transistor Theory and Applications." https://www.ti.com/lit/an/sloa059/sloa059.pdf

[^62]: Electronics Tutorials. (2022). "Semiconductor Diode Theory." https://www.electronics-tutorials.ws/diode/diode_1.html

[^63]: IEEE Power Electronics Society. (2023). "Transistor Fundamentals and Applications." https://www.ieee-pels.org/education/tutorials

[^64]: National Renewable Energy Laboratory. (2023). "Photovoltaic Science and Technology." https://www.nrel.gov/pv/

[^65]: Solar Energy Industries Association. (2022). "Solar Photovoltaic Technology." https://www.seia.org/initiatives/photovoltaics

[^66]: American Wind Energy Association. (2023). "Wind Energy Technology." https://www.awea.org/wind-101/basics-of-wind-energy/wind-facts-at-a-glance

[^67]: U.S. Department of Energy. (2022). "Wind Energy Technologies Office." https://www.energy.gov/eere/wind/wind-energy-technologies-office

[^68]: International Hydropower Association. (2023). "Hydropower Technology and Applications." https://www.hydropower.org/iha/discover-hydropower

[^69]: Agilent Technologies. (2022). "The Fundamentals of Signal Measurement." https://www.keysight.com/zz/en/assets/7018-01326/application-notes/5965-7908.pdf

[^70]: Fundamentals of Physics. (2023). "Ohm's Law and Electrical Resistance." https://www.wiley.com/en-us/Fundamentals+of+Physics-p-9781119460138

[^71]: Electric Power Research Institute. (2022). "Transformer Efficiency and Loss Evaluation." https://www.epri.com/research/products/000000003002000090

[^73]: University of Colorado. (2023). "Ohm's Law and Electrical Circuits." https://www.colorado.edu/physics/phys1140/phys1140_fa2018/