import { ISection } from '@/types/content';

/**
 * Client-side content parser that fetches content from the API
 * instead of directly accessing the file system
 * @returns Promise resolving to an array of structured content sections
 */
export async function parseContentFile(): Promise<ISection[]> {
  try {
    console.log('Client-side: Fetching content from API');
    // Fetch content from the API route instead of directly using fs
    const response = await fetch('/api/content', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
      // Use cache: 'no-store' to ensure we always get fresh content
      cache: 'no-store'
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch content: ${response.status}`);
    }

    const data = await response.json();
    console.log('Client-side: Received data from API:', data);
    console.log('Client-side: Number of sections:', data.sections ? data.sections.length : 0);
    
    if (data.sections && data.sections.length > 0) {
      console.log('Client-side: First section title:', data.sections[0].title);
      console.log('Client-side: First section has content HTML:', !!data.sections[0].contentHtml);
    }
    
    return data.sections || [];
  } catch (error) {
    console.error('Error fetching content:', error);
    return [];
  }
}
