/**
 * AI Service for the Basic Electricity Tutor
 * Handles communication with OpenAI API for the chatbot functionality
 */

import { ISection } from '@/types/content';
import { IMessage } from '@/types/chat';

// Default system prompt that instructs the AI on its role
const DEFAULT_SYSTEM_PROMPT = `
You are an AI tutor specialized in teaching basic electricity concepts.
Your goal is to help students understand fundamental electrical principles through clear explanations,
analogies, and guided problem-solving. Be patient, encouraging, and adapt your explanations to the
student's level of understanding. 

Key teaching principles:
- Use simple analogies (water flow for current, pressure for voltage, etc.)
- Break complex concepts into digestible steps
- Encourage questions and provide positive reinforcement
- Reference visualizations and examples from the course content when helpful
- Guide students to discover answers rather than just providing them
- Use practical, real-world examples to make concepts relatable

When appropriate, refer to visualizations and examples from the course content to reinforce learning.
If a student seems confused, try a different approach or analogy.
Always maintain an encouraging and supportive tone.
`;

interface AIServiceConfig {
  apiKey?: string;
  model?: string;
  maxTokens?: number;
  temperature?: number;
}

export class AIService {
  private apiKey: string;
  private model: string;
  private maxTokens: number;
  private temperature: number;
  private currentSection: ISection | null = null;
  private conversationHistory: IMessage[] = [];

  constructor(config: AIServiceConfig = {}) {
    this.apiKey = config.apiKey || process.env.NEXT_PUBLIC_OPENAI_API_KEY || '';
    this.model = config.model || 'gpt-4o';
    this.maxTokens = config.maxTokens || 1000;
    this.temperature = config.temperature || 0.7;
  }

  /**
   * Set the current section being viewed by the user
   * This provides context for the AI responses
   */
  public setCurrentSection(section: ISection | null): void {
    this.currentSection = section;
  }

  /**
   * Get conversation history for context
   */
  public getConversationHistory(): IMessage[] {
    return this.conversationHistory;
  }

  /**
   * Clear conversation history
   */
  public clearConversationHistory(): void {
    this.conversationHistory = [];
  }

  /**
   * Generate a comprehensive system prompt based on the current section
   */
  private generateSystemPrompt(): string {
    let systemPrompt = DEFAULT_SYSTEM_PROMPT;

    if (this.currentSection) {
      systemPrompt += `\n\n=== CURRENT LESSON CONTEXT ===\n`;
      systemPrompt += `Section: ${this.currentSection.title}\n`;
      
      // Add key concepts from the content
      const contentPreview = this.currentSection.rawContent.substring(0, 500);
      systemPrompt += `Key concepts in this section: ${contentPreview}...\n`;
      
      // Add information about visualizations if they exist
      if (this.currentSection.visualizations && this.currentSection.visualizations.length > 0) {
        systemPrompt += '\n=== AVAILABLE VISUALIZATIONS ===\n';
        this.currentSection.visualizations.forEach(vis => {
          systemPrompt += `- ${vis.title}: ${vis.description}\n`;
        });
        systemPrompt += 'You can reference these visualizations to help explain concepts.\n';
      }
      
      // Add information about practice questions if they exist
      if (this.currentSection.practiceQuestions && this.currentSection.practiceQuestions.length > 0) {
        systemPrompt += '\n=== PRACTICE QUESTIONS AVAILABLE ===\n';
        systemPrompt += `There are ${this.currentSection.practiceQuestions.length} practice questions for this section.\n`;
        systemPrompt += 'You can suggest students try these questions to test their understanding.\n';
      }

      systemPrompt += '\n=== TEACHING GUIDELINES ===\n';
      systemPrompt += '- Always relate explanations back to the current section content\n';
      systemPrompt += '- Use the visualizations to enhance understanding\n';
      systemPrompt += '- Encourage hands-on learning with practice questions\n';
      systemPrompt += '- If students ask about topics not in the current section, gently guide them back or suggest they explore other sections\n';
    }

    return systemPrompt;
  }

  /**
   * Send a message to the AI and get a response with enhanced error handling
   */
  public async sendMessage(messages: IMessage[]): Promise<IMessage> {
    // Check if API key is available
    if (!this.apiKey) {
      console.error('OpenAI API key is not configured');
      return {
        role: 'assistant',
        content: 'I apologize, but the AI tutoring service is not properly configured. Please check that your OpenAI API key is set up correctly in your environment variables.'
      };
    }

    try {
      // Update conversation history
      const newUserMessage = messages[messages.length - 1];
      if (newUserMessage) {
        this.conversationHistory.push(newUserMessage);
      }

      // Prepare the messages array with system prompt and recent history
      const systemPrompt = this.generateSystemPrompt();
      const recentHistory = this.conversationHistory.slice(-6); // Keep last 6 messages for context
      
      const apiMessages = [
        { role: 'system', content: systemPrompt },
        ...recentHistory.map(msg => ({
          role: msg.role,
          content: msg.content
        }))
      ];

      // Call the OpenAI API
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          model: this.model,
          messages: apiMessages,
          max_tokens: this.maxTokens,
          temperature: this.temperature,
          presence_penalty: 0.1,
          frequency_penalty: 0.1
        })
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        console.error('OpenAI API error:', response.status, errorData);
        
        if (response.status === 401) {
          return {
            role: 'assistant',
            content: 'I apologize, but there seems to be an authentication issue with the AI service. Please check your API key configuration.'
          };
        } else if (response.status === 429) {
          return {
            role: 'assistant',
            content: 'I apologize, but the AI service is currently experiencing high demand. Please try again in a moment.'
          };
        } else {
          return {
            role: 'assistant',
            content: 'I apologize, but I encountered an error while processing your request. Please try again.'
          };
        }
      }

      const data = await response.json();
      const assistantMessage: IMessage = {
        role: 'assistant',
        content: data.choices[0]?.message?.content || 'I apologize, but I was unable to generate a response. Please try again.'
      };

      // Add assistant response to history
      this.conversationHistory.push(assistantMessage);

      return assistantMessage;

    } catch (error) {
      console.error('Error calling OpenAI API:', error);
      return {
        role: 'assistant',
        content: 'I apologize, but I encountered a technical error. Please check your internet connection and try again.'
      };
    }
  }

  /**
   * Generate a helpful suggestion based on the current section
   */
  public generateSectionSuggestion(): string {
    if (!this.currentSection) {
      return "Feel free to ask me any questions about electricity! I'm here to help you learn.";
    }

    const suggestions = [
      `Let's explore ${this.currentSection.title}. What would you like to understand better?`,
      `I can help explain the concepts in "${this.currentSection.title}". What questions do you have?`,
      `Ready to dive into ${this.currentSection.title}? Ask me anything about this topic!`
    ];

    if (this.currentSection.visualizations && this.currentSection.visualizations.length > 0) {
      suggestions.push(`Check out the interactive visualizations for ${this.currentSection.title} - they really help illustrate these concepts!`);
    }

    if (this.currentSection.practiceQuestions && this.currentSection.practiceQuestions.length > 0) {
      suggestions.push(`Once you understand ${this.currentSection.title}, try the practice questions to test your knowledge!`);
    }

    return suggestions[Math.floor(Math.random() * suggestions.length)];
  }

  /**
   * Generate helpful suggestions based on the current section
   */
  async getSuggestions(section: ISection): Promise<string[]> {
    // Check if API key is available
    if (!this.apiKey || this.apiKey === 'your-openai-api-key-here') {
      console.warn('OpenAI API key not configured, using default suggestions');
      return this.getDefaultSuggestions(section);
    }

    try {
      const prompt = `Based on the following electrical concepts section, generate 4 helpful questions that a student might want to ask to better understand the topic. Make them specific, educational, and engaging.

Section: ${section.title}
Content preview: ${section.rawContent.substring(0, 500)}...

Available visualizations: ${section.visualizations?.map(v => v.title).join(', ') || 'None'}
Available practice questions: ${section.practiceQuestions?.length || 0} questions

Generate exactly 4 questions that would help students:
1. Understand the core concept better
2. See real-world applications
3. Connect to related topics
4. Practice or test their knowledge

Format as a simple list, one question per line.`;

      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          model: 'gpt-3.5-turbo',
          messages: [
            { role: 'system', content: 'You are an educational AI that generates helpful study questions. Be concise and educational.' },
            { role: 'user', content: prompt }
          ],
          max_tokens: 300,
          temperature: 0.7
        })
      });

      if (!response.ok) {
        if (response.status === 401) {
          console.warn('OpenAI API authentication failed. Please check your API key.');
          return this.getDefaultSuggestions(section);
        }
        throw new Error(`API request failed with status ${response.status}`);
      }

      const data = await response.json();
      const content = data.choices?.[0]?.message?.content;
      
      if (!content) {
        console.warn('No content received from OpenAI API');
        return this.getDefaultSuggestions(section);
      }

      // Parse the response into individual questions
      const suggestions = content
        .split('\n')
        .map((line: string) => line.replace(/^\d+\.\s*/, '').trim())
        .filter((line: string) => line.length > 0 && line.length < 100)
        .slice(0, 4);

      return suggestions.length > 0 ? suggestions : this.getDefaultSuggestions(section);
    } catch (error) {
      console.error('Error generating suggestions:', error);
      return this.getDefaultSuggestions(section);
    }
  }

  /**
   * Get default suggestions when AI generation fails
   */
  private getDefaultSuggestions(section: ISection): string[] {
    const suggestions = [
      `Tell me more about ${section.title}`,
      'Can you explain this concept differently?',
      'What are some real-world applications?',
      'How does this relate to other electrical concepts?'
    ];

    // Add visualization-specific suggestions if available
    if (section.visualizations && section.visualizations.length > 0) {
      suggestions[1] = `Explain the ${section.visualizations[0].title} visualization`;
    }

    // Add practice question suggestion if available
    if (section.practiceQuestions && section.practiceQuestions.length > 0) {
      suggestions[3] = 'Can you help me with the practice questions?';
    }

    return suggestions;
  }
}

// Create a singleton instance for use throughout the app
let aiServiceInstance: AIService | null = null;

export function getAIService(config?: AIServiceConfig): AIService {
  if (!aiServiceInstance) {
    aiServiceInstance = new AIService(config);
  }
  return aiServiceInstance;
}
