import React, { useEffect, useRef } from 'react';
import * as THREE from '../../../node_modules/@types/three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';

interface AtomicModelProps {
  element?: string;
  protons?: number;
  neutrons?: number;
  electrons?: number;
  shells?: number[];
  width?: number;
  height?: number;
  className?: string;
}

export default function AtomicModelVisualization({
  element = 'Generic',
  protons = 4,
  neutrons = 5,
  electrons = 4,
  shells = [2, 2],
  width = 400,
  height = 400,
  className = ''
}: AtomicModelProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const frameIdRef = useRef<number | null>(null);
  const electronGroupsRef = useRef<THREE.Group[]>([]);
  
  // Set up and clean up the Three.js scene
  useEffect(() => {
    if (!containerRef.current) return;
    
    // Create scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xf5f5f5);
    sceneRef.current = scene;
    
    // Create camera
    const camera = new THREE.PerspectiveCamera(75, width / height, 0.1, 1000);
    camera.position.z = 30;
    cameraRef.current = camera;
    
    // Create renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(window.devicePixelRatio);
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;
    
    // Add orbit controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controlsRef.current = controls;
    
    // Add ambient light
    const ambientLight = new THREE.AmbientLight(0x404040);
    scene.add(ambientLight);
    
    // Add directional light
    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(1, 1, 1);
    scene.add(directionalLight);
    
    // Create nucleus
    createNucleus();
    
    // Create electron shells
    createElectronShells();
    
    // Animation loop
    const animate = () => {
      frameIdRef.current = requestAnimationFrame(animate);
      
      // Rotate electron groups
      electronGroupsRef.current.forEach((group, index) => {
        const rotationSpeed = 0.01 / (index + 1); // Outer shells rotate slower
        group.rotation.z += rotationSpeed;
        group.rotation.x += rotationSpeed * 0.3;
      });
      
      controls.update();
      renderer.render(scene, camera);
    };
    
    animate();
    
    // Handle window resize
    const handleResize = () => {
      if (!containerRef.current || !cameraRef.current || !rendererRef.current) return;
      
      const newWidth = containerRef.current.clientWidth;
      const newHeight = containerRef.current.clientHeight;
      
      cameraRef.current.aspect = newWidth / newHeight;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(newWidth, newHeight);
    };
    
    window.addEventListener('resize', handleResize);
    
    // Cleanup function
    return () => {
      window.removeEventListener('resize', handleResize);
      
      if (frameIdRef.current !== null) {
        cancelAnimationFrame(frameIdRef.current);
      }
      
      if (rendererRef.current && containerRef.current) {
        containerRef.current.removeChild(rendererRef.current.domElement);
      }
      
      scene.clear();
    };
  }, [width, height]);
  
  // Update the model when props change
  useEffect(() => {
    if (!sceneRef.current) return;
    
    // Clear previous model
    while (sceneRef.current.children.length > 2) { // Keep lights
      sceneRef.current.remove(sceneRef.current.children[2]);
    }
    
    electronGroupsRef.current = [];
    
    // Recreate model with new props
    createNucleus();
    createElectronShells();
  }, [element, protons, neutrons, electrons, shells]);
  
  // Create the nucleus with protons and neutrons
  const createNucleus = () => {
    if (!sceneRef.current) return;
    
    const nucleusGroup = new THREE.Group();
    
    // Create a random but stable arrangement of protons and neutrons
    const nucleonRadius = 1;
    const positions = generateNucleonPositions(protons + neutrons, nucleonRadius);
    
    // Create protons (red)
    const protonGeometry = new THREE.SphereGeometry(nucleonRadius, 32, 32);
    const protonMaterial = new THREE.MeshStandardMaterial({ 
      color: 0xff5555,
      roughness: 0.5,
      metalness: 0.1
    });
    
    for (let i = 0; i < protons; i++) {
      const proton = new THREE.Mesh(protonGeometry, protonMaterial);
      proton.position.copy(positions[i]);
      nucleusGroup.add(proton);
      
      // Add positive charge indicator
      const chargeMaterial = new THREE.MeshBasicMaterial({ color: 0xffffff });
      const chargeGeometry = new THREE.BoxGeometry(0.4, 0.1, 0.1);
      const horizontalCharge = new THREE.Mesh(chargeGeometry, chargeMaterial);
      const verticalCharge = new THREE.Mesh(
        new THREE.BoxGeometry(0.1, 0.4, 0.1),
        chargeMaterial
      );
      
      const chargeGroup = new THREE.Group();
      chargeGroup.add(horizontalCharge);
      chargeGroup.add(verticalCharge);
      chargeGroup.position.copy(positions[i]);
      chargeGroup.position.y += 1;
      nucleusGroup.add(chargeGroup);
    }
    
    // Create neutrons (blue)
    const neutronGeometry = new THREE.SphereGeometry(nucleonRadius, 32, 32);
    const neutronMaterial = new THREE.MeshStandardMaterial({ 
      color: 0x5555ff,
      roughness: 0.5, 
      metalness: 0.1
    });
    
    for (let i = 0; i < neutrons; i++) {
      const neutron = new THREE.Mesh(neutronGeometry, neutronMaterial);
      neutron.position.copy(positions[protons + i]);
      nucleusGroup.add(neutron);
    }
    
    sceneRef.current.add(nucleusGroup);
  };
  
  // Generate positions for nucleons in the nucleus
  const generateNucleonPositions = (count: number, radius: number): THREE.Vector3[] => {
    const positions: THREE.Vector3[] = [];
    const minDistance = radius * 1.8;
    
    // Helper function to check if a position is valid
    const isValidPosition = (pos: THREE.Vector3): boolean => {
      for (const existing of positions) {
        if (pos.distanceTo(existing) < minDistance) {
          return false;
        }
      }
      return true;
    };
    
    // Generate positions using rejection sampling
    for (let i = 0; i < count; i++) {
      let position: THREE.Vector3;
      let attempts = 0;
      
      do {
        // Calculate a random position within a sphere
        const angle1 = Math.random() * Math.PI * 2;
        const angle2 = Math.random() * Math.PI * 2;
        const r = radius * 1.2 * Math.cbrt(Math.random()) * Math.min(3, Math.sqrt(count) * 0.5);
        
        position = new THREE.Vector3(
          r * Math.sin(angle1) * Math.cos(angle2),
          r * Math.sin(angle1) * Math.sin(angle2),
          r * Math.cos(angle1)
        );
        
        attempts++;
      } while (!isValidPosition(position) && attempts < 100);
      
      positions.push(position);
    }
    
    return positions;
  };
  
  // Create electron shells and electrons
  const createElectronShells = () => {
    if (!sceneRef.current) return;
    
    // Calculate total electrons needed
    const totalElectrons = shells.reduce((sum, shellCount) => sum + shellCount, 0);
    let electronCount = Math.min(electrons, totalElectrons);
    
    // Create shells
    for (let shellIndex = 0; shellIndex < shells.length; shellIndex++) {
      const shellGroup = new THREE.Group();
      const shellRadius = (shellIndex + 1) * 6;
      
      // Create shell orbit (ring)
      const ringGeometry = new THREE.TorusGeometry(shellRadius, 0.05, 16, 100);
      const ringMaterial = new THREE.MeshBasicMaterial({ 
        color: 0xcccccc,
        opacity: 0.5,
        transparent: true 
      });
      const ring = new THREE.Mesh(ringGeometry, ringMaterial);
      shellGroup.add(ring);
      
      // Add a second ring at an angle to show the 3D nature of the shell
      const ring2 = ring.clone();
      ring2.rotation.x = Math.PI / 2;
      shellGroup.add(ring2);
      
      // Create electrons for this shell
      const electronsInShell = Math.min(shells[shellIndex], electronCount);
      electronCount -= electronsInShell;
      
      const electronGeometry = new THREE.SphereGeometry(0.5, 32, 32);
      const electronMaterial = new THREE.MeshStandardMaterial({ 
        color: 0xffff00,
        emissive: 0xffff00,
        emissiveIntensity: 0.3,
        roughness: 0.3,
        metalness: 0.7 
      });
      
      for (let i = 0; i < electronsInShell; i++) {
        const electronGroup = new THREE.Group();
        const angle = (i / electronsInShell) * Math.PI * 2;
        
        const electron = new THREE.Mesh(electronGeometry, electronMaterial);
        electron.position.set(shellRadius * Math.cos(angle), shellRadius * Math.sin(angle), 0);
        
        // Add negative charge indicator
        const chargeMaterial = new THREE.MeshBasicMaterial({ color: 0xffffff });
        const chargeGeometry = new THREE.BoxGeometry(0.3, 0.08, 0.08);
        const charge = new THREE.Mesh(chargeGeometry, chargeMaterial);
        charge.position.copy(electron.position);
        charge.position.y += 0.6;
        
        electronGroup.add(electron);
        electronGroup.add(charge);
        shellGroup.add(electronGroup);
      }
      
      // Add a small random rotation to each shell to make it more interesting
      shellGroup.rotation.x = Math.random() * Math.PI;
      shellGroup.rotation.z = Math.random() * Math.PI;
      
      sceneRef.current.add(shellGroup);
      electronGroupsRef.current.push(shellGroup);
    }
  };
  
  return (
    <div 
      ref={containerRef} 
      className={`atomic-model ${className}`} 
      style={{ width: `${width}px`, height: `${height}px` }}
    >
      <div className="absolute top-2 left-2 bg-white bg-opacity-70 px-2 py-1 rounded text-sm">
        {element} ({protons}p, {neutrons}n, {electrons}e-)
      </div>
    </div>
  );
}
