"use client";

import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';

interface WaveformVisualizationProps {
  width?: number;
  height?: number;
  className?: string;
  interactive?: boolean;
  animate?: boolean;
  showControls?: boolean;
}

export default function WaveformVisualization({
  width = 600,
  height = 300,
  className = '',
  interactive = true,
  animate = true,
  showControls = true
}: WaveformVisualizationProps) {
  const svgRef = useRef<SVGSVGElement>(null);
  const [frequency, setFrequency] = useState(1);
  const [amplitude, setAmplitude] = useState(1);
  const [phase, setPhase] = useState(0);
  const [waveType, setWaveType] = useState<'sine' | 'square' | 'triangle'>('sine');
  const animationRef = useRef<number>();

  useEffect(() => {
    if (!svgRef.current) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    const margin = { top: 20, right: 20, bottom: 40, left: 50 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    // Create scales
    const xScale = d3.scaleLinear()
      .domain([0, 4 * Math.PI])
      .range([0, innerWidth]);

    const yScale = d3.scaleLinear()
      .domain([-2, 2])
      .range([innerHeight, 0]);

    // Create main group
    const g = svg.append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    // Add axes
    const xAxis = d3.axisBottom(xScale)
      .tickFormat(d => `${(d / Math.PI).toFixed(1)}π`);
    
    const yAxis = d3.axisLeft(yScale);

    g.append('g')
      .attr('class', 'x-axis')
      .attr('transform', `translate(0,${innerHeight})`)
      .call(xAxis);

    g.append('g')
      .attr('class', 'y-axis')
      .call(yAxis);

    // Add axis labels
    g.append('text')
      .attr('class', 'axis-label')
      .attr('x', innerWidth / 2)
      .attr('y', innerHeight + 35)
      .style('text-anchor', 'middle')
      .text('Time (radians)');

    g.append('text')
      .attr('class', 'axis-label')
      .attr('transform', 'rotate(-90)')
      .attr('x', -innerHeight / 2)
      .attr('y', -35)
      .style('text-anchor', 'middle')
      .text('Amplitude');

    // Generate waveform data
    const generateWaveData = (timeOffset = 0) => {
      const data = [];
      const numPoints = 200;
      
      for (let i = 0; i <= numPoints; i++) {
        const x = (i / numPoints) * 4 * Math.PI;
        let y = 0;
        
        switch (waveType) {
          case 'sine':
            y = amplitude * Math.sin(frequency * x + phase + timeOffset);
            break;
          case 'square':
            y = amplitude * Math.sign(Math.sin(frequency * x + phase + timeOffset));
            break;
          case 'triangle':
            y = amplitude * (2 / Math.PI) * Math.asin(Math.sin(frequency * x + phase + timeOffset));
            break;
        }
        
        data.push({ x, y });
      }
      
      return data;
    };

    // Create line generator
    const line = d3.line<{x: number, y: number}>()
      .x(d => xScale(d.x))
      .y(d => yScale(d.y))
      .curve(d3.curveMonotoneX);

    // Add waveform path
    const path = g.append('path')
      .attr('class', 'waveform')
      .attr('fill', 'none')
      .attr('stroke', '#2563eb')
      .attr('stroke-width', 2);

    // Animation function
    const animateWave = () => {
      if (!animate) return;
      
      let startTime = Date.now();
      
      const updateWave = () => {
        const elapsed = (Date.now() - startTime) / 1000;
        const timeOffset = elapsed * 2; // Animation speed
        
        const data = generateWaveData(timeOffset);
        path.datum(data).attr('d', line);
        
        animationRef.current = requestAnimationFrame(updateWave);
      };
      
      updateWave();
    };

    // Initial render
    const initialData = generateWaveData();
    path.datum(initialData).attr('d', line);

    // Start animation
    if (animate) {
      animateWave();
    }

    // Add grid lines
    g.selectAll('.grid-line-x')
      .data(xScale.ticks(8))
      .enter()
      .append('line')
      .attr('class', 'grid-line-x')
      .attr('x1', d => xScale(d))
      .attr('x2', d => xScale(d))
      .attr('y1', 0)
      .attr('y2', innerHeight)
      .attr('stroke', '#e5e7eb')
      .attr('stroke-width', 0.5);

    g.selectAll('.grid-line-y')
      .data(yScale.ticks(6))
      .enter()
      .append('line')
      .attr('class', 'grid-line-y')
      .attr('x1', 0)
      .attr('x2', innerWidth)
      .attr('y1', d => yScale(d))
      .attr('y2', d => yScale(d))
      .attr('stroke', '#e5e7eb')
      .attr('stroke-width', 0.5);

    // Cleanup function
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [frequency, amplitude, phase, waveType, animate, width, height]);

  return (
    <div className={`waveform-visualization ${className}`}>
      <div className="bg-white border border-gray-200 rounded-lg p-4">
        <h3 className="text-lg font-semibold mb-4">Waveform Generator</h3>
        
        {showControls && (
          <div className="controls mb-4 space-y-3">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Wave Type
                </label>
                <select
                  value={waveType}
                  onChange={(e) => setWaveType(e.target.value as 'sine' | 'square' | 'triangle')}
                  className="w-full px-3 py-1 border border-gray-300 rounded-md text-sm"
                >
                  <option value="sine">Sine</option>
                  <option value="square">Square</option>
                  <option value="triangle">Triangle</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Frequency: {frequency.toFixed(1)}
                </label>
                <input
                  type="range"
                  min="0.1"
                  max="3"
                  step="0.1"
                  value={frequency}
                  onChange={(e) => setFrequency(parseFloat(e.target.value))}
                  className="w-full"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Amplitude: {amplitude.toFixed(1)}
                </label>
                <input
                  type="range"
                  min="0.1"
                  max="2"
                  step="0.1"
                  value={amplitude}
                  onChange={(e) => setAmplitude(parseFloat(e.target.value))}
                  className="w-full"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Phase: {(phase * 180 / Math.PI).toFixed(0)}°
                </label>
                <input
                  type="range"
                  min="0"
                  max={2 * Math.PI}
                  step="0.1"
                  value={phase}
                  onChange={(e) => setPhase(parseFloat(e.target.value))}
                  className="w-full"
                />
              </div>
            </div>
          </div>
        )}
        
        <div className="visualization-container">
          <svg
            ref={svgRef}
            width={width}
            height={height}
            className="border border-gray-100 rounded"
          />
        </div>
        
        <div className="mt-3 text-sm text-gray-600">
          <p>
            This visualization shows different types of electrical waveforms commonly found in AC circuits.
            Adjust the controls to see how frequency, amplitude, and phase affect the waveform shape.
          </p>
        </div>
      </div>
    </div>
  );
}
