"use client";

import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';

interface PowerTriangleVisualizationProps {
  width?: number;
  height?: number;
  className?: string;
  interactive?: boolean;
  showVectors?: boolean;
}

export default function PowerTriangleVisualization({
  width = 400,
  height = 400,
  className = '',
  interactive = true,
  showVectors = true
}: PowerTriangleVisualizationProps) {
  const svgRef = useRef<SVGSVGElement>(null);
  const [realPower, setRealPower] = useState(300); // P (Watts)
  const [reactivePower, setReactivePower] = useState(400); // Q (VAR)
  const [powerFactor, setPowerFactor] = useState(0.75);

  // Calculate derived values
  const apparentPower = Math.sqrt(realPower * realPower + reactivePower * reactivePower); // S (VA)
  const phaseAngle = Math.atan2(reactivePower, realPower) * (180 / Math.PI); // θ in degrees
  const calculatedPF = realPower / apparentPower;

  useEffect(() => {
    if (!svgRef.current) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    const margin = { top: 40, right: 40, bottom: 40, left: 40 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;
    const centerX = innerWidth / 2;
    const centerY = innerHeight / 2;

    // Create main group
    const g = svg.append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    // Scale factor for visualization
    const maxPower = Math.max(realPower, reactivePower, apparentPower);
    const scale = Math.min(centerX, centerY) * 0.8 / maxPower;

    // Calculate triangle points
    const origin = { x: centerX - (realPower * scale) / 2, y: centerY + (reactivePower * scale) / 2 };
    const realPoint = { x: origin.x + realPower * scale, y: origin.y };
    const reactivePoint = { x: origin.x, y: origin.y - reactivePower * scale };

    // Draw coordinate system
    g.append('line')
      .attr('x1', 0)
      .attr('x2', innerWidth)
      .attr('y1', centerY)
      .attr('y2', centerY)
      .attr('stroke', '#e5e7eb')
      .attr('stroke-width', 1);

    g.append('line')
      .attr('x1', centerX)
      .attr('x2', centerX)
      .attr('y1', 0)
      .attr('y2', innerHeight)
      .attr('stroke', '#e5e7eb')
      .attr('stroke-width', 1);

    // Draw power triangle
    const triangleData = [origin, realPoint, reactivePoint, origin];
    
    const line = d3.line<{x: number, y: number}>()
      .x(d => d.x)
      .y(d => d.y);

    // Triangle outline
    g.append('path')
      .datum(triangleData)
      .attr('d', line)
      .attr('fill', 'rgba(59, 130, 246, 0.1)')
      .attr('stroke', '#3b82f6')
      .attr('stroke-width', 2);

    // Draw individual vectors
    if (showVectors) {
      // Real Power (P) - horizontal red vector
      g.append('line')
        .attr('x1', origin.x)
        .attr('x2', realPoint.x)
        .attr('y1', origin.y)
        .attr('y2', realPoint.y)
        .attr('stroke', '#dc2626')
        .attr('stroke-width', 3)
        .attr('marker-end', 'url(#arrowhead-red)');

      // Reactive Power (Q) - vertical blue vector
      g.append('line')
        .attr('x1', origin.x)
        .attr('x2', reactivePoint.x)
        .attr('y1', origin.y)
        .attr('y2', reactivePoint.y)
        .attr('stroke', '#2563eb')
        .attr('stroke-width', 3)
        .attr('marker-end', 'url(#arrowhead-blue)');

      // Apparent Power (S) - diagonal green vector
      g.append('line')
        .attr('x1', origin.x)
        .attr('x2', reactivePoint.x)
        .attr('y1', origin.y)
        .attr('y2', reactivePoint.y)
        .attr('stroke', '#16a34a')
        .attr('stroke-width', 3)
        .attr('marker-end', 'url(#arrowhead-green)');
    }

    // Add arrowhead markers
    const defs = svg.append('defs');
    
    ['red', 'blue', 'green'].forEach((color, index) => {
      const colors = ['#dc2626', '#2563eb', '#16a34a'];
      defs.append('marker')
        .attr('id', `arrowhead-${color}`)
        .attr('viewBox', '0 -5 10 10')
        .attr('refX', 8)
        .attr('refY', 0)
        .attr('markerWidth', 6)
        .attr('markerHeight', 6)
        .attr('orient', 'auto')
        .append('path')
        .attr('d', 'M0,-5L10,0L0,5')
        .attr('fill', colors[index]);
    });

    // Add labels
    const labelOffset = 15;
    
    // Real Power label
    g.append('text')
      .attr('x', (origin.x + realPoint.x) / 2)
      .attr('y', origin.y + labelOffset)
      .attr('text-anchor', 'middle')
      .attr('class', 'power-label')
      .style('font-size', '12px')
      .style('font-weight', 'bold')
      .style('fill', '#dc2626')
      .text(`P = ${realPower.toFixed(0)} W`);

    // Reactive Power label
    g.append('text')
      .attr('x', origin.x - labelOffset)
      .attr('y', (origin.y + reactivePoint.y) / 2)
      .attr('text-anchor', 'middle')
      .attr('class', 'power-label')
      .style('font-size', '12px')
      .style('font-weight', 'bold')
      .style('fill', '#2563eb')
      .text(`Q = ${reactivePower.toFixed(0)} VAR`);

    // Apparent Power label
    g.append('text')
      .attr('x', (origin.x + reactivePoint.x) / 2 - 20)
      .attr('y', (origin.y + reactivePoint.y) / 2 - 10)
      .attr('text-anchor', 'middle')
      .attr('class', 'power-label')
      .style('font-size', '12px')
      .style('font-weight', 'bold')
      .style('fill', '#16a34a')
      .text(`S = ${apparentPower.toFixed(0)} VA`);

    // Phase angle arc
    const arcRadius = 40;
    const arc = d3.arc()
      .innerRadius(0)
      .outerRadius(arcRadius)
      .startAngle(0)
      .endAngle(phaseAngle * Math.PI / 180);

    g.append('path')
      .attr('d', arc as any)
      .attr('transform', `translate(${origin.x},${origin.y})`)
      .attr('fill', 'rgba(251, 191, 36, 0.3)')
      .attr('stroke', '#f59e0b')
      .attr('stroke-width', 1);

    // Phase angle label
    g.append('text')
      .attr('x', origin.x + arcRadius + 10)
      .attr('y', origin.y - 5)
      .attr('class', 'angle-label')
      .style('font-size', '11px')
      .style('fill', '#f59e0b')
      .text(`θ = ${phaseAngle.toFixed(1)}°`);

  }, [realPower, reactivePower, width, height, showVectors]);

  return (
    <div className={`power-triangle-visualization ${className}`}>
      <div className="bg-white border border-gray-200 rounded-lg p-4">
        <h3 className="text-lg font-semibold mb-4">AC Power Triangle</h3>
        
        {interactive && (
          <div className="controls mb-4 space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Real Power (P): {realPower.toFixed(0)} W
                </label>
                <input
                  type="range"
                  min="100"
                  max="500"
                  step="10"
                  value={realPower}
                  onChange={(e) => setRealPower(parseFloat(e.target.value))}
                  className="w-full"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Reactive Power (Q): {reactivePower.toFixed(0)} VAR
                </label>
                <input
                  type="range"
                  min="0"
                  max="500"
                  step="10"
                  value={reactivePower}
                  onChange={(e) => setReactivePower(parseFloat(e.target.value))}
                  className="w-full"
                />
              </div>
            </div>
          </div>
        )}
        
        <div className="visualization-container mb-4">
          <svg
            ref={svgRef}
            width={width}
            height={height}
            className="border border-gray-100 rounded"
          />
        </div>
        
        <div className="power-calculations bg-gray-50 p-3 rounded-lg">
          <h4 className="font-medium text-gray-800 mb-2">Power Calculations:</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
            <div>
              <span className="text-red-600 font-medium">Real Power (P):</span>
              <br />
              {realPower.toFixed(0)} W
            </div>
            <div>
              <span className="text-blue-600 font-medium">Reactive Power (Q):</span>
              <br />
              {reactivePower.toFixed(0)} VAR
            </div>
            <div>
              <span className="text-green-600 font-medium">Apparent Power (S):</span>
              <br />
              {apparentPower.toFixed(0)} VA
            </div>
            <div>
              <span className="text-yellow-600 font-medium">Power Factor:</span>
              <br />
              {calculatedPF.toFixed(3)}
            </div>
          </div>
          
          <div className="mt-3 text-xs text-gray-600">
            <p><strong>Formula:</strong> S² = P² + Q²</p>
            <p><strong>Power Factor:</strong> cos(θ) = P/S = {calculatedPF.toFixed(3)}</p>
            <p><strong>Phase Angle:</strong> θ = arctan(Q/P) = {phaseAngle.toFixed(1)}°</p>
          </div>
        </div>
        
        <div className="mt-3 text-sm text-gray-600">
          <p>
            The power triangle shows the relationship between real power (P), reactive power (Q), 
            and apparent power (S) in AC circuits. Adjust the sliders to see how changes affect 
            the power factor and phase angle.
          </p>
        </div>
      </div>
    </div>
  );
}
