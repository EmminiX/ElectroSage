import React, { useState, useEffect, useRef } from 'react';
import * as d3 from 'd3';

/**
 * Props for the ACWaveformVisualization component
 */
interface ACWaveformVisualizationProps {
  /** Initial frequency in Hertz */
  initialFrequency?: number;
  /** Initial amplitude in Volts */
  initialAmplitude?: number;
  /** Width of the visualization in pixels */
  width?: number;
  /** Height of the visualization in pixels */
  height?: number;
  /** Optional CSS class name */
  className?: string;
}

/**
 * An interactive visualization of AC waveforms
 * Shows sine waves representing alternating current and allows
 * adjustment of frequency and amplitude
 */
const ACWaveformVisualization: React.FC<ACWaveformVisualizationProps> = ({
  initialFrequency = 60,
  initialAmplitude = 5,
  width = 600,
  height = 400,
  className = ''
}) => {
  const [frequency, setFrequency] = useState(initialFrequency);
  const [amplitude, setAmplitude] = useState(initialAmplitude);
  const [isAnimating, setIsAnimating] = useState(true);
  const [phaseShift, setPhaseShift] = useState(0);
  const [showDCComparison, setShowDCComparison] = useState(false);
  
  const svgRef = useRef<SVGSVGElement>(null);
  const tooltipRef = useRef<HTMLDivElement>(null);
  const animationRef = useRef<number | null>(null);
  
  // Handle frequency change
  const handleFrequencyChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    if (!isNaN(value)) {
      setFrequency(value);
    }
  };
  
  // Handle amplitude change
  const handleAmplitudeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    if (!isNaN(value)) {
      setAmplitude(value);
    }
  };
  
  // Toggle animation
  const toggleAnimation = () => {
    setIsAnimating(prev => !prev);
  };
  
  // Toggle DC comparison
  const toggleDCComparison = () => {
    setShowDCComparison(prev => !prev);
  };
  
  // Animate the waveform
  useEffect(() => {
    if (!isAnimating) {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
        animationRef.current = null;
      }
      return;
    }
    
    let animationFrame = 0;
    const startTime = Date.now();
    
    const animate = () => {
      const currentTime = Date.now();
      const elapsed = currentTime - startTime;
      
      // Update phase shift based on elapsed time and frequency
      const newPhaseShift = (elapsed / 1000) * Math.PI * 2 * (frequency / 10);
      setPhaseShift(newPhaseShift % (Math.PI * 2));
      
      animationRef.current = requestAnimationFrame(animate);
    };
    
    animationRef.current = requestAnimationFrame(animate);
    
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
        animationRef.current = null;
      }
    };
  }, [isAnimating, frequency]);
  
  // Draw the visualization
  useEffect(() => {
    if (!svgRef.current) return;
    
    // Clear previous visualization
    d3.select(svgRef.current).selectAll('*').remove();
    
    // SVG dimensions and settings
    const margin = { top: 40, right: 40, bottom: 60, left: 60 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;
    
    // Select the SVG element
    const svg = d3.select(svgRef.current)
      .attr('width', width)
      .attr('height', height);
    
    // Create a group for the visualization content
    const g = svg.append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);
    
    // X axis represents time
    const xScale = d3.scaleLinear()
      .domain([0, 2 * Math.PI])
      .range([0, innerWidth]);
    
    // Y axis represents voltage
    const yScale = d3.scaleLinear()
      .domain([-amplitude * 1.2, amplitude * 1.2])
      .range([innerHeight, 0])
      .nice();
    
    // Create the X axis
    g.append('g')
      .attr('transform', `translate(0,${innerHeight / 2})`)
      .call(d3.axisBottom(xScale).tickFormat((d) => {
        const value = +d;
        if (value === 0) return '0';
        if (value === Math.PI / 2) return 'π/2';
        if (value === Math.PI) return 'π';
        if (value === 3 * Math.PI / 2) return '3π/2';
        if (value === 2 * Math.PI) return '2π';
        return '';
      }))
      .selectAll('text')
      .attr('font-size', '12px');
    
    // X axis label
    g.append('text')
      .attr('x', innerWidth / 2)
      .attr('y', innerHeight + 40)
      .attr('text-anchor', 'middle')
      .attr('fill', 'currentColor')
      .attr('font-size', '14px')
      .text('Time (radians)');
    
    // Create the Y axis
    g.append('g')
      .call(d3.axisLeft(yScale))
      .selectAll('text')
      .attr('font-size', '12px');
    
    // Y axis label
    g.append('text')
      .attr('transform', 'rotate(-90)')
      .attr('x', -innerHeight / 2)
      .attr('y', -40)
      .attr('text-anchor', 'middle')
      .attr('fill', 'currentColor')
      .attr('font-size', '14px')
      .text('Voltage (V)');
    
    // Zero line
    g.append('line')
      .attr('x1', 0)
      .attr('y1', innerHeight / 2)
      .attr('x2', innerWidth)
      .attr('y2', innerHeight / 2)
      .attr('stroke', '#aaa')
      .attr('stroke-width', 1);
    
    // Generate sine wave data points
    const sineWavePoints: { x: number; y: number }[] = [];
    const numPoints = 100;
    
    for (let i = 0; i <= numPoints; i++) {
      const x = (i / numPoints) * 2 * Math.PI;
      const y = amplitude * Math.sin(x + phaseShift);
      sineWavePoints.push({ x, y });
    }
    
    // Draw the sine wave
    const line = d3.line<{ x: number; y: number }>()
      .x(d => xScale(d.x))
      .y(d => yScale(d.y))
      .curve(d3.curveBasis);
    
    g.append('path')
      .datum(sineWavePoints)
      .attr('fill', 'none')
      .attr('stroke', '#4361ee')
      .attr('stroke-width', 2.5)
      .attr('d', line);
    
    // Add DC comparison if enabled
    if (showDCComparison) {
      // Calculate average value (0 for pure sine wave)
      const avgValue = 0;
      
      // RMS value is amplitude / √2 for a sine wave
      const rmsValue = amplitude / Math.sqrt(2);
      
      // Draw RMS line
      g.append('line')
        .attr('x1', 0)
        .attr('y1', yScale(rmsValue))
        .attr('x2', innerWidth)
        .attr('y2', yScale(rmsValue))
        .attr('stroke', '#ff6b6b')
        .attr('stroke-width', 2)
        .attr('stroke-dasharray', '5,5');
      
      g.append('line')
        .attr('x1', 0)
        .attr('y1', yScale(-rmsValue))
        .attr('x2', innerWidth)
        .attr('y2', yScale(-rmsValue))
        .attr('stroke', '#ff6b6b')
        .attr('stroke-width', 2)
        .attr('stroke-dasharray', '5,5');
      
      // Labels for RMS lines
      g.append('text')
        .attr('x', 10)
        .attr('y', yScale(rmsValue) - 5)
        .attr('fill', '#ff6b6b')
        .attr('font-size', '12px')
        .text(`RMS: ${rmsValue.toFixed(1)}V`);
      
      g.append('text')
        .attr('x', 10)
        .attr('y', yScale(-rmsValue) + 15)
        .attr('fill', '#ff6b6b')
        .attr('font-size', '12px')
        .text(`RMS: -${rmsValue.toFixed(1)}V`);
      
      // Draw DC equivalent
      g.append('rect')
        .attr('x', 0)
        .attr('y', yScale(rmsValue))
        .attr('width', innerWidth)
        .attr('height', yScale(-rmsValue) - yScale(rmsValue))
        .attr('fill', '#4361ee')
        .attr('opacity', 0.1);
    }
    
    // Add the title
    svg.append('text')
      .attr('x', width / 2)
      .attr('y', 20)
      .attr('text-anchor', 'middle')
      .attr('font-size', '18px')
      .attr('font-weight', 'bold')
      .text('AC Waveform Visualization');
    
    // Add peak voltage indicators
    g.append('line')
      .attr('x1', 0)
      .attr('y1', yScale(amplitude))
      .attr('x2', innerWidth)
      .attr('y2', yScale(amplitude))
      .attr('stroke', '#aaa')
      .attr('stroke-width', 1)
      .attr('stroke-dasharray', '3,3');
    
    g.append('line')
      .attr('x1', 0)
      .attr('y1', yScale(-amplitude))
      .attr('x2', innerWidth)
      .attr('y2', yScale(-amplitude))
      .attr('stroke', '#aaa')
      .attr('stroke-width', 1)
      .attr('stroke-dasharray', '3,3');
    
    g.append('text')
      .attr('x', innerWidth + 5)
      .attr('y', yScale(amplitude))
      .attr('fill', '#555')
      .attr('font-size', '10px')
      .attr('alignment-baseline', 'middle')
      .text(`+${amplitude}V`);
    
    g.append('text')
      .attr('x', innerWidth + 5)
      .attr('y', yScale(-amplitude))
      .attr('fill', '#555')
      .attr('font-size', '10px')
      .attr('alignment-baseline', 'middle')
      .text(`-${amplitude}V`);
    
    // Add period indicator
    g.append('text')
      .attr('x', innerWidth / 2)
      .attr('y', innerHeight + 20)
      .attr('text-anchor', 'middle')
      .attr('fill', '#555')
      .attr('font-size', '10px')
      .text(`1 cycle = 1/${frequency} s = ${(1000 / frequency).toFixed(1)} ms`);
    
  }, [width, height, frequency, amplitude, phaseShift, showDCComparison]);
  
  return (
    <div className={`max-w-4xl mx-auto p-4 bg-white rounded-lg shadow-md dark:bg-gray-800 ${className}`}>
      <h3 className="text-lg font-bold mb-4 text-gray-800 dark:text-white">AC Waveform Interactive Visualization</h3>
      
      <div className="mb-6 grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="flex flex-col">
          <label htmlFor="frequency" className="mb-2 font-medium text-gray-700 dark:text-gray-300">
            Frequency (Hz)
          </label>
          <div className="flex items-center">
            <input
              type="range"
              id="frequency"
              min="1"
              max="120"
              step="1"
              value={frequency}
              onChange={handleFrequencyChange}
              className="w-full"
              aria-label="Adjust frequency"
            />
            <span className="ml-2 w-16 text-right text-gray-700 dark:text-gray-300">
              {frequency} Hz
            </span>
          </div>
        </div>
        
        <div className="flex flex-col">
          <label htmlFor="amplitude" className="mb-2 font-medium text-gray-700 dark:text-gray-300">
            Amplitude (V)
          </label>
          <div className="flex items-center">
            <input
              type="range"
              id="amplitude"
              min="1"
              max="10"
              step="0.5"
              value={amplitude}
              onChange={handleAmplitudeChange}
              className="w-full"
              aria-label="Adjust amplitude"
            />
            <span className="ml-2 w-16 text-right text-gray-700 dark:text-gray-300">
              {amplitude} V
            </span>
          </div>
        </div>
      </div>
      
      <div className="mb-4 flex flex-wrap gap-4 justify-start">
        <button
          onClick={toggleAnimation}
          className="px-4 py-2 bg-voltage-500 text-white rounded hover:bg-voltage-600 focus:outline-none focus:ring-2 focus:ring-voltage-300"
          aria-label={isAnimating ? "Pause animation" : "Start animation"}
        >
          {isAnimating ? 'Pause Animation' : 'Start Animation'}
        </button>
        
        <button
          onClick={toggleDCComparison}
          className={`px-4 py-2 rounded focus:outline-none focus:ring-2 focus:ring-voltage-300 ${
            showDCComparison 
              ? 'bg-voltage-500 text-white hover:bg-voltage-600' 
              : 'bg-gray-200 text-gray-800 hover:bg-gray-300 dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600'
          }`}
          aria-label={showDCComparison ? "Hide DC comparison" : "Show DC comparison"}
        >
          {showDCComparison ? 'Hide DC Comparison' : 'Show DC Comparison'}
        </button>
      </div>
      
      <div className="relative overflow-hidden">
        <svg 
          ref={svgRef} 
          className="w-full h-auto bg-white dark:bg-gray-900 rounded-lg"
          role="img"
          aria-labelledby="ac-waveform-title"
        >
          <title id="ac-waveform-title">AC Waveform Visualization</title>
        </svg>
        <div 
          ref={tooltipRef}
          className="absolute hidden bg-black bg-opacity-80 text-white p-2 rounded text-xs pointer-events-none"
          style={{visibility: 'hidden'}}
        ></div>
      </div>
      
      <div className="mt-4 text-sm text-gray-700 dark:text-gray-300">
        <p><strong>AC (Alternating Current)</strong> periodically changes direction and magnitude following a sine wave pattern.</p>
        <ul className="list-disc pl-5 mt-2">
          <li>Adjust the frequency slider to change how many cycles occur per second</li>
          <li>Adjust the amplitude slider to change the peak voltage</li>
          <li>The RMS (Root Mean Square) value shows the equivalent DC voltage that would produce the same average power</li>
          <li>For a sine wave, the RMS value is the peak value divided by √2 (approximately 0.707 × peak)</li>
          <li>Most household electricity is AC at 50Hz or 60Hz depending on your country</li>
        </ul>
      </div>
    </div>
  );
};

export default ACWaveformVisualization;
