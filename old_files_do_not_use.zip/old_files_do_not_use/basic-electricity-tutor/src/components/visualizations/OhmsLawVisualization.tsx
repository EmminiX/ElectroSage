import React, { useState, useEffect, useRef } from 'react';
import * as d3 from 'd3';

/**
 * Props for the OhmsLawVisualization component
 */
interface OhmsLawVisualizationProps {
  /** Optional initial voltage value in volts */
  initialVoltage?: number;
  /** Optional initial current value in amperes */
  initialCurrent?: number;
  /** Optional initial resistance value in ohms */
  initialResistance?: number;
}

/**
 * An interactive visualization demonstrating Ohm's Law (V = I × R)
 * Allows users to adjust voltage, current, or resistance and see how the other values change
 */
const OhmsLawVisualization: React.FC<OhmsLawVisualizationProps> = ({ 
  initialVoltage = 12, 
  initialCurrent = 2,
  initialResistance = 6
}) => {
  const [voltage, setVoltage] = useState(initialVoltage);
  const [current, setCurrent] = useState(initialCurrent);
  const [resistance, setResistance] = useState(initialResistance);
  const [activeAdjustment, setActiveAdjustment] = useState<'voltage' | 'current' | 'resistance'>('resistance');
  
  const svgRef = useRef<SVGSVGElement>(null);
  const tooltipRef = useRef<HTMLDivElement>(null);
  
  // Calculate the dependent value based on which two values are being directly adjusted
  useEffect(() => {
    if (activeAdjustment === 'voltage') {
      // V = I × R
      setVoltage(Number((current * resistance).toFixed(2)));
    } else if (activeAdjustment === 'current') {
      // I = V / R
      if (resistance !== 0) {
        setCurrent(Number((voltage / resistance).toFixed(2)));
      }
    } else if (activeAdjustment === 'resistance') {
      // R = V / I
      if (current !== 0) {
        setResistance(Number((voltage / current).toFixed(2)));
      }
    }
  }, [voltage, current, resistance, activeAdjustment]);
  
  // Handle input changes for each parameter
  const handleVoltageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    if (!isNaN(value)) {
      setVoltage(value);
      setActiveAdjustment('voltage');
    }
  };
  
  const handleCurrentChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    if (!isNaN(value)) {
      setCurrent(value);
      setActiveAdjustment('current');
    }
  };
  
  const handleResistanceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    if (!isNaN(value) && value !== 0) {
      setResistance(value);
      setActiveAdjustment('resistance');
    }
  };
  
  // Create or update the visualization using D3
  useEffect(() => {
    if (!svgRef.current) return;
    
    // Clear previous visualization
    d3.select(svgRef.current).selectAll("*").remove();
    
    // SVG dimensions and settings
    const width = 600;
    const height = 400;
    const margin = { top: 40, right: 40, bottom: 60, left: 60 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;
    
    // Select the SVG element
    const svg = d3.select(svgRef.current)
      .attr("width", width)
      .attr("height", height);
    
    // Create a group for the visualization content
    const g = svg.append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`);
    
    // Calculate the maximum values for the axes
    const maxVoltage = Math.max(voltage * 2, 20);
    const maxCurrent = Math.max(current * 2, 5);
    
    // Create scales for the axes
    const xScale = d3.scaleLinear()
      .domain([0, maxCurrent])
      .range([0, innerWidth])
      .nice();
    
    const yScale = d3.scaleLinear()
      .domain([0, maxVoltage])
      .range([innerHeight, 0])
      .nice();
    
    // Create the X axis
    g.append("g")
      .attr("transform", `translate(0,${innerHeight})`)
      .call(d3.axisBottom(xScale))
      .selectAll("text")
      .attr("font-size", "12px");
    
    // X axis label
    g.append("text")
      .attr("x", innerWidth / 2)
      .attr("y", innerHeight + 40)
      .attr("text-anchor", "middle")
      .attr("fill", "currentColor")
      .attr("font-size", "14px")
      .text("Current (I) in Amperes");
    
    // Create the Y axis
    g.append("g")
      .call(d3.axisLeft(yScale))
      .selectAll("text")
      .attr("font-size", "12px");
    
    // Y axis label
    g.append("text")
      .attr("transform", "rotate(-90)")
      .attr("x", -innerHeight / 2)
      .attr("y", -40)
      .attr("text-anchor", "middle")
      .attr("fill", "currentColor")
      .attr("font-size", "14px")
      .text("Voltage (V) in Volts");
    
    // Calculate points for the resistance lines
    const getResistanceLine = (r: number) => {
      return [
        { x: 0, y: 0 },
        { x: maxCurrent, y: maxCurrent * r }
      ].filter(d => d.y <= maxVoltage); // Ensure points are within the visible area
    };
    
    // Draw multiple resistance lines
    const resistanceValues = [1, 2, 5, 10, 20];
    resistanceValues.forEach(r => {
      const lineData = getResistanceLine(r);
      
      if (lineData.length >= 2) {
        const line = d3.line<{x: number, y: number}>()
          .x(d => xScale(d.x))
          .y(d => yScale(d.y));
          
        g.append("path")
          .datum(lineData)
          .attr("fill", "none")
          .attr("stroke", "#ddd")
          .attr("stroke-width", 1)
          .attr("stroke-dasharray", "5,5")
          .attr("d", line);
        
        // Add resistance value label at the end of the line
        const lastPoint = lineData[lineData.length - 1];
        g.append("text")
          .attr("x", xScale(lastPoint.x) - 30)
          .attr("y", yScale(lastPoint.y))
          .attr("fill", "#999")
          .attr("font-size", "10px")
          .text(`${r}Ω`);
      }
    });
    
    // Draw the current resistance line
    const currentResistanceLine = getResistanceLine(resistance);
    
    if (currentResistanceLine.length >= 2) {
      const line = d3.line<{x: number, y: number}>()
        .x(d => xScale(d.x))
        .y(d => yScale(d.y));
        
      g.append("path")
        .datum(currentResistanceLine)
        .attr("fill", "none")
        .attr("stroke", "#ff6b6b")
        .attr("stroke-width", 2)
        .attr("d", line);
      
      // Add resistance value label
      g.append("text")
        .attr("x", xScale(maxCurrent / 2))
        .attr("y", yScale((maxCurrent / 2) * resistance) - 10)
        .attr("fill", "#ff6b6b")
        .attr("font-size", "12px")
        .attr("font-weight", "bold")
        .attr("text-anchor", "middle")
        .text(`R = ${resistance}Ω`);
    }
    
    // Add a point for the current V-I values
    g.append("circle")
      .attr("cx", xScale(current))
      .attr("cy", yScale(voltage))
      .attr("r", 8)
      .attr("fill", "#4361ee")
      .attr("stroke", "#fff")
      .attr("stroke-width", 2)
      .attr("cursor", "pointer")
      .on("mouseover", function(event) {
        if (tooltipRef.current) {
          d3.select(tooltipRef.current)
            .style("visibility", "visible")
            .style("left", `${event.pageX + 10}px`)
            .style("top", `${event.pageY - 30}px`)
            .html(`
              <strong>Voltage (V):</strong> ${voltage}V<br>
              <strong>Current (I):</strong> ${current}A<br>
              <strong>Resistance (R):</strong> ${resistance}Ω
            `);
        }
      })
      .on("mouseout", function() {
        if (tooltipRef.current) {
          d3.select(tooltipRef.current)
            .style("visibility", "hidden");
        }
      });
    
    // Add the title
    svg.append("text")
      .attr("x", width / 2)
      .attr("y", 20)
      .attr("text-anchor", "middle")
      .attr("font-size", "18px")
      .attr("font-weight", "bold")
      .text("Ohm's Law Visualization: V = I × R");
  }, [voltage, current, resistance]);
  
  return (
    <div className="max-w-4xl mx-auto p-4 bg-white rounded-lg shadow-md dark:bg-gray-800">
      <h3 className="text-lg font-bold mb-4 text-gray-800 dark:text-white">Ohm's Law Interactive Visualization</h3>
      
      <div className="mb-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="flex flex-col">
          <label htmlFor="voltage" className="mb-2 font-medium text-gray-700 dark:text-gray-300">
            Voltage (V)
          </label>
          <div className="flex items-center">
            <input
              type="range"
              id="voltage"
              min="0"
              max="50"
              step="0.1"
              value={voltage}
              onChange={handleVoltageChange}
              className="w-full"
              aria-label="Adjust voltage"
            />
            <span className="ml-2 w-16 text-right text-gray-700 dark:text-gray-300">
              {voltage}V
            </span>
          </div>
        </div>
        
        <div className="flex flex-col">
          <label htmlFor="current" className="mb-2 font-medium text-gray-700 dark:text-gray-300">
            Current (I)
          </label>
          <div className="flex items-center">
            <input
              type="range"
              id="current"
              min="0.1"
              max="10"
              step="0.1"
              value={current}
              onChange={handleCurrentChange}
              className="w-full"
              aria-label="Adjust current"
            />
            <span className="ml-2 w-16 text-right text-gray-700 dark:text-gray-300">
              {current}A
            </span>
          </div>
        </div>
        
        <div className="flex flex-col">
          <label htmlFor="resistance" className="mb-2 font-medium text-gray-700 dark:text-gray-300">
            Resistance (R)
          </label>
          <div className="flex items-center">
            <input
              type="range"
              id="resistance"
              min="0.1"
              max="20"
              step="0.1"
              value={resistance}
              onChange={handleResistanceChange}
              className="w-full"
              aria-label="Adjust resistance"
            />
            <span className="ml-2 w-16 text-right text-gray-700 dark:text-gray-300">
              {resistance}Ω
            </span>
          </div>
        </div>
      </div>
      
      <div className="mb-4 text-center bg-voltage-50 dark:bg-voltage-900 p-3 rounded-md">
        <div className="text-xl font-bold text-gray-800 dark:text-white">
          V = I × R &nbsp;→&nbsp; {voltage}V = {current}A × {resistance}Ω
        </div>
        <div className="text-sm text-gray-600 dark:text-gray-400 mt-1">
          {activeAdjustment === 'voltage' 
            ? 'Voltage is calculated from current and resistance'
            : activeAdjustment === 'current'
              ? 'Current is calculated from voltage and resistance'
              : 'Resistance is calculated from voltage and current'
          }
        </div>
      </div>
      
      <div className="relative overflow-hidden">
        <svg ref={svgRef} className="w-full h-auto bg-white dark:bg-gray-900 rounded-lg"></svg>
        <div 
          ref={tooltipRef}
          className="absolute hidden bg-black bg-opacity-80 text-white p-2 rounded text-xs pointer-events-none"
          style={{visibility: 'hidden'}}
        ></div>
      </div>
      
      <div className="mt-4 text-sm text-gray-700 dark:text-gray-300">
        <p><strong>Ohm's Law</strong> states that the current through a conductor between two points is directly proportional to the voltage across the two points.</p>
        <ul className="list-disc pl-5 mt-2">
          <li>Adjust any slider to see how it affects the other values</li>
          <li>The red line shows your current resistance value</li>
          <li>Dotted lines represent reference resistance values</li>
          <li>Hover over the blue point to see exact values</li>
        </ul>
      </div>
    </div>
  );
};

export default OhmsLawVisualization;
