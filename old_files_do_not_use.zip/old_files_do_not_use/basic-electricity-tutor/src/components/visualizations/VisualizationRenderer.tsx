"use client";

import React from 'react';
import { IVisualization } from '@/types/content';
import OhmsLawVisualization from './OhmsLawVisualization';
import AtomicModelVisualization from './AtomicModelVisualization';
import CircuitVisualization from './CircuitVisualization';
import WaveformVisualization from './WaveformVisualization';
import PowerTriangleVisualization from './PowerTriangleVisualization';

interface VisualizationRendererProps {
  visualization: IVisualization;
  className?: string;
}

/**
 * VisualizationRenderer component that renders the appropriate visualization
 * based on the visualization type and configuration
 */
export default function VisualizationRenderer({ 
  visualization,
  className = ''
}: VisualizationRendererProps) {
  const { type, configData = {} } = visualization;

  switch (type) {
    case 'circuit':
      return (
        <CircuitVisualization 
          elements={configData.elements || []}
          connections={configData.connections || []}
          width={configData.width || 600}
          height={configData.height || 400}
          className={className}
          animate={configData.animate !== false}
        />
      );
      
    case 'atomic':
      return (
        <AtomicModelVisualization 
          element={configData.element || 'Generic'}
          protons={configData.protons || 4}
          neutrons={configData.neutrons || 5}
          electrons={configData.electrons || 4}
          shells={configData.shells || [2, 2]}
          width={configData.width || 400}
          height={configData.height || 400}
          className={className}
        />
      );
      
    case 'waveform':
      return (
        <WaveformVisualization
          className={className}
          {...configData}
        />
      );
      
    case 'power-triangle':
      return (
        <PowerTriangleVisualization
          className={className}
          {...configData}
        />
      );
      
    case 'graph':
      if (configData.type === 'ohms-law') {
        return (
          <OhmsLawVisualization 
            initialVoltage={configData.voltage || 5}
            initialCurrent={configData.current || 0.5}
            initialResistance={configData.resistance || 10}
          />
        );
      }
      return (
        <div className={`visualization-placeholder ${className}`}>
          <p>Graph visualization type "{configData.type}" not implemented yet</p>
        </div>
      );
      
    default:
      return (
        <div className={`visualization-placeholder ${className}`}>
          <p>Visualization type "{type}" not implemented yet</p>
        </div>
      );
  }

  return (
    <div className={`visualization-container ${className}`}>
      <div className="visualization-header mb-3">
        <h3 className="text-lg font-semibold text-gray-800">
          {visualization.title}
        </h3>
        {visualization.description && (
          <p className="text-sm text-gray-600 mt-1">
            {visualization.description}
          </p>
        )}
      </div>
      <div className="visualization-content">
        {/* Visualization content is rendered by the switch statement above */}
      </div>
    </div>
  );
}
