import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';

interface CircuitElement {
  id: string;
  type: 'battery' | 'resistor' | 'wire' | 'bulb' | 'switch';
  x: number;
  y: number;
  rotation?: number;
  value?: number;
  state?: 'open' | 'closed';
}

interface CircuitConnection {
  source: string;
  target: string;
}

interface CircuitVisualizationProps {
  elements: CircuitElement[];
  connections: CircuitConnection[];
  width?: number;
  height?: number;
  className?: string;
  animate?: boolean;
}

export default function CircuitVisualization({
  elements,
  connections,
  width = 600,
  height = 400,
  className = '',
  animate = true
}: CircuitVisualizationProps) {
  const svgRef = useRef<SVGSVGElement>(null);
  
  useEffect(() => {
    if (!svgRef.current) return;
    
    // Clear previous content
    d3.select(svgRef.current).selectAll('*').remove();
    
    // Create SVG container
    const svg = d3.select(svgRef.current)
      .attr('viewBox', `0 0 ${width} ${height}`)
      .attr('width', '100%')
      .attr('height', '100%');
      
    // Create definitions for component symbols
    const defs = svg.append('defs');
    
    // Battery symbol
    defs.append('symbol')
      .attr('id', 'battery')
      .attr('viewBox', '0 0 40 20')
      .append('g')
      .call(g => {
        g.append('line')
          .attr('x1', 0).attr('y1', 10)
          .attr('x2', 12).attr('y2', 10)
          .attr('stroke', 'black').attr('stroke-width', 2);
        g.append('line')
          .attr('x1', 12).attr('y1', 2)
          .attr('x2', 12).attr('y2', 18)
          .attr('stroke', 'black').attr('stroke-width', 2);
        g.append('line')
          .attr('x1', 18).attr('y1', 5)
          .attr('x2', 18).attr('y2', 15)
          .attr('stroke', 'black').attr('stroke-width', 2);
        g.append('line')
          .attr('x1', 18).attr('y1', 10)
          .attr('x2', 40).attr('y2', 10)
          .attr('stroke', 'black').attr('stroke-width', 2);
        
        g.append('text')
          .attr('x', 30).attr('y', 8)
          .attr('font-size', 8)
          .text('+');
          
        g.append('text')
          .attr('x', 6).attr('y', 8)
          .attr('font-size', 8)
          .text('-');
      });
    
    // Resistor symbol
    defs.append('symbol')
      .attr('id', 'resistor')
      .attr('viewBox', '0 0 40 20')
      .append('g')
      .call(g => {
        g.append('line')
          .attr('x1', 0).attr('y1', 10)
          .attr('x2', 5).attr('y2', 10)
          .attr('stroke', 'black').attr('stroke-width', 2);
        g.append('path')
          .attr('d', 'M5,10 L8,5 L13,15 L18,5 L23,15 L28,5 L33,15 L36,10')
          .attr('fill', 'none')
          .attr('stroke', 'black')
          .attr('stroke-width', 2);
        g.append('line')
          .attr('x1', 36).attr('y1', 10)
          .attr('x2', 40).attr('y2', 10)
          .attr('stroke', 'black').attr('stroke-width', 2);
      });
    
    // Bulb symbol
    defs.append('symbol')
      .attr('id', 'bulb')
      .attr('viewBox', '0 0 40 30')
      .append('g')
      .call(g => {
        g.append('line')
          .attr('x1', 0).attr('y1', 15)
          .attr('x2', 10).attr('y2', 15)
          .attr('stroke', 'black').attr('stroke-width', 2);
        g.append('circle')
          .attr('cx', 20).attr('cy', 15)
          .attr('r', 10)
          .attr('stroke', 'black')
          .attr('stroke-width', 2)
          .attr('fill', 'white');
        g.append('line')
          .attr('x1', 15).attr('y1', 10)
          .attr('x2', 25).attr('y2', 20)
          .attr('stroke', 'black').attr('stroke-width', 1);
        g.append('line')
          .attr('x1', 15).attr('y1', 20)
          .attr('x2', 25).attr('y2', 10)
          .attr('stroke', 'black').attr('stroke-width', 1);
        g.append('line')
          .attr('x1', 30).attr('y1', 15)
          .attr('x2', 40).attr('y2', 15)
          .attr('stroke', 'black').attr('stroke-width', 2);
      });
    
    // Switch symbol
    defs.append('symbol')
      .attr('id', 'switch-open')
      .attr('viewBox', '0 0 40 20')
      .append('g')
      .call(g => {
        g.append('line')
          .attr('x1', 0).attr('y1', 10)
          .attr('x2', 10).attr('y2', 10)
          .attr('stroke', 'black').attr('stroke-width', 2);
        g.append('circle')
          .attr('cx', 10).attr('cy', 10)
          .attr('r', 2)
          .attr('stroke', 'black')
          .attr('fill', 'black');
        g.append('line')
          .attr('x1', 10).attr('y1', 10)
          .attr('x2', 30).attr('y2', 2)
          .attr('stroke', 'black').attr('stroke-width', 2);
        g.append('circle')
          .attr('cx', 30).attr('cy', 10)
          .attr('r', 2)
          .attr('stroke', 'black')
          .attr('fill', 'white');
        g.append('line')
          .attr('x1', 30).attr('y1', 10)
          .attr('x2', 40).attr('y2', 10)
          .attr('stroke', 'black').attr('stroke-width', 2);
      });
    
    defs.append('symbol')
      .attr('id', 'switch-closed')
      .attr('viewBox', '0 0 40 20')
      .append('g')
      .call(g => {
        g.append('line')
          .attr('x1', 0).attr('y1', 10)
          .attr('x2', 10).attr('y2', 10)
          .attr('stroke', 'black').attr('stroke-width', 2);
        g.append('circle')
          .attr('cx', 10).attr('cy', 10)
          .attr('r', 2)
          .attr('stroke', 'black')
          .attr('fill', 'black');
        g.append('line')
          .attr('x1', 10).attr('y1', 10)
          .attr('x2', 30).attr('y2', 10)
          .attr('stroke', 'black').attr('stroke-width', 2);
        g.append('circle')
          .attr('cx', 30).attr('cy', 10)
          .attr('r', 2)
          .attr('stroke', 'black')
          .attr('fill', 'white');
        g.append('line')
          .attr('x1', 30).attr('y1', 10)
          .attr('x2', 40).attr('y2', 10)
          .attr('stroke', 'black').attr('stroke-width', 2);
      });
    
    // Electron particles for animation
    if (animate) {
      defs.append('symbol')
        .attr('id', 'electron')
        .attr('viewBox', '0 0 6 6')
        .append('circle')
        .attr('cx', 3)
        .attr('cy', 3)
        .attr('r', 3)
        .attr('fill', 'blue')
        .attr('opacity', 0.7);
    }
    
    // Create connections (wires)
    const wireGroup = svg.append('g').attr('class', 'wires');
    
    // Create a layout of elements as a map for easy lookup
    const elementsMap = new Map(elements.map(el => [el.id, el]));
    
    connections.forEach((conn, index) => {
      const source = elementsMap.get(conn.source);
      const target = elementsMap.get(conn.target);
      
      if (!source || !target) return;
      
      const wire = wireGroup.append('line')
        .attr('x1', source.x)
        .attr('y1', source.y)
        .attr('x2', target.x)
        .attr('y2', target.y)
        .attr('stroke', 'black')
        .attr('stroke-width', 2);
      
      // Add electron flow animation
      if (animate) {
        const totalLength = Math.sqrt(
          Math.pow(target.x - source.x, 2) + 
          Math.pow(target.y - source.y, 2)
        );
        
        // Create electron particles along the wire
        const numParticles = Math.ceil(totalLength / 30);
        
        for (let i = 0; i < numParticles; i++) {
          const particle = svg.append('use')
            .attr('href', '#electron')
            .attr('width', 8)
            .attr('height', 8)
            .attr('x', -4)
            .attr('y', -4);
          
          // Create animation for the particle
          function animateParticle() {
            const duration = 2000;
            const initialOffset = (i / numParticles) * duration;
            
            particle.attr('opacity', 0)
              .attr('transform', `translate(${source.x}, ${source.y})`)
              .transition()
              .delay(initialOffset)
              .duration(0)
              .attr('opacity', 0.8)
              .transition()
              .duration(duration)
              .ease(d3.easeLinear)
              .attr('transform', `translate(${target.x}, ${target.y})`)
              .attr('opacity', 0)
              .on('end', animateParticle);
          }
          
          animateParticle();
        }
      }
    });
    
    // Create circuit elements
    const componentsGroup = svg.append('g').attr('class', 'components');
    
    elements.forEach(el => {
      const component = componentsGroup.append('g')
        .attr('transform', `translate(${el.x}, ${el.y})${el.rotation ? ` rotate(${el.rotation})` : ''}`)
        .attr('class', el.type);
      
      let symbolId;
      let width = 40;
      let height = 20;
      
      switch (el.type) {
        case 'battery':
          symbolId = 'battery';
          break;
        case 'resistor':
          symbolId = 'resistor';
          break;
        case 'bulb':
          symbolId = 'bulb';
          height = 30;
          break;
        case 'switch':
          symbolId = el.state === 'closed' ? 'switch-closed' : 'switch-open';
          break;
        default:
          return; // Skip unknown components
      }
      
      component.append('use')
        .attr('href', `#${symbolId}`)
        .attr('width', width)
        .attr('height', height)
        .attr('x', -width / 2)
        .attr('y', -height / 2);
      
      // Add value label for components that have values
      if (el.value !== undefined) {
        component.append('text')
          .attr('x', 0)
          .attr('y', height / 2 + 15)
          .attr('text-anchor', 'middle')
          .attr('font-size', 10)
          .text(el.type === 'resistor' ? `${el.value} Ω` : 
                el.type === 'battery' ? `${el.value} V` : 
                `${el.value}`);
      }
      
      // Add interactivity for switches
      if (el.type === 'switch') {
        component.style('cursor', 'pointer');
        component.on('click', function() {
          // In a real implementation, we would update the state and re-render
          console.log(`Switch ${el.id} clicked`);
        });
      }
    });
    
    return () => {
      // Clean up animations on component unmount
    };
  }, [elements, connections, width, height, animate]);
  
  return (
    <div className={`circuit-visualization ${className}`}>
      <svg ref={svgRef} className="w-full h-full"></svg>
    </div>
  );
}
