"use client";

import React, { useState } from 'react';
import { ISection } from '@/types/content';
import VisualizationRenderer from '../visualizations/VisualizationRenderer';
import QuizComponent from '../quiz/QuizComponent';

type ContentPanelProps = {
  sections: ISection[];
  currentSection?: ISection | null;
  onSectionChange: (section: ISection) => void;
};

export default function ContentPanel({ 
  sections, 
  currentSection, 
  onSectionChange 
}: ContentPanelProps) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [readingMode, setReadingMode] = useState<'normal' | 'focus' | 'guided'>('normal');

  const currentIndex = sections.findIndex(section => section.id === currentSection?.id);
  const hasNext = currentIndex < sections.length - 1;
  const hasPrevious = currentIndex > 0;

  const handleNext = () => {
    if (hasNext) {
      onSectionChange(sections[currentIndex + 1]);
    }
  };

  const handlePrevious = () => {
    if (hasPrevious) {
      onSectionChange(sections[currentIndex - 1]);
    }
  };

  return (
    <div className="flex h-full bg-gray-50" role="main" aria-label="Educational content">
      {/* Accessible Navigation Sidebar */}
      <nav 
        id="navigation"
        className={`
          flex-shrink-0 bg-white border-r-2 border-neutral-200 transition-all duration-300 overflow-y-auto shadow-gentle
          ${isSidebarOpen ? 'w-72 lg:w-80' : 'w-0'}
        `}
        role="navigation"
        aria-label="Course sections"
      >
        <div className="p-4 lg:p-6">
          {/* Navigation Header */}
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg lg:text-xl font-semibold text-neutral-800">
              Course Contents
            </h2>
            <div className="text-sm text-neutral-600 bg-neutral-100 px-3 py-1 rounded-full">
              {currentIndex + 1} of {sections.length}
            </div>
          </div>

          {/* Progress Bar */}
          <div className="mb-6">
            <div className="flex justify-between text-sm text-neutral-600 mb-2">
              <span>Progress</span>
              <span>{Math.round(((currentIndex + 1) / sections.length) * 100)}%</span>
            </div>
            <div className="w-full bg-neutral-200 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-voltage-500 to-current-500 h-2 rounded-full transition-all duration-500"
                style={{ width: `${((currentIndex + 1) / sections.length) * 100}%` }}
                role="progressbar"
                aria-valuenow={currentIndex + 1}
                aria-valuemin={0}
                aria-valuemax={sections.length}
                aria-label={`Course progress: ${currentIndex + 1} of ${sections.length} sections completed`}
              />
            </div>
          </div>

          {/* Section Navigation */}
          <div className="space-y-2">
            {sections.map((section, index) => (
              <button
                key={section.id}
                onClick={() => onSectionChange(section)}
                className={`
                  w-full px-4 py-3 rounded-lg text-left transition-all duration-200 focus-visible-ring
                  ${currentSection?.id === section.id
                    ? 'bg-voltage-100 text-voltage-800 border-2 border-voltage-300 shadow-moderate'
                    : 'text-neutral-700 hover:bg-neutral-100 border-2 border-transparent hover:border-neutral-200'}
                `}
                aria-current={currentSection?.id === section.id ? 'page' : undefined}
                aria-describedby={`section-${index}-description`}
              >
                <div className="flex items-start space-x-3">
                  <div className={`
                    flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold mt-0.5
                    ${currentSection?.id === section.id
                      ? 'bg-voltage-600 text-white'
                      : index < currentIndex
                      ? 'bg-current-500 text-white'
                      : 'bg-neutral-300 text-neutral-600'}
                  `}>
                    {index < currentIndex ? '✓' : index + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium text-sm lg:text-base leading-tight mb-1">
                      {section.title}
                    </h3>
                    <p 
                      id={`section-${index}-description`}
                      className="text-xs lg:text-sm text-neutral-600 line-clamp-2"
                    >
                      {section.rawContent.substring(0, 100)}...
                    </p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Content Header with Controls */}
        <div className="bg-white border-b-2 border-neutral-200 px-4 lg:px-6 py-4 shadow-gentle">
          <div className="flex items-center justify-between">
            {/* Sidebar Toggle */}
            <button
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="lg:hidden p-2 rounded-md text-neutral-600 hover:bg-neutral-100 focus-visible-ring"
              aria-label={isSidebarOpen ? 'Close navigation' : 'Open navigation'}
              aria-expanded={isSidebarOpen}
              aria-controls="navigation"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/>
              </svg>
            </button>

            {/* Reading Mode Controls */}
            <div className="flex items-center space-x-2">
              <label htmlFor="reading-mode" className="text-sm font-medium text-neutral-700">
                Reading Mode:
              </label>
              <select
                id="reading-mode"
                value={readingMode}
                onChange={(e) => setReadingMode(e.target.value as any)}
                className="text-sm border-2 border-neutral-300 rounded-md px-3 py-1 bg-white focus-visible-ring"
              >
                <option value="normal">Normal</option>
                <option value="focus">Focus Mode</option>
                <option value="guided">Guided Reading</option>
              </select>
            </div>

            {/* Navigation Controls */}
            <div className="flex items-center space-x-2">
              <button
                onClick={handlePrevious}
                disabled={!hasPrevious}
                className="px-3 py-2 text-sm font-medium text-neutral-700 bg-white border-2 border-neutral-300 rounded-md hover:bg-neutral-50 disabled:opacity-50 disabled:cursor-not-allowed focus-visible-ring"
                aria-label="Go to previous section"
              >
                ← Previous
              </button>
              <button
                onClick={handleNext}
                disabled={!hasNext}
                className="px-3 py-2 text-sm font-medium text-white bg-voltage-600 border-2 border-voltage-600 rounded-md hover:bg-voltage-700 disabled:opacity-50 disabled:cursor-not-allowed focus-visible-ring"
                aria-label="Go to next section"
              >
                Next →
              </button>
            </div>
          </div>
        </div>

        {/* Content Display */}
        <div 
          id="main-content"
          className="flex-1 overflow-y-auto p-4 lg:p-6"
          role="main"
          aria-live="polite"
          aria-label="Section content"
        >
          {currentSection ? (
            <ContentRenderer 
              section={currentSection} 
              readingMode={readingMode}
            />
          ) : (
            <div className="flex items-center justify-center h-full">
              <div className="text-center">
                <div className="w-16 h-16 bg-neutral-200 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-neutral-400" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                  </svg>
                </div>
                <h2 className="text-xl font-semibold text-neutral-800 mb-2">
                  Welcome to Basic Electricity Tutor
                </h2>
                <p className="text-neutral-600 max-w-md">
                  Select a section from the navigation to begin your learning journey.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function ContentRenderer({ section, readingMode }: { section: ISection; readingMode: string }) {
  const contentClass = readingMode === 'focus' ? 'focus-mode' : '';
  const guidedClass = readingMode === 'guided' ? 'reading-guide' : '';

  return (
    <article className={`max-w-4xl mx-auto ${contentClass}`}>
      {/* Section Header */}
      <header className="mb-8">
        <h1 className="text-2xl lg:text-3xl font-semibold text-neutral-800 mb-4 leading-tight">
          {section.title}
        </h1>
        <div className="flex items-center space-x-4 text-sm text-neutral-600">
          <span className="flex items-center space-x-1">
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
            </svg>
            <span>Reading Time: ~{Math.ceil(section.rawContent.length / 1000)} min</span>
          </span>
        </div>
      </header>

      {/* Content Body */}
      <div className={`prose prose-lg max-w-none ${guidedClass}`}>
        <div 
          className="text-chunk"
          dangerouslySetInnerHTML={{ __html: section.contentHtml }}
        />
      </div>

      {/* Interactive Elements */}
      <div className="mt-8 space-y-6">
        {/* Visualization */}
        {section.visualizations && section.visualizations.length > 0 && (
          <section className="bg-white rounded-lg border-2 border-neutral-200 p-6 shadow-gentle">
            <h2 className="text-xl font-semibold text-neutral-800 mb-4">
              Interactive Visualization
            </h2>
            {section.visualizations.map((visualization) => (
              <VisualizationRenderer 
                key={visualization.id}
                visualization={visualization} 
              />
            ))}
          </section>
        )}

        {/* Quiz */}
        {section.practiceQuestions && section.practiceQuestions.length > 0 && (
          <section className="bg-white rounded-lg border-2 border-neutral-200 p-6 shadow-gentle">
            <h2 className="text-xl font-semibold text-neutral-800 mb-4">
              Knowledge Check
            </h2>
            <QuizComponent questions={section.practiceQuestions} />
          </section>
        )}
      </div>
    </article>
  );
}
