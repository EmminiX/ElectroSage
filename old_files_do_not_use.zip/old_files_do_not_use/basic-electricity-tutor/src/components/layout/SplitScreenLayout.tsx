"use client";

import React, { ReactNode, useState } from 'react';

type SplitScreenLayoutProps = {
  contentPanel: ReactNode;
  aiChatPanel: ReactNode;
};

export default function SplitScreenLayout({ contentPanel, aiChatPanel }: SplitScreenLayoutProps) {
  const [splitPosition, setSplitPosition] = useState(60); // Default split: 60% content, 40% chat
  const [isDragging, setIsDragging] = useState(false);

  const handleDragStart = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragEnd = () => {
    setIsDragging(false);
  };

  const handleDrag = (e: React.MouseEvent) => {
    if (!isDragging) return;
    
    const container = e.currentTarget as HTMLDivElement;
    const containerRect = container.getBoundingClientRect();
    const newPosition = ((e.clientX - containerRect.left) / containerRect.width) * 100;
    
    // Constrain split position between 30% and 70%
    const constrainedPosition = Math.max(30, Math.min(70, newPosition));
    setSplitPosition(constrainedPosition);
  };

  return (
    <div 
      className="flex flex-col lg:flex-row h-screen overflow-hidden"
      onMouseMove={handleDrag}
      onMouseUp={handleDragEnd}
      onMouseLeave={handleDragEnd}
    >
      {/* Content Panel (Left) */}
      <div 
        className="flex-none lg:flex-1 overflow-auto bg-white"
        style={{ width: `${splitPosition}%` }}
      >
        {contentPanel}
      </div>
      
      {/* Resizer */}
      <div 
        className={`
          hidden lg:block w-2 bg-gray-200 hover:bg-voltage-500 cursor-ew-resize
          ${isDragging ? 'bg-voltage-600' : ''}
        `}
        onMouseDown={handleDragStart}
      />
      
      {/* AI Chat Panel (Right) */}
      <div 
        className="flex-none lg:flex-1 overflow-auto bg-gray-50 border-t lg:border-t-0 lg:border-l border-gray-200"
        style={{ width: `${100 - splitPosition}%` }}
      >
        {aiChatPanel}
      </div>
    </div>
  );
}
