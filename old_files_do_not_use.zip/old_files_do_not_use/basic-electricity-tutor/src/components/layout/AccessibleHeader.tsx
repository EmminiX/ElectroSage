"use client";

import React from 'react';

interface AccessibleHeaderProps {
  title?: string;
  subtitle?: string;
}

export default function AccessibleHeader({ 
  title = "Basic Electricity Tutor", 
  subtitle = "Interactive Learning Experience" 
}: AccessibleHeaderProps) {
  return (
    <>
      {/* Skip Links for Keyboard Navigation */}
      <a href="#main-content" className="skip-link">
        Skip to main content
      </a>
      <a href="#navigation" className="skip-link">
        Skip to navigation
      </a>
      <a href="#chat-panel" className="skip-link">
        Skip to AI tutor
      </a>
      
      {/* Main Header */}
      <header 
        className="bg-white border-b-2 border-voltage-200 shadow-gentle px-4 py-3 lg:px-6 lg:py-4"
        role="banner"
      >
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          {/* Logo and Title */}
          <div className="flex items-center space-x-3">
            <div 
              className="w-10 h-10 lg:w-12 lg:h-12 bg-gradient-to-br from-voltage-500 to-current-500 rounded-lg flex items-center justify-center shadow-moderate"
              aria-hidden="true"
            >
              <svg 
                className="w-6 h-6 lg:w-7 lg:h-7 text-white" 
                fill="currentColor" 
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                <path d="M13 10V3L4 14h7v7l9-11h-7z"/>
              </svg>
            </div>
            <div>
              <h1 className="text-xl lg:text-2xl font-semibold text-neutral-800 leading-tight">
                {title}
              </h1>
              <p className="text-sm lg:text-base text-neutral-600 font-medium">
                {subtitle}
              </p>
            </div>
          </div>
          
          {/* Accessibility Controls */}
          <div className="flex items-center space-x-2 lg:space-x-3">
            <AccessibilityControls />
          </div>
        </div>
      </header>
    </>
  );
}

function AccessibilityControls() {
  const [highContrast, setHighContrast] = React.useState(false);
  const [reducedMotion, setReducedMotion] = React.useState(false);
  const [fontSize, setFontSize] = React.useState('normal');

  React.useEffect(() => {
    // Apply high contrast mode
    if (highContrast) {
      document.documentElement.classList.add('high-contrast');
    } else {
      document.documentElement.classList.remove('high-contrast');
    }
  }, [highContrast]);

  React.useEffect(() => {
    // Apply reduced motion
    if (reducedMotion) {
      document.documentElement.classList.add('no-animation');
    } else {
      document.documentElement.classList.remove('no-animation');
    }
  }, [reducedMotion]);

  React.useEffect(() => {
    // Apply font size changes
    const root = document.documentElement;
    root.classList.remove('text-sm', 'text-base', 'text-lg');
    
    switch (fontSize) {
      case 'small':
        root.classList.add('text-sm');
        break;
      case 'large':
        root.classList.add('text-lg');
        break;
      default:
        root.classList.add('text-base');
    }
  }, [fontSize]);

  return (
    <div className="flex items-center space-x-2">
      {/* Font Size Control */}
      <div className="relative">
        <label htmlFor="font-size" className="sr-only">
          Adjust font size
        </label>
        <select
          id="font-size"
          value={fontSize}
          onChange={(e) => setFontSize(e.target.value)}
          className="text-sm border-2 border-neutral-300 rounded-md px-2 py-1 bg-white focus-visible-ring"
          aria-label="Font size options"
        >
          <option value="small">Small Text</option>
          <option value="normal">Normal Text</option>
          <option value="large">Large Text</option>
        </select>
      </div>

      {/* High Contrast Toggle */}
      <button
        onClick={() => setHighContrast(!highContrast)}
        className={`
          px-3 py-1.5 text-sm font-medium rounded-md border-2 transition-colors focus-visible-ring
          ${highContrast 
            ? 'bg-neutral-900 text-white border-neutral-900' 
            : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-50'
          }
        `}
        aria-pressed={highContrast}
        aria-label={`${highContrast ? 'Disable' : 'Enable'} high contrast mode`}
      >
        <span className="flex items-center space-x-1">
          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8v16z"/>
          </svg>
          <span className="hidden lg:inline">Contrast</span>
        </span>
      </button>

      {/* Reduced Motion Toggle */}
      <button
        onClick={() => setReducedMotion(!reducedMotion)}
        className={`
          px-3 py-1.5 text-sm font-medium rounded-md border-2 transition-colors focus-visible-ring
          ${reducedMotion 
            ? 'bg-voltage-600 text-white border-voltage-600' 
            : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-50'
          }
        `}
        aria-pressed={reducedMotion}
        aria-label={`${reducedMotion ? 'Enable' : 'Disable'} animations and motion`}
      >
        <span className="flex items-center space-x-1">
          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
          </svg>
          <span className="hidden lg:inline">Motion</span>
        </span>
      </button>
    </div>
  );
}
