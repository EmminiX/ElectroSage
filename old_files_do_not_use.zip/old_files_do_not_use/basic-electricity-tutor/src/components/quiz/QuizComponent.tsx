"use client";

import React, { useState, useEffect } from 'react';
import { IPracticeQuestion } from '@/types/content';

interface QuizComponentProps {
  questions: IPracticeQuestion[];
  onComplete?: (score: number, totalQuestions: number, results: QuizResult[]) => void;
  className?: string;
  showHints?: boolean;
  allowRetry?: boolean;
}

interface QuizResult {
  questionId: string;
  question: string;
  userAnswer: string;
  correctAnswer: string;
  isCorrect: boolean;
  timeSpent: number;
}

/**
 * Enhanced QuizComponent with better UX, progress tracking, and educational features
 */
export default function QuizComponent({ 
  questions, 
  onComplete,
  className = '',
  showHints = true,
  allowRetry = true
}: QuizComponentProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string>('');
  const [textAnswer, setTextAnswer] = useState<string>('');
  const [isAnswered, setIsAnswered] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [score, setScore] = useState(0);
  const [showExplanation, setShowExplanation] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [quizResults, setQuizResults] = useState<QuizResult[]>([]);
  const [questionStartTime, setQuestionStartTime] = useState<number>(Date.now());
  const [attempts, setAttempts] = useState(0);

  // Get the current question
  const currentQuestion = questions[currentQuestionIndex];
  
  // Check if this is the last question
  const isLastQuestion = currentQuestionIndex === questions.length - 1;

  // Progress calculation
  const progress = ((currentQuestionIndex + (isAnswered ? 1 : 0)) / questions.length) * 100;

  // Reset question timer when question changes
  useEffect(() => {
    setQuestionStartTime(Date.now());
  }, [currentQuestionIndex]);

  /**
   * Handle submission of an answer
   */
  const handleSubmitAnswer = () => {
    const answer = currentQuestion.type === 'multiple-choice' ? selectedAnswer : textAnswer;
    let correct = false;
    
    // Validate that an answer was provided
    if (!answer.trim()) {
      alert('Please provide an answer before submitting.');
      return;
    }
    
    // Check if the answer is correct
    if (currentQuestion.type === 'multiple-choice') {
      correct = answer === currentQuestion.correctAnswer;
    } else {
      // For text input, check if the answer matches any of the acceptable answers
      const acceptableAnswers = Array.isArray(currentQuestion.correctAnswer) 
        ? currentQuestion.correctAnswer 
        : [currentQuestion.correctAnswer];
        
      correct = acceptableAnswers.some(
        correctAns => answer.toLowerCase().trim() === correctAns.toLowerCase().trim()
      );
    }
    
    // Calculate time spent on this question
    const timeSpent = Date.now() - questionStartTime;
    
    // Create result record
    const result: QuizResult = {
      questionId: currentQuestion.id,
      question: currentQuestion.question,
      userAnswer: answer,
      correctAnswer: Array.isArray(currentQuestion.correctAnswer) 
        ? currentQuestion.correctAnswer[0] 
        : currentQuestion.correctAnswer,
      isCorrect: correct,
      timeSpent
    };
    
    // Update state based on answer correctness
    setIsAnswered(true);
    setIsCorrect(correct);
    setShowExplanation(true);
    setAttempts(prev => prev + 1);
    
    if (correct) {
      setScore(prev => prev + 1);
    }
    
    // Add result to quiz results
    setQuizResults(prev => [...prev, result]);
  };

  /**
   * Handle retry for current question (if allowed)
   */
  const handleRetryQuestion = () => {
    setSelectedAnswer('');
    setTextAnswer('');
    setIsAnswered(false);
    setShowExplanation(false);
    setShowHint(false);
    setQuestionStartTime(Date.now());
  };

  /**
   * Move to the next question or complete the quiz
   */
  const handleNextQuestion = () => {
    if (isLastQuestion) {
      setQuizCompleted(true);
      onComplete?.(score, questions.length, quizResults);
    } else {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedAnswer('');
      setTextAnswer('');
      setIsAnswered(false);
      setShowExplanation(false);
      setShowHint(false);
      setAttempts(0);
    }
  };

  /**
   * Reset the quiz to start over
   */
  const handleResetQuiz = () => {
    setCurrentQuestionIndex(0);
    setSelectedAnswer('');
    setTextAnswer('');
    setIsAnswered(false);
    setIsCorrect(false);
    setScore(0);
    setShowExplanation(false);
    setShowHint(false);
    setQuizCompleted(false);
    setQuizResults([]);
    setAttempts(0);
    setQuestionStartTime(Date.now());
  };

  /**
   * Toggle hint visibility
   */
  const handleToggleHint = () => {
    setShowHint(prev => !prev);
  };

  // If no questions are provided, show a message
  if (questions.length === 0) {
    return (
      <div className={`quiz-container ${className} p-6 bg-white rounded-lg shadow-sm border`}>
        <div className="text-center text-gray-500">
          <div className="text-4xl mb-4">📝</div>
          <h3 className="text-lg font-medium mb-2">No Practice Questions Available</h3>
          <p className="text-sm">Practice questions will appear here when available for this section.</p>
        </div>
      </div>
    );
  }

  // Quiz completion screen
  if (quizCompleted) {
    const percentage = Math.round((score / questions.length) * 100);
    const performanceLevel = percentage >= 80 ? 'excellent' : percentage >= 60 ? 'good' : 'needs-improvement';
    
    return (
      <div className={`quiz-container ${className} p-6 bg-white rounded-lg shadow-sm border`}>
        <div className="text-center">
          <div className="text-6xl mb-4">
            {performanceLevel === 'excellent' ? '🎉' : performanceLevel === 'good' ? '👍' : '📚'}
          </div>
          <h3 className="text-2xl font-bold mb-4">Quiz Complete!</h3>
          
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <div className="text-3xl font-bold text-blue-600 mb-2">{score}/{questions.length}</div>
            <div className="text-lg text-gray-700 mb-1">{percentage}% Correct</div>
            <div className="text-sm text-gray-500">
              {performanceLevel === 'excellent' && 'Excellent work! You have a strong understanding of this topic.'}
              {performanceLevel === 'good' && 'Good job! You understand most of the concepts.'}
              {performanceLevel === 'needs-improvement' && 'Keep studying! Review the material and try again.'}
            </div>
          </div>

          {/* Detailed Results */}
          <div className="text-left mb-6">
            <h4 className="font-semibold mb-3">Question Review:</h4>
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {quizResults.map((result, index) => (
                <div key={result.questionId} className={`p-3 rounded border-l-4 ${
                  result.isCorrect ? 'border-green-500 bg-green-50' : 'border-red-500 bg-red-50'
                }`}>
                  <div className="text-sm font-medium">Q{index + 1}: {result.question}</div>
                  <div className="text-xs text-gray-600 mt-1">
                    Your answer: <span className={result.isCorrect ? 'text-green-700' : 'text-red-700'}>
                      {result.userAnswer}
                    </span>
                    {!result.isCorrect && (
                      <span className="ml-2">
                        (Correct: <span className="text-green-700">{result.correctAnswer}</span>)
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex gap-3 justify-center">
            <button
              onClick={handleResetQuiz}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Try Again
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`quiz-container ${className} p-6 bg-white rounded-lg shadow-sm border`}>
      {/* Progress Bar */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-medium text-gray-700">
            Question {currentQuestionIndex + 1} of {questions.length}
          </span>
          <span className="text-sm text-gray-500">
            Score: {score}/{currentQuestionIndex + (isAnswered && isCorrect ? 1 : 0)}
          </span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="bg-blue-600 h-2 rounded-full transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Question */}
      <div className="mb-6">
        <h3 className="text-lg font-semibold mb-4 text-gray-800">
          {currentQuestion.question}
        </h3>

        {/* Multiple Choice Options */}
        {currentQuestion.type === 'multiple-choice' && currentQuestion.options && (
          <div className="space-y-3">
            {currentQuestion.options.map((option, index) => (
              <label
                key={index}
                className={`flex items-center p-3 border rounded-lg cursor-pointer transition-colors ${
                  selectedAnswer === option
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                } ${isAnswered ? 'cursor-not-allowed' : ''}`}
              >
                <input
                  type="radio"
                  name="answer"
                  value={option}
                  checked={selectedAnswer === option}
                  onChange={(e) => setSelectedAnswer(e.target.value)}
                  disabled={isAnswered}
                  className="mr-3"
                />
                <span className={isAnswered ? 'text-gray-600' : 'text-gray-800'}>
                  {option}
                </span>
              </label>
            ))}
          </div>
        )}

        {/* Text Input */}
        {currentQuestion.type === 'text-input' && (
          <div>
            <textarea
              value={textAnswer}
              onChange={(e) => setTextAnswer(e.target.value)}
              disabled={isAnswered}
              placeholder="Enter your answer here..."
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-100 disabled:text-gray-600"
              rows={3}
            />
          </div>
        )}
      </div>

      {/* Hint Section */}
      {showHints && currentQuestion.hint && !isAnswered && (
        <div className="mb-4">
          <button
            onClick={handleToggleHint}
            className="text-sm text-blue-600 hover:text-blue-800 flex items-center"
          >
            💡 {showHint ? 'Hide Hint' : 'Show Hint'}
          </button>
          {showHint && (
            <div className="mt-2 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
              <p className="text-sm text-yellow-800">{currentQuestion.hint}</p>
            </div>
          )}
        </div>
      )}

      {/* Explanation Section */}
      {showExplanation && currentQuestion.explanation && (
        <div className={`mb-4 p-4 rounded-lg border-l-4 ${
          isCorrect 
            ? 'bg-green-50 border-green-500' 
            : 'bg-red-50 border-red-500'
        }`}>
          <div className={`font-medium mb-2 ${
            isCorrect ? 'text-green-800' : 'text-red-800'
          }`}>
            {isCorrect ? '✅ Correct!' : '❌ Incorrect'}
          </div>
          <p className={`text-sm ${
            isCorrect ? 'text-green-700' : 'text-red-700'
          }`}>
            {currentQuestion.explanation}
          </p>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex gap-3 justify-between">
        <div>
          {!isAnswered && (
            <button
              onClick={handleSubmitAnswer}
              disabled={
                (currentQuestion.type === 'multiple-choice' && !selectedAnswer) ||
                (currentQuestion.type === 'text-input' && !textAnswer.trim())
              }
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
            >
              Submit Answer
            </button>
          )}
          
          {isAnswered && !isCorrect && allowRetry && attempts < 2 && (
            <button
              onClick={handleRetryQuestion}
              className="px-4 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 transition-colors mr-3"
            >
              Try Again
            </button>
          )}
        </div>

        {isAnswered && (
          <button
            onClick={handleNextQuestion}
            className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
          >
            {isLastQuestion ? 'Complete Quiz' : 'Next Question'}
          </button>
        )}
      </div>
    </div>
  );
}
