"use client";

import React, { useState, useRef, useEffect } from 'react';
import { IMessage } from '../../types/chat';
import { getAIService } from '@/lib/aiService';
import { ISection } from '@/types/content';

/**
 * Props for the ChatPanel component
 */
interface ChatPanelProps {
  /** Current section being viewed */
  currentSection?: ISection | null;
}

/**
 * Enhanced ChatPanel component with improved UI and features
 */
export default function ChatPanel({ currentSection }: ChatPanelProps) {
  const [messages, setMessages] = useState<IMessage[]>([
    {
      role: 'assistant',
      content: 'Hello! I\'m your Basic Electricity tutor. I can help you understand electrical concepts, explain visualizations, and guide you through practice questions. What would you like to learn about?'
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(true);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Scroll to bottom of chat when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Update AI service and get suggestions when section changes
  useEffect(() => {
    const aiService = getAIService();
    aiService.setCurrentSection(currentSection || null);
    
    // Get AI suggestions for the current section
    if (currentSection) {
      loadSuggestions();
    } else {
      setSuggestions([
        "What is electric current?",
        "How does voltage work?",
        "Explain Ohm's law",
        "What are the different types of circuits?"
      ]);
    }
  }, [currentSection]);

  /**
   * Load AI-generated suggestions for the current section
   */
  const loadSuggestions = async () => {
    if (!currentSection) return;
    
    try {
      const aiService = getAIService();
      const sectionSuggestions = await aiService.getSuggestions(currentSection);
      setSuggestions(sectionSuggestions);
    } catch (error) {
      console.error('Error loading suggestions:', error);
      // Fallback suggestions
      setSuggestions([
        `Tell me more about ${currentSection.title}`,
        "Can you explain this concept differently?",
        "What are some real-world applications?",
        "How does this relate to other electrical concepts?"
      ]);
    }
  };

  /**
   * Handles sending a new message to the AI assistant
   */
  const handleSendMessage = async (messageContent?: string) => {
    const content = messageContent || inputValue;
    if (!content.trim()) return;
    
    const userMessage: IMessage = {
      role: 'user',
      content: content,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);
    setShowSuggestions(false);
    
    try {
      // Get AI service and send the message
      const aiService = getAIService();
      const currentMessages = [...messages, userMessage];
      const response = await aiService.sendMessage(currentMessages);
      
      // Add timestamp to the response
      response.timestamp = new Date();
      
      setMessages(prev => [...prev, response]);
    } catch (error) {
      console.error('Error fetching AI response:', error);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: 'I apologize, but I encountered an error while processing your request. Please try again or check your API configuration.',
        timestamp: new Date()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Handle form submission
   */
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSendMessage();
  };

  /**
   * Handle suggestion click
   */
  const handleSuggestionClick = (suggestion: string) => {
    handleSendMessage(suggestion);
  };

  /**
   * Clear chat history
   */
  const handleClearChat = () => {
    setMessages([
      {
        role: 'assistant',
        content: 'Chat cleared! How can I help you with electrical concepts?'
      }
    ]);
    setShowSuggestions(true);
  };

  /**
   * Format message content with basic markdown support
   */
  const formatMessageContent = (content: string) => {
    // Simple markdown formatting
    return content
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/`(.*?)`/g, '<code class="bg-gray-200 px-1 rounded">$1</code>')
      .replace(/\n/g, '<br />');
  };

  return (
    <div className="flex flex-col h-full bg-white" role="region" aria-label="Chat with AI Electricity Tutor">
      {/* Header */}
      <div className="p-4 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-indigo-50">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-xl font-semibold text-gray-800 flex items-center" id="chat-title">
              🤖 AI Electricity Tutor
            </h2>
            <p className="text-sm text-gray-600 mt-1" id="chat-context">
              {currentSection 
                ? `Currently discussing: ${currentSection.title}` 
                : 'Ask me anything about electricity'}
            </p>
          </div>
          <button
            onClick={handleClearChat}
            className="text-sm text-gray-500 hover:text-gray-700 px-3 py-1 rounded-lg hover:bg-white/50 transition-colors"
            title="Clear chat history"
          >
            🗑️ Clear
          </button>
        </div>
      </div>
      
      {/* Messages */}
      <div 
        className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50" 
        role="log" 
        aria-live="polite" 
        aria-label="Chat messages"
        aria-labelledby="chat-title"
      >
        {messages.map((message, index) => (
          <div
            key={index}
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            role="article"
            aria-label={`${message.role} message`}
          >
            <div
              className={`max-w-[85%] rounded-2xl p-4 shadow-sm ${message.role === 'user'
                ? 'bg-blue-600 text-white ml-4'
                : 'bg-white text-gray-800 mr-4 border border-gray-200'
              }`}
            >
              <div 
                className={`${message.role === 'assistant' ? 'prose prose-sm max-w-none' : ''}`}
                dangerouslySetInnerHTML={{ 
                  __html: formatMessageContent(message.content) 
                }}
              />
              {message.timestamp && (
                <div className={`text-xs mt-2 ${
                  message.role === 'user' ? 'text-blue-100' : 'text-gray-400'
                }`}>
                  {message.timestamp.toLocaleTimeString()}
                </div>
              )}
            </div>
          </div>
        ))}
        
        {isLoading && (
          <div className="flex justify-start" aria-live="polite">
            <div className="max-w-[85%] rounded-2xl p-4 bg-white mr-4 border border-gray-200 shadow-sm">
              <div 
                className="flex space-x-2 items-center" 
                aria-label="Assistant is typing"
              >
                <div className="w-2 h-2 rounded-full bg-blue-400 animate-bounce"></div>
                <div className="w-2 h-2 rounded-full bg-blue-400 animate-bounce delay-100"></div>
                <div className="w-2 h-2 rounded-full bg-blue-400 animate-bounce delay-200"></div>
                <span className="text-sm text-gray-500 ml-2">Thinking...</span>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Suggestions */}
      {showSuggestions && suggestions.length > 0 && messages.length <= 2 && (
        <div className="px-4 py-2 border-t border-gray-200 bg-white">
          <div className="text-sm text-gray-600 mb-2">💡 Suggested questions:</div>
          <div className="flex flex-wrap gap-2">
            {suggestions.slice(0, 3).map((suggestion, index) => (
              <button
                key={index}
                onClick={() => handleSuggestionClick(suggestion)}
                className="text-sm px-3 py-2 bg-blue-50 text-blue-700 rounded-full hover:bg-blue-100 transition-colors border border-blue-200"
                disabled={isLoading}
              >
                {suggestion}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input Form */}
      <form 
        onSubmit={handleSubmit} 
        className="p-4 border-t border-gray-200 bg-white" 
        aria-label="Chat message form"
      >
        <div className="flex items-end space-x-3">
          <div className="flex-1">
            <input
              ref={inputRef}
              type="text"
              value={inputValue}
              onChange={e => setInputValue(e.target.value)}
              placeholder="Ask about electrical concepts, visualizations, or practice questions..."
              className="w-full border border-gray-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
              aria-label="Type your message"
              disabled={isLoading}
            />
          </div>
          <button
            type="submit"
            disabled={isLoading || !inputValue.trim()}
            className="bg-blue-600 text-white px-6 py-3 rounded-xl hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center space-x-2"
            aria-label="Send message"
          >
            {isLoading ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <span>Send</span>
            )}
          </button>
        </div>
        
        {/* Quick Actions */}
        <div className="flex space-x-2 mt-3">
          <button
            type="button"
            onClick={() => handleSuggestionClick("Explain this section in simple terms")}
            className="text-xs px-3 py-1 bg-gray-100 text-gray-600 rounded-full hover:bg-gray-200 transition-colors"
            disabled={isLoading || !currentSection}
          >
            📝 Simplify
          </button>
          <button
            type="button"
            onClick={() => handleSuggestionClick("Show me a real-world example")}
            className="text-xs px-3 py-1 bg-gray-100 text-gray-600 rounded-full hover:bg-gray-200 transition-colors"
            disabled={isLoading}
          >
            🌍 Examples
          </button>
          <button
            type="button"
            onClick={() => handleSuggestionClick("What should I study next?")}
            className="text-xs px-3 py-1 bg-gray-100 text-gray-600 rounded-full hover:bg-gray-200 transition-colors"
            disabled={isLoading}
          >
            📚 Study Guide
          </button>
        </div>
      </form>
    </div>
  );
}
