import type { Metadata } from "next";
import { Lexend } from "next/font/google";
import "./globals.css";

const lexend = Lexend({
  subsets: ["latin"],
  variable: "--font-lexend",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Basic Electricity Tutor - Interactive Learning Experience",
  description: "Learn basic electricity concepts through interactive visualizations and AI-powered tutoring. Designed for accessible, ADHD and dyslexic-friendly learning.",
  keywords: "electricity, education, interactive learning, ADHD friendly, dyslexic friendly, accessible education",
  viewport: "width=device-width, initial-scale=1",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${lexend.variable} font-lexend antialiased bg-gray-50`}
        suppressHydrationWarning
      >
        {children}
      </body>
    </html>
  );
}
