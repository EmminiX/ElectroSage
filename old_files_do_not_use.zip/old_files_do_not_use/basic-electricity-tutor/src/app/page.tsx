"use client";

import { useState, useEffect } from 'react';
import SplitScreenLayout from '@/components/layout/SplitScreenLayout';
import AccessibleHeader from '@/components/layout/AccessibleHeader';
import ContentPanel from '@/components/content/ContentPanel';
import ChatPanel from '@/components/ai/ChatPanel';
import { parseContentFile } from '@/lib/contentParser';
import { ISection } from '@/types/content';
import { getAIService } from '@/lib/aiService';

export default function Home() {
  const [sections, setSections] = useState<ISection[]>([]);
  const [currentSection, setCurrentSection] = useState<ISection | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadContent = async () => {
      try {
        setIsLoading(true);
        const response = await fetch('/api/content');
        
        if (!response.ok) {
          throw new Error(`Failed to load content: ${response.statusText}`);
        }
        
        const data = await response.json();
        
        if (data.error) {
          throw new Error(data.error);
        }
        
        if (!data.sections || !Array.isArray(data.sections)) {
          throw new Error('Invalid content format received');
        }
        
        setSections(data.sections);
        
        // Set the first section as current if available
        if (data.sections.length > 0) {
          setCurrentSection(data.sections[0]);
        }
        
      } catch (err) {
        console.error('Error loading content:', err);
        setError(err instanceof Error ? err.message : 'Failed to load content');
      } finally {
        setIsLoading(false);
      }
    };

    loadContent();
  }, []);

  // Initialize AI service
  useEffect(() => {
    const initAI = async () => {
      try {
        await getAIService();
      } catch (error) {
        console.error('Failed to initialize AI service:', error);
      }
    };
    
    initAI();
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <AccessibleHeader />
        <div className="flex items-center justify-center h-screen pt-16">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-voltage-600 mx-auto mb-4"></div>
            <p className="text-neutral-600">Loading educational content...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50">
        <AccessibleHeader />
        <div className="flex items-center justify-center h-screen pt-16">
          <div className="text-center max-w-md">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-red-600" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/>
              </svg>
            </div>
            <h2 className="text-xl font-semibold text-neutral-800 mb-2">
              Content Loading Error
            </h2>
            <p className="text-neutral-600 mb-4">{error}</p>
            <button 
              onClick={() => window.location.reload()}
              className="px-4 py-2 bg-voltage-600 text-white rounded-md hover:bg-voltage-700 focus-visible-ring"
            >
              Try Again
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <AccessibleHeader />
      <main className="h-screen pt-16"> {/* Account for fixed header height */}
        <SplitScreenLayout
          contentPanel={
            <ContentPanel
              sections={sections}
              currentSection={currentSection}
              onSectionChange={setCurrentSection}
            />
          }
          aiChatPanel={
            <ChatPanel
              currentSection={currentSection}
            />
          }
        />
      </main>
    </div>
  );
}
