/**
 * Represents a section of educational content with its metadata, HTML content,
 * subsections, visualizations, and practice questions.
 */
export interface ISection {
  /** Unique identifier for the section */
  id: string;
  /** Section title */
  title: string;
  /** HTML-rendered content for display */
  contentHtml: string;
  /** Raw markdown content for AI context */
  rawContent: string;
  /** Optional nested subsections */
  subsections?: ISection[];
  /** Optional visualizations tied to this section */
  visualizations?: IVisualization[];
  /** Optional practice questions for this section */
  practiceQuestions?: IPracticeQuestion[];
}

/**
 * Represents an interactive visualization for electrical concepts
 * that can be rendered using D3.js or Three.js
 */
export interface IVisualization {
  /** Unique identifier for the visualization */
  id: string;
  /** Type of visualization to determine rendering strategy */
  type: 'circuit' | 'atomic' | 'graph' | 'animation' | '3d' | 'waveform' | 'power-triangle';
  /** Title of the visualization */
  title: string;
  /** Description explaining the concept being visualized */
  description: string;
  /** Optional configuration data for the visualization */
  configData?: Record<string, any>;
}

/**
 * Represents a practice question for testing understanding
 * of electrical concepts
 */
export interface IPracticeQuestion {
  /** Unique identifier for the question */
  id: string;
  /** The question text */
  question: string;
  /** Type of question (multiple-choice or text input) */
  type: 'multiple-choice' | 'text-input';
  /** Optional multiple choice options */
  options?: string[];
  /** The correct answer (option text for multiple-choice or text answer for text-input) */
  correctAnswer: string | string[];
  /** Explanation of the correct answer */
  explanation: string;
  /** Optional hint to help users answer the question */
  hint?: string;
  /** Difficulty level of the question */
  difficulty: 'basic' | 'intermediate' | 'advanced';
}
