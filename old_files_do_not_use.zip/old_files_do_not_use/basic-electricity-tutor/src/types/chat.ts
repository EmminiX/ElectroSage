/**
 * Represents a chat message in the AI tutor conversation with role,
 * content and optional timestamp
 */
export interface IMessage {
  /** The role of the message sender (user, AI assistant, or system) */
  role: 'user' | 'assistant' | 'system';
  /** The text content of the message */
  content: string;
  /** Optional timestamp when the message was sent */
  timestamp?: Date;
}

/**
 * Configuration for AI chat integration with various providers
 * including OpenAI, Anthropic Claude, or mock implementations
 */
export interface IChatConfig {
  /** The AI provider to use */
  provider: 'openai' | 'anthropic' | 'mock';
  /** Optional model name to use with the provider */
  model?: string;
  /** Optional API key for authentication */
  apiKey?: string;
  /** Optional system prompt to configure AI behavior */
  systemPrompt?: string;
  /** Optional token limit for responses */
  maxTokens?: number;
  /** Optional temperature setting (0-1) for response randomness */
  temperature?: number;
}
