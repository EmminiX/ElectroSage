/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        'lexend': ['var(--font-lexend)', 'system-ui', 'sans-serif'],
        sans: ["Inter", "system-ui", "-apple-system", "sans-serif"],
        mono: ["Fira Code", "monospace"],
      },
      fontSize: {
        // ADHD/Dyslexic-friendly font sizes with improved line heights
        'xs': ['0.75rem', { lineHeight: '1.6' }],
        'sm': ['0.875rem', { lineHeight: '1.6' }],
        'base': ['1rem', { lineHeight: '1.7' }],
        'lg': ['1.125rem', { lineHeight: '1.7' }],
        'xl': ['1.25rem', { lineHeight: '1.6' }],
        '2xl': ['1.5rem', { lineHeight: '1.5' }],
        '3xl': ['1.875rem', { lineHeight: '1.4' }],
        '4xl': ['2.25rem', { lineHeight: '1.3' }],
      },
      spacing: {
        // Enhanced spacing for better readability
        '18': '4.5rem',
        '22': '5.5rem',
        '26': '6.5rem',
        '30': '7.5rem',
      },
      colors: {
        // Electrical-themed color palette with improved accessibility
        voltage: {
          50: "#f0f9ff",
          100: "#e0f2fe",
          200: "#bae6fd",
          300: "#7dd3fc",
          400: "#38bdf8",
          500: "#0ea5e9",
          600: "#0284c7", // Primary voltage color - WCAG AA compliant
          700: "#0369a1",
          800: "#075985",
          900: "#0c4a6e",
        },
        current: {
          50: "#fefce8",
          100: "#fef9c3",
          200: "#fef08a",
          300: "#fde047",
          400: "#facc15",
          500: "#eab308", // Primary current color - WCAG AA compliant
          600: "#ca8a04",
          700: "#a16207",
          800: "#854d0e",
          900: "#713f12",
        },
        resistance: {
          50: "#fef2f2",
          100: "#fee2e2",
          200: "#fecaca",
          300: "#fca5a5",
          400: "#f87171",
          500: "#ef4444", // Primary resistance color - WCAG AA compliant
          600: "#dc2626",
          700: "#b91c1c",
          800: "#991b1b",
          900: "#7f1d1d",
        },
        // Accessibility-focused colors
        focus: {
          ring: "#3b82f6",
          outline: "#1d4ed8",
        },
        // ADHD/Dyslexic-friendly neutral palette
        neutral: {
          50: "#fafafa",
          100: "#f5f5f5",
          200: "#e5e5e5",
          300: "#d4d4d4",
          400: "#a3a3a3",
          500: "#737373",
          600: "#525252",
          700: "#404040",
          800: "#262626",
          900: "#171717",
        },
        // High contrast mode colors
        'high-contrast': {
          bg: "#ffffff",
          text: "#000000",
          accent: "#0066cc",
        },
        conductor: "#6b7280",
        insulator: "#f9fafb",
        semiconductor: "#4b5563",
      },
      // Enhanced focus styles for accessibility
      ringWidth: {
        '3': '3px',
        '4': '4px',
      },
      ringOffsetWidth: {
        '3': '3px',
        '4': '4px',
      },
      // Animation preferences for ADHD users
      animation: {
        'fade-in': 'fadeIn 0.3s ease-in-out',
        'slide-in': 'slideIn 0.2s ease-out',
        'pulse-gentle': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        "electron-flow": "flow 2s linear infinite",
        "pulse-slow": "pulse 3s linear infinite",
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideIn: {
          '0%': { transform: 'translateY(-10px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        flow: {
          "0%": { transform: "translateX(0)" },
          "100%": { transform: "translateX(100%)" },
        },
      },
      // Improved shadows for better depth perception
      boxShadow: {
        'focus': '0 0 0 3px rgba(59, 130, 246, 0.5)',
        'focus-visible': '0 0 0 2px #ffffff, 0 0 0 4px #3b82f6',
        'gentle': '0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06)',
        'moderate': '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
      },
      backgroundImage: {
        "circuit-pattern": "url('/images/circuit-pattern.svg')",
      },
    },
  },
  plugins: [
    require("@tailwindcss/forms"),
    require("@tailwindcss/typography"),
    // Add focus-visible plugin for better keyboard navigation
    function({ addUtilities }) {
      addUtilities({
        '.focus-visible-ring': {
          '&:focus-visible': {
            outline: '2px solid transparent',
            'outline-offset': '2px',
            'box-shadow': '0 0 0 2px #ffffff, 0 0 0 4px #3b82f6',
          },
        },
        '.skip-link': {
          position: 'absolute',
          top: '-40px',
          left: '6px',
          background: '#000000',
          color: '#ffffff',
          padding: '8px',
          'z-index': '100',
          'text-decoration': 'none',
          '&:focus': {
            top: '6px',
          },
        },
      });
    },
  ],
};
