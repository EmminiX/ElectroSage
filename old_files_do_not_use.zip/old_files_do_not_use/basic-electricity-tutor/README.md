# Basic Electricity Tutor 🔌⚡

An interactive web application for learning basic electrical concepts, featuring AI-powered tutoring, interactive visualizations, and comprehensive practice questions.

## ✨ Features

- **📚 11 Educational Sections** covering fundamental electrical concepts
- **🤖 AI-Powered Tutor** with contextual suggestions and personalized help
- **📊 Interactive Visualizations** using D3.js and Three.js
- **🧠 Enhanced Quiz System** with hints, progress tracking, and detailed feedback
- **📱 Responsive Design** optimized for desktop, tablet, and mobile
- **🎨 Modern UI/UX** with professional styling and smooth animations

## 🚀 Quick Start

### Prerequisites

- Node.js 18+ and npm
- OpenAI API key (optional, for AI features)

### Installation

1. **Clone and navigate to the project:**
   ```bash
   cd basic-electricity-tutor
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Set up environment variables:**
   ```bash
   cp env.example .env.local
   ```
   
   Edit `.env.local` and add your OpenAI API key:
   ```env
   NEXT_PUBLIC_OPENAI_API_KEY=your-actual-openai-api-key-here
   ```

4. **Start the development server:**
   ```bash
   npm run dev
   ```

5. **Open your browser:**
   Navigate to `http://localhost:3000` (or the port shown in terminal)

## 🔑 API Key Setup

### Getting an OpenAI API Key

1. Visit [OpenAI Platform](https://platform.openai.com/api-keys)
2. Sign up or log in to your account
3. Create a new API key
4. Copy the key and add it to your `.env.local` file

### Without API Key

The application will work without an API key, but AI features will use default suggestions instead of personalized responses.

## 📖 Usage Guide

### Navigation
- **Header**: Shows current section and progress
- **Left Panel**: Educational content with visualizations and quizzes
- **Right Panel**: AI chatbot for personalized tutoring
- **Mobile**: Responsive design with collapsible navigation

### Educational Content
- Browse through 11 sections covering basic electricity
- Interactive visualizations help understand complex concepts
- Practice questions test your knowledge with immediate feedback

### AI Tutor Features
- **Contextual Help**: AI understands your current section
- **Smart Suggestions**: Get relevant questions based on content
- **Quick Actions**: Simplify explanations, show examples, create study guides
- **Chat History**: Maintain conversation context

### Quiz System
- **Hints**: Toggle hints for additional help
- **Progress Tracking**: Visual progress bar and scoring
- **Retry Logic**: Up to 2 attempts per question
- **Detailed Results**: Review answers and explanations

## 🛠️ Technical Stack

- **Framework**: Next.js 15 with React 19
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **Visualizations**: D3.js, Three.js
- **AI Integration**: OpenAI API
- **Build Tool**: Turbopack

## 📁 Project Structure

```
src/
├── app/                    # Next.js app router
│   ├── api/content/       # Content parsing API
│   └── page.tsx           # Main application page
├── components/            # React components
│   ├── ai/               # AI chatbot components
│   ├── content/          # Content display components
│   ├── layout/           # Layout components
│   ├── quiz/             # Quiz system components
│   └── visualizations/   # Interactive visualizations
├── lib/                  # Utility libraries
│   ├── aiService.ts      # AI service integration
│   └── contentParser.ts  # Markdown content parser
└── types/                # TypeScript type definitions
```

## 🎯 Educational Sections

1. **Introduction to Electricity** - Basic concepts and definitions
2. **Atomic Structure and Electrons** - Foundation of electrical theory
3. **Electric Current** - Understanding current flow
4. **Voltage (Potential Difference)** - Electrical pressure concepts
5. **Resistance** - Opposition to current flow
6. **Ohm's Law** - Fundamental electrical relationship
7. **Electrical Power** - Energy consumption and generation
8. **Series and Parallel Circuits** - Circuit configurations
9. **AC vs DC** - Alternating and direct current
10. **Electrical Safety** - Safety practices and procedures
11. **Common Electrical Components** - Components and their functions

## 🔧 Development

### Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run start` - Start production server
- `npm run lint` - Run ESLint

### Adding Content

Educational content is stored in `content/Basic_Electricity_Tutor_Content.md`. The application automatically parses:
- Section headers (## Title)
- Visualizations (marked with specific syntax)
- Practice questions (structured format)

## 🐛 Troubleshooting

### Common Issues

1. **401 API Errors**: Check your OpenAI API key in `.env.local`
2. **Content Not Loading**: Ensure the content markdown file exists
3. **Port Already in Use**: The app will automatically use an available port
4. **Build Errors**: Run `npm install` to ensure all dependencies are installed

### Console Errors

If you see repeated 401 errors in the console, it means the OpenAI API key is not configured. The app will still work with default suggestions.

## 📄 License

This project is for educational purposes. Please ensure you comply with OpenAI's usage policies when using their API.

## 🤝 Contributing

This is an educational project. Feel free to extend it with additional features:
- More visualization types
- Additional practice question formats
- Enhanced AI prompting
- Progress persistence
- User accounts

---

**Happy Learning! ⚡📚**
