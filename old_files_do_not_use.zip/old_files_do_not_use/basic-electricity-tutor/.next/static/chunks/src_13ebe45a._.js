(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/components/layout/SplitScreenLayout.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>SplitScreenLayout)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function SplitScreenLayout({ contentPanel, aiChatPanel }) {
    _s();
    const [splitPosition, setSplitPosition] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(60); // Default split: 60% content, 40% chat
    const [isDragging, setIsDragging] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const handleDragStart = (e)=>{
        e.preventDefault();
        setIsDragging(true);
    };
    const handleDragEnd = ()=>{
        setIsDragging(false);
    };
    const handleDrag = (e)=>{
        if (!isDragging) return;
        const container = e.currentTarget;
        const containerRect = container.getBoundingClientRect();
        const newPosition = (e.clientX - containerRect.left) / containerRect.width * 100;
        // Constrain split position between 30% and 70%
        const constrainedPosition = Math.max(30, Math.min(70, newPosition));
        setSplitPosition(constrainedPosition);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col lg:flex-row h-screen overflow-hidden",
        onMouseMove: handleDrag,
        onMouseUp: handleDragEnd,
        onMouseLeave: handleDragEnd,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-none lg:flex-1 overflow-auto bg-white",
                style: {
                    width: `${splitPosition}%`
                },
                children: contentPanel
            }, void 0, false, {
                fileName: "[project]/src/components/layout/SplitScreenLayout.tsx",
                lineNumber: 43,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `
          hidden lg:block w-2 bg-gray-200 hover:bg-voltage-500 cursor-ew-resize
          ${isDragging ? 'bg-voltage-600' : ''}
        `,
                onMouseDown: handleDragStart
            }, void 0, false, {
                fileName: "[project]/src/components/layout/SplitScreenLayout.tsx",
                lineNumber: 51,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-none lg:flex-1 overflow-auto bg-gray-50 border-t lg:border-t-0 lg:border-l border-gray-200",
                style: {
                    width: `${100 - splitPosition}%`
                },
                children: aiChatPanel
            }, void 0, false, {
                fileName: "[project]/src/components/layout/SplitScreenLayout.tsx",
                lineNumber: 60,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/layout/SplitScreenLayout.tsx",
        lineNumber: 36,
        columnNumber: 5
    }, this);
}
_s(SplitScreenLayout, "ukLHSHLAT89M2HvdG+F877MsevI=");
_c = SplitScreenLayout;
var _c;
__turbopack_context__.k.register(_c, "SplitScreenLayout");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/visualizations/OhmsLawVisualization.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3/src/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-selection/src/select.js [app-client] (ecmascript) <export default as select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/linear.js [app-client] (ecmascript) <export default as scaleLinear>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-axis/src/axis.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__line$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-shape/src/line.js [app-client] (ecmascript) <export default as line>");
;
var _s = __turbopack_context__.k.signature();
;
;
/**
 * An interactive visualization demonstrating Ohm's Law (V = I × R)
 * Allows users to adjust voltage, current, or resistance and see how the other values change
 */ const OhmsLawVisualization = ({ initialVoltage = 12, initialCurrent = 2, initialResistance = 6 })=>{
    _s();
    const [voltage, setVoltage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialVoltage);
    const [current, setCurrent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialCurrent);
    const [resistance, setResistance] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialResistance);
    const [activeAdjustment, setActiveAdjustment] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('resistance');
    const svgRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const tooltipRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Calculate the dependent value based on which two values are being directly adjusted
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OhmsLawVisualization.useEffect": ()=>{
            if (activeAdjustment === 'voltage') {
                // V = I × R
                setVoltage(Number((current * resistance).toFixed(2)));
            } else if (activeAdjustment === 'current') {
                // I = V / R
                if (resistance !== 0) {
                    setCurrent(Number((voltage / resistance).toFixed(2)));
                }
            } else if (activeAdjustment === 'resistance') {
                // R = V / I
                if (current !== 0) {
                    setResistance(Number((voltage / current).toFixed(2)));
                }
            }
        }
    }["OhmsLawVisualization.useEffect"], [
        voltage,
        current,
        resistance,
        activeAdjustment
    ]);
    // Handle input changes for each parameter
    const handleVoltageChange = (e)=>{
        const value = parseFloat(e.target.value);
        if (!isNaN(value)) {
            setVoltage(value);
            setActiveAdjustment('voltage');
        }
    };
    const handleCurrentChange = (e)=>{
        const value = parseFloat(e.target.value);
        if (!isNaN(value)) {
            setCurrent(value);
            setActiveAdjustment('current');
        }
    };
    const handleResistanceChange = (e)=>{
        const value = parseFloat(e.target.value);
        if (!isNaN(value) && value !== 0) {
            setResistance(value);
            setActiveAdjustment('resistance');
        }
    };
    // Create or update the visualization using D3
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OhmsLawVisualization.useEffect": ()=>{
            if (!svgRef.current) return;
            // Clear previous visualization
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).selectAll("*").remove();
            // SVG dimensions and settings
            const width = 600;
            const height = 400;
            const margin = {
                top: 40,
                right: 40,
                bottom: 60,
                left: 60
            };
            const innerWidth = width - margin.left - margin.right;
            const innerHeight = height - margin.top - margin.bottom;
            // Select the SVG element
            const svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).attr("width", width).attr("height", height);
            // Create a group for the visualization content
            const g = svg.append("g").attr("transform", `translate(${margin.left},${margin.top})`);
            // Calculate the maximum values for the axes
            const maxVoltage = Math.max(voltage * 2, 20);
            const maxCurrent = Math.max(current * 2, 5);
            // Create scales for the axes
            const xScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
                0,
                maxCurrent
            ]).range([
                0,
                innerWidth
            ]).nice();
            const yScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
                0,
                maxVoltage
            ]).range([
                innerHeight,
                0
            ]).nice();
            // Create the X axis
            g.append("g").attr("transform", `translate(0,${innerHeight})`).call((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["axisBottom"])(xScale)).selectAll("text").attr("font-size", "12px");
            // X axis label
            g.append("text").attr("x", innerWidth / 2).attr("y", innerHeight + 40).attr("text-anchor", "middle").attr("fill", "currentColor").attr("font-size", "14px").text("Current (I) in Amperes");
            // Create the Y axis
            g.append("g").call((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["axisLeft"])(yScale)).selectAll("text").attr("font-size", "12px");
            // Y axis label
            g.append("text").attr("transform", "rotate(-90)").attr("x", -innerHeight / 2).attr("y", -40).attr("text-anchor", "middle").attr("fill", "currentColor").attr("font-size", "14px").text("Voltage (V) in Volts");
            // Calculate points for the resistance lines
            const getResistanceLine = {
                "OhmsLawVisualization.useEffect.getResistanceLine": (r)=>{
                    return [
                        {
                            x: 0,
                            y: 0
                        },
                        {
                            x: maxCurrent,
                            y: maxCurrent * r
                        }
                    ].filter({
                        "OhmsLawVisualization.useEffect.getResistanceLine": (d)=>d.y <= maxVoltage
                    }["OhmsLawVisualization.useEffect.getResistanceLine"]); // Ensure points are within the visible area
                }
            }["OhmsLawVisualization.useEffect.getResistanceLine"];
            // Draw multiple resistance lines
            const resistanceValues = [
                1,
                2,
                5,
                10,
                20
            ];
            resistanceValues.forEach({
                "OhmsLawVisualization.useEffect": (r)=>{
                    const lineData = getResistanceLine(r);
                    if (lineData.length >= 2) {
                        const line = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__line$3e$__["line"])().x({
                            "OhmsLawVisualization.useEffect.line": (d)=>xScale(d.x)
                        }["OhmsLawVisualization.useEffect.line"]).y({
                            "OhmsLawVisualization.useEffect.line": (d)=>yScale(d.y)
                        }["OhmsLawVisualization.useEffect.line"]);
                        g.append("path").datum(lineData).attr("fill", "none").attr("stroke", "#ddd").attr("stroke-width", 1).attr("stroke-dasharray", "5,5").attr("d", line);
                        // Add resistance value label at the end of the line
                        const lastPoint = lineData[lineData.length - 1];
                        g.append("text").attr("x", xScale(lastPoint.x) - 30).attr("y", yScale(lastPoint.y)).attr("fill", "#999").attr("font-size", "10px").text(`${r}Ω`);
                    }
                }
            }["OhmsLawVisualization.useEffect"]);
            // Draw the current resistance line
            const currentResistanceLine = getResistanceLine(resistance);
            if (currentResistanceLine.length >= 2) {
                const line = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__line$3e$__["line"])().x({
                    "OhmsLawVisualization.useEffect.line": (d)=>xScale(d.x)
                }["OhmsLawVisualization.useEffect.line"]).y({
                    "OhmsLawVisualization.useEffect.line": (d)=>yScale(d.y)
                }["OhmsLawVisualization.useEffect.line"]);
                g.append("path").datum(currentResistanceLine).attr("fill", "none").attr("stroke", "#ff6b6b").attr("stroke-width", 2).attr("d", line);
                // Add resistance value label
                g.append("text").attr("x", xScale(maxCurrent / 2)).attr("y", yScale(maxCurrent / 2 * resistance) - 10).attr("fill", "#ff6b6b").attr("font-size", "12px").attr("font-weight", "bold").attr("text-anchor", "middle").text(`R = ${resistance}Ω`);
            }
            // Add a point for the current V-I values
            g.append("circle").attr("cx", xScale(current)).attr("cy", yScale(voltage)).attr("r", 8).attr("fill", "#4361ee").attr("stroke", "#fff").attr("stroke-width", 2).attr("cursor", "pointer").on("mouseover", {
                "OhmsLawVisualization.useEffect": function(event) {
                    if (tooltipRef.current) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(tooltipRef.current).style("visibility", "visible").style("left", `${event.pageX + 10}px`).style("top", `${event.pageY - 30}px`).html(`
              <strong>Voltage (V):</strong> ${voltage}V<br>
              <strong>Current (I):</strong> ${current}A<br>
              <strong>Resistance (R):</strong> ${resistance}Ω
            `);
                    }
                }
            }["OhmsLawVisualization.useEffect"]).on("mouseout", {
                "OhmsLawVisualization.useEffect": function() {
                    if (tooltipRef.current) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(tooltipRef.current).style("visibility", "hidden");
                    }
                }
            }["OhmsLawVisualization.useEffect"]);
            // Add the title
            svg.append("text").attr("x", width / 2).attr("y", 20).attr("text-anchor", "middle").attr("font-size", "18px").attr("font-weight", "bold").text("Ohm's Law Visualization: V = I × R");
        }
    }["OhmsLawVisualization.useEffect"], [
        voltage,
        current,
        resistance
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "max-w-4xl mx-auto p-4 bg-white rounded-lg shadow-md dark:bg-gray-800",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "text-lg font-bold mb-4 text-gray-800 dark:text-white",
                children: "Ohm's Law Interactive Visualization"
            }, void 0, false, {
                fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                lineNumber: 250,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-6 grid grid-cols-1 md:grid-cols-3 gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "voltage",
                                className: "mb-2 font-medium text-gray-700 dark:text-gray-300",
                                children: "Voltage (V)"
                            }, void 0, false, {
                                fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                                lineNumber: 254,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "range",
                                        id: "voltage",
                                        min: "0",
                                        max: "50",
                                        step: "0.1",
                                        value: voltage,
                                        onChange: handleVoltageChange,
                                        className: "w-full",
                                        "aria-label": "Adjust voltage"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                                        lineNumber: 258,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "ml-2 w-16 text-right text-gray-700 dark:text-gray-300",
                                        children: [
                                            voltage,
                                            "V"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                                        lineNumber: 269,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                                lineNumber: 257,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                        lineNumber: 253,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "current",
                                className: "mb-2 font-medium text-gray-700 dark:text-gray-300",
                                children: "Current (I)"
                            }, void 0, false, {
                                fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                                lineNumber: 276,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "range",
                                        id: "current",
                                        min: "0.1",
                                        max: "10",
                                        step: "0.1",
                                        value: current,
                                        onChange: handleCurrentChange,
                                        className: "w-full",
                                        "aria-label": "Adjust current"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                                        lineNumber: 280,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "ml-2 w-16 text-right text-gray-700 dark:text-gray-300",
                                        children: [
                                            current,
                                            "A"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                                        lineNumber: 291,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                                lineNumber: 279,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                        lineNumber: 275,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "resistance",
                                className: "mb-2 font-medium text-gray-700 dark:text-gray-300",
                                children: "Resistance (R)"
                            }, void 0, false, {
                                fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                                lineNumber: 298,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "range",
                                        id: "resistance",
                                        min: "0.1",
                                        max: "20",
                                        step: "0.1",
                                        value: resistance,
                                        onChange: handleResistanceChange,
                                        className: "w-full",
                                        "aria-label": "Adjust resistance"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                                        lineNumber: 302,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "ml-2 w-16 text-right text-gray-700 dark:text-gray-300",
                                        children: [
                                            resistance,
                                            "Ω"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                                        lineNumber: 313,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                                lineNumber: 301,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                        lineNumber: 297,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                lineNumber: 252,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4 text-center bg-voltage-50 dark:bg-voltage-900 p-3 rounded-md",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-xl font-bold text-gray-800 dark:text-white",
                        children: [
                            "V = I × R  →  ",
                            voltage,
                            "V = ",
                            current,
                            "A × ",
                            resistance,
                            "Ω"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                        lineNumber: 321,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-sm text-gray-600 dark:text-gray-400 mt-1",
                        children: activeAdjustment === 'voltage' ? 'Voltage is calculated from current and resistance' : activeAdjustment === 'current' ? 'Current is calculated from voltage and resistance' : 'Resistance is calculated from voltage and current'
                    }, void 0, false, {
                        fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                        lineNumber: 324,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                lineNumber: 320,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative overflow-hidden",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                        ref: svgRef,
                        className: "w-full h-auto bg-white dark:bg-gray-900 rounded-lg"
                    }, void 0, false, {
                        fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                        lineNumber: 335,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: tooltipRef,
                        className: "absolute hidden bg-black bg-opacity-80 text-white p-2 rounded text-xs pointer-events-none",
                        style: {
                            visibility: 'hidden'
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                        lineNumber: 336,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                lineNumber: 334,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-4 text-sm text-gray-700 dark:text-gray-300",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: "Ohm's Law"
                            }, void 0, false, {
                                fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                                lineNumber: 344,
                                columnNumber: 12
                            }, this),
                            " states that the current through a conductor between two points is directly proportional to the voltage across the two points."
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                        lineNumber: 344,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                        className: "list-disc pl-5 mt-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Adjust any slider to see how it affects the other values"
                            }, void 0, false, {
                                fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                                lineNumber: 346,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "The red line shows your current resistance value"
                            }, void 0, false, {
                                fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                                lineNumber: 347,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Dotted lines represent reference resistance values"
                            }, void 0, false, {
                                fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                                lineNumber: 348,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Hover over the blue point to see exact values"
                            }, void 0, false, {
                                fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                                lineNumber: 349,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                        lineNumber: 345,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
                lineNumber: 343,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/visualizations/OhmsLawVisualization.tsx",
        lineNumber: 249,
        columnNumber: 5
    }, this);
};
_s(OhmsLawVisualization, "USAPecYdHcVp9RfYrYjNPXYUejs=");
_c = OhmsLawVisualization;
const __TURBOPACK__default__export__ = OhmsLawVisualization;
var _c;
__turbopack_context__.k.register(_c, "OhmsLawVisualization");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/visualizations/AtomicModelVisualization.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>AtomicModelVisualization)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/three/build/three.core.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/three/build/three.module.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$examples$2f$jsm$2f$controls$2f$OrbitControls$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/three/examples/jsm/controls/OrbitControls.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
function AtomicModelVisualization({ element = 'Generic', protons = 4, neutrons = 5, electrons = 4, shells = [
    2,
    2
], width = 400, height = 400, className = '' }) {
    _s();
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const rendererRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const sceneRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const cameraRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const controlsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const frameIdRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const electronGroupsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])([]);
    // Set up and clean up the Three.js scene
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AtomicModelVisualization.useEffect": ()=>{
            if (!containerRef.current) return;
            // Create scene
            const scene = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Scene"]();
            scene.background = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Color"](0xf5f5f5);
            sceneRef.current = scene;
            // Create camera
            const camera = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PerspectiveCamera"](75, width / height, 0.1, 1000);
            camera.position.z = 30;
            cameraRef.current = camera;
            // Create renderer
            const renderer = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["WebGLRenderer"]({
                antialias: true
            });
            renderer.setSize(width, height);
            renderer.setPixelRatio(window.devicePixelRatio);
            containerRef.current.appendChild(renderer.domElement);
            rendererRef.current = renderer;
            // Add orbit controls
            const controls = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$examples$2f$jsm$2f$controls$2f$OrbitControls$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OrbitControls"](camera, renderer.domElement);
            controls.enableDamping = true;
            controls.dampingFactor = 0.05;
            controlsRef.current = controls;
            // Add ambient light
            const ambientLight = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmbientLight"](0x404040);
            scene.add(ambientLight);
            // Add directional light
            const directionalLight = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DirectionalLight"](0xffffff, 1);
            directionalLight.position.set(1, 1, 1);
            scene.add(directionalLight);
            // Create nucleus
            createNucleus();
            // Create electron shells
            createElectronShells();
            // Animation loop
            const animate = {
                "AtomicModelVisualization.useEffect.animate": ()=>{
                    frameIdRef.current = requestAnimationFrame(animate);
                    // Rotate electron groups
                    electronGroupsRef.current.forEach({
                        "AtomicModelVisualization.useEffect.animate": (group, index)=>{
                            const rotationSpeed = 0.01 / (index + 1); // Outer shells rotate slower
                            group.rotation.z += rotationSpeed;
                            group.rotation.x += rotationSpeed * 0.3;
                        }
                    }["AtomicModelVisualization.useEffect.animate"]);
                    controls.update();
                    renderer.render(scene, camera);
                }
            }["AtomicModelVisualization.useEffect.animate"];
            animate();
            // Handle window resize
            const handleResize = {
                "AtomicModelVisualization.useEffect.handleResize": ()=>{
                    if (!containerRef.current || !cameraRef.current || !rendererRef.current) return;
                    const newWidth = containerRef.current.clientWidth;
                    const newHeight = containerRef.current.clientHeight;
                    cameraRef.current.aspect = newWidth / newHeight;
                    cameraRef.current.updateProjectionMatrix();
                    rendererRef.current.setSize(newWidth, newHeight);
                }
            }["AtomicModelVisualization.useEffect.handleResize"];
            window.addEventListener('resize', handleResize);
            // Cleanup function
            return ({
                "AtomicModelVisualization.useEffect": ()=>{
                    window.removeEventListener('resize', handleResize);
                    if (frameIdRef.current !== null) {
                        cancelAnimationFrame(frameIdRef.current);
                    }
                    if (rendererRef.current && containerRef.current) {
                        containerRef.current.removeChild(rendererRef.current.domElement);
                    }
                    scene.clear();
                }
            })["AtomicModelVisualization.useEffect"];
        }
    }["AtomicModelVisualization.useEffect"], [
        width,
        height
    ]);
    // Update the model when props change
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AtomicModelVisualization.useEffect": ()=>{
            if (!sceneRef.current) return;
            // Clear previous model
            while(sceneRef.current.children.length > 2){
                sceneRef.current.remove(sceneRef.current.children[2]);
            }
            electronGroupsRef.current = [];
            // Recreate model with new props
            createNucleus();
            createElectronShells();
        }
    }["AtomicModelVisualization.useEffect"], [
        element,
        protons,
        neutrons,
        electrons,
        shells
    ]);
    // Create the nucleus with protons and neutrons
    const createNucleus = ()=>{
        if (!sceneRef.current) return;
        const nucleusGroup = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Group"]();
        // Create a random but stable arrangement of protons and neutrons
        const nucleonRadius = 1;
        const positions = generateNucleonPositions(protons + neutrons, nucleonRadius);
        // Create protons (red)
        const protonGeometry = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SphereGeometry"](nucleonRadius, 32, 32);
        const protonMaterial = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MeshStandardMaterial"]({
            color: 0xff5555,
            roughness: 0.5,
            metalness: 0.1
        });
        for(let i = 0; i < protons; i++){
            const proton = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mesh"](protonGeometry, protonMaterial);
            proton.position.copy(positions[i]);
            nucleusGroup.add(proton);
            // Add positive charge indicator
            const chargeMaterial = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MeshBasicMaterial"]({
                color: 0xffffff
            });
            const chargeGeometry = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BoxGeometry"](0.4, 0.1, 0.1);
            const horizontalCharge = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mesh"](chargeGeometry, chargeMaterial);
            const verticalCharge = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mesh"](new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BoxGeometry"](0.1, 0.4, 0.1), chargeMaterial);
            const chargeGroup = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Group"]();
            chargeGroup.add(horizontalCharge);
            chargeGroup.add(verticalCharge);
            chargeGroup.position.copy(positions[i]);
            chargeGroup.position.y += 1;
            nucleusGroup.add(chargeGroup);
        }
        // Create neutrons (blue)
        const neutronGeometry = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SphereGeometry"](nucleonRadius, 32, 32);
        const neutronMaterial = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MeshStandardMaterial"]({
            color: 0x5555ff,
            roughness: 0.5,
            metalness: 0.1
        });
        for(let i = 0; i < neutrons; i++){
            const neutron = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mesh"](neutronGeometry, neutronMaterial);
            neutron.position.copy(positions[protons + i]);
            nucleusGroup.add(neutron);
        }
        sceneRef.current.add(nucleusGroup);
    };
    // Generate positions for nucleons in the nucleus
    const generateNucleonPositions = (count, radius)=>{
        const positions = [];
        const minDistance = radius * 1.8;
        // Helper function to check if a position is valid
        const isValidPosition = (pos)=>{
            for (const existing of positions){
                if (pos.distanceTo(existing) < minDistance) {
                    return false;
                }
            }
            return true;
        };
        // Generate positions using rejection sampling
        for(let i = 0; i < count; i++){
            let position;
            let attempts = 0;
            do {
                // Calculate a random position within a sphere
                const angle1 = Math.random() * Math.PI * 2;
                const angle2 = Math.random() * Math.PI * 2;
                const r = radius * 1.2 * Math.cbrt(Math.random()) * Math.min(3, Math.sqrt(count) * 0.5);
                position = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vector3"](r * Math.sin(angle1) * Math.cos(angle2), r * Math.sin(angle1) * Math.sin(angle2), r * Math.cos(angle1));
                attempts++;
            }while (!isValidPosition(position) && attempts < 100)
            positions.push(position);
        }
        return positions;
    };
    // Create electron shells and electrons
    const createElectronShells = ()=>{
        if (!sceneRef.current) return;
        // Calculate total electrons needed
        const totalElectrons = shells.reduce((sum, shellCount)=>sum + shellCount, 0);
        let electronCount = Math.min(electrons, totalElectrons);
        // Create shells
        for(let shellIndex = 0; shellIndex < shells.length; shellIndex++){
            const shellGroup = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Group"]();
            const shellRadius = (shellIndex + 1) * 6;
            // Create shell orbit (ring)
            const ringGeometry = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TorusGeometry"](shellRadius, 0.05, 16, 100);
            const ringMaterial = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MeshBasicMaterial"]({
                color: 0xcccccc,
                opacity: 0.5,
                transparent: true
            });
            const ring = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mesh"](ringGeometry, ringMaterial);
            shellGroup.add(ring);
            // Add a second ring at an angle to show the 3D nature of the shell
            const ring2 = ring.clone();
            ring2.rotation.x = Math.PI / 2;
            shellGroup.add(ring2);
            // Create electrons for this shell
            const electronsInShell = Math.min(shells[shellIndex], electronCount);
            electronCount -= electronsInShell;
            const electronGeometry = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SphereGeometry"](0.5, 32, 32);
            const electronMaterial = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MeshStandardMaterial"]({
                color: 0xffff00,
                emissive: 0xffff00,
                emissiveIntensity: 0.3,
                roughness: 0.3,
                metalness: 0.7
            });
            for(let i = 0; i < electronsInShell; i++){
                const electronGroup = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Group"]();
                const angle = i / electronsInShell * Math.PI * 2;
                const electron = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mesh"](electronGeometry, electronMaterial);
                electron.position.set(shellRadius * Math.cos(angle), shellRadius * Math.sin(angle), 0);
                // Add negative charge indicator
                const chargeMaterial = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MeshBasicMaterial"]({
                    color: 0xffffff
                });
                const chargeGeometry = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BoxGeometry"](0.3, 0.08, 0.08);
                const charge = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mesh"](chargeGeometry, chargeMaterial);
                charge.position.copy(electron.position);
                charge.position.y += 0.6;
                electronGroup.add(electron);
                electronGroup.add(charge);
                shellGroup.add(electronGroup);
            }
            // Add a small random rotation to each shell to make it more interesting
            shellGroup.rotation.x = Math.random() * Math.PI;
            shellGroup.rotation.z = Math.random() * Math.PI;
            sceneRef.current.add(shellGroup);
            electronGroupsRef.current.push(shellGroup);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: containerRef,
        className: `atomic-model ${className}`,
        style: {
            width: `${width}px`,
            height: `${height}px`
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute top-2 left-2 bg-white bg-opacity-70 px-2 py-1 rounded text-sm",
            children: [
                element,
                " (",
                protons,
                "p, ",
                neutrons,
                "n, ",
                electrons,
                "e-)"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/visualizations/AtomicModelVisualization.tsx",
            lineNumber: 312,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/visualizations/AtomicModelVisualization.tsx",
        lineNumber: 307,
        columnNumber: 5
    }, this);
}
_s(AtomicModelVisualization, "0M1KdtOZpRwqxQ7G1loLgU8s3us=");
_c = AtomicModelVisualization;
var _c;
__turbopack_context__.k.register(_c, "AtomicModelVisualization");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/visualizations/CircuitVisualization.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>CircuitVisualization)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3/src/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-selection/src/select.js [app-client] (ecmascript) <export default as select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$ease$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__linear__as__easeLinear$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-ease/src/linear.js [app-client] (ecmascript) <export linear as easeLinear>");
;
var _s = __turbopack_context__.k.signature();
;
;
function CircuitVisualization({ elements, connections, width = 600, height = 400, className = '', animate = true }) {
    _s();
    const svgRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CircuitVisualization.useEffect": ()=>{
            if (!svgRef.current) return;
            // Clear previous content
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).selectAll('*').remove();
            // Create SVG container
            const svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).attr('viewBox', `0 0 ${width} ${height}`).attr('width', '100%').attr('height', '100%');
            // Create definitions for component symbols
            const defs = svg.append('defs');
            // Battery symbol
            defs.append('symbol').attr('id', 'battery').attr('viewBox', '0 0 40 20').append('g').call({
                "CircuitVisualization.useEffect": (g)=>{
                    g.append('line').attr('x1', 0).attr('y1', 10).attr('x2', 12).attr('y2', 10).attr('stroke', 'black').attr('stroke-width', 2);
                    g.append('line').attr('x1', 12).attr('y1', 2).attr('x2', 12).attr('y2', 18).attr('stroke', 'black').attr('stroke-width', 2);
                    g.append('line').attr('x1', 18).attr('y1', 5).attr('x2', 18).attr('y2', 15).attr('stroke', 'black').attr('stroke-width', 2);
                    g.append('line').attr('x1', 18).attr('y1', 10).attr('x2', 40).attr('y2', 10).attr('stroke', 'black').attr('stroke-width', 2);
                    g.append('text').attr('x', 30).attr('y', 8).attr('font-size', 8).text('+');
                    g.append('text').attr('x', 6).attr('y', 8).attr('font-size', 8).text('-');
                }
            }["CircuitVisualization.useEffect"]);
            // Resistor symbol
            defs.append('symbol').attr('id', 'resistor').attr('viewBox', '0 0 40 20').append('g').call({
                "CircuitVisualization.useEffect": (g)=>{
                    g.append('line').attr('x1', 0).attr('y1', 10).attr('x2', 5).attr('y2', 10).attr('stroke', 'black').attr('stroke-width', 2);
                    g.append('path').attr('d', 'M5,10 L8,5 L13,15 L18,5 L23,15 L28,5 L33,15 L36,10').attr('fill', 'none').attr('stroke', 'black').attr('stroke-width', 2);
                    g.append('line').attr('x1', 36).attr('y1', 10).attr('x2', 40).attr('y2', 10).attr('stroke', 'black').attr('stroke-width', 2);
                }
            }["CircuitVisualization.useEffect"]);
            // Bulb symbol
            defs.append('symbol').attr('id', 'bulb').attr('viewBox', '0 0 40 30').append('g').call({
                "CircuitVisualization.useEffect": (g)=>{
                    g.append('line').attr('x1', 0).attr('y1', 15).attr('x2', 10).attr('y2', 15).attr('stroke', 'black').attr('stroke-width', 2);
                    g.append('circle').attr('cx', 20).attr('cy', 15).attr('r', 10).attr('stroke', 'black').attr('stroke-width', 2).attr('fill', 'white');
                    g.append('line').attr('x1', 15).attr('y1', 10).attr('x2', 25).attr('y2', 20).attr('stroke', 'black').attr('stroke-width', 1);
                    g.append('line').attr('x1', 15).attr('y1', 20).attr('x2', 25).attr('y2', 10).attr('stroke', 'black').attr('stroke-width', 1);
                    g.append('line').attr('x1', 30).attr('y1', 15).attr('x2', 40).attr('y2', 15).attr('stroke', 'black').attr('stroke-width', 2);
                }
            }["CircuitVisualization.useEffect"]);
            // Switch symbol
            defs.append('symbol').attr('id', 'switch-open').attr('viewBox', '0 0 40 20').append('g').call({
                "CircuitVisualization.useEffect": (g)=>{
                    g.append('line').attr('x1', 0).attr('y1', 10).attr('x2', 10).attr('y2', 10).attr('stroke', 'black').attr('stroke-width', 2);
                    g.append('circle').attr('cx', 10).attr('cy', 10).attr('r', 2).attr('stroke', 'black').attr('fill', 'black');
                    g.append('line').attr('x1', 10).attr('y1', 10).attr('x2', 30).attr('y2', 2).attr('stroke', 'black').attr('stroke-width', 2);
                    g.append('circle').attr('cx', 30).attr('cy', 10).attr('r', 2).attr('stroke', 'black').attr('fill', 'white');
                    g.append('line').attr('x1', 30).attr('y1', 10).attr('x2', 40).attr('y2', 10).attr('stroke', 'black').attr('stroke-width', 2);
                }
            }["CircuitVisualization.useEffect"]);
            defs.append('symbol').attr('id', 'switch-closed').attr('viewBox', '0 0 40 20').append('g').call({
                "CircuitVisualization.useEffect": (g)=>{
                    g.append('line').attr('x1', 0).attr('y1', 10).attr('x2', 10).attr('y2', 10).attr('stroke', 'black').attr('stroke-width', 2);
                    g.append('circle').attr('cx', 10).attr('cy', 10).attr('r', 2).attr('stroke', 'black').attr('fill', 'black');
                    g.append('line').attr('x1', 10).attr('y1', 10).attr('x2', 30).attr('y2', 10).attr('stroke', 'black').attr('stroke-width', 2);
                    g.append('circle').attr('cx', 30).attr('cy', 10).attr('r', 2).attr('stroke', 'black').attr('fill', 'white');
                    g.append('line').attr('x1', 30).attr('y1', 10).attr('x2', 40).attr('y2', 10).attr('stroke', 'black').attr('stroke-width', 2);
                }
            }["CircuitVisualization.useEffect"]);
            // Electron particles for animation
            if (animate) {
                defs.append('symbol').attr('id', 'electron').attr('viewBox', '0 0 6 6').append('circle').attr('cx', 3).attr('cy', 3).attr('r', 3).attr('fill', 'blue').attr('opacity', 0.7);
            }
            // Create connections (wires)
            const wireGroup = svg.append('g').attr('class', 'wires');
            // Create a layout of elements as a map for easy lookup
            const elementsMap = new Map(elements.map({
                "CircuitVisualization.useEffect": (el)=>[
                        el.id,
                        el
                    ]
            }["CircuitVisualization.useEffect"]));
            connections.forEach({
                "CircuitVisualization.useEffect": (conn, index)=>{
                    const source = elementsMap.get(conn.source);
                    const target = elementsMap.get(conn.target);
                    if (!source || !target) return;
                    const wire = wireGroup.append('line').attr('x1', source.x).attr('y1', source.y).attr('x2', target.x).attr('y2', target.y).attr('stroke', 'black').attr('stroke-width', 2);
                    // Add electron flow animation
                    if (animate) {
                        const totalLength = Math.sqrt(Math.pow(target.x - source.x, 2) + Math.pow(target.y - source.y, 2));
                        // Create electron particles along the wire
                        const numParticles = Math.ceil(totalLength / 30);
                        for(let i = 0; i < numParticles; i++){
                            const particle = svg.append('use').attr('href', '#electron').attr('width', 8).attr('height', 8).attr('x', -4).attr('y', -4);
                            // Create animation for the particle
                            function animateParticle() {
                                const duration = 2000;
                                const initialOffset = i / numParticles * duration;
                                particle.attr('opacity', 0).attr('transform', `translate(${source.x}, ${source.y})`).transition().delay(initialOffset).duration(0).attr('opacity', 0.8).transition().duration(duration).ease(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$ease$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__linear__as__easeLinear$3e$__["easeLinear"]).attr('transform', `translate(${target.x}, ${target.y})`).attr('opacity', 0).on('end', animateParticle);
                            }
                            animateParticle();
                        }
                    }
                }
            }["CircuitVisualization.useEffect"]);
            // Create circuit elements
            const componentsGroup = svg.append('g').attr('class', 'components');
            elements.forEach({
                "CircuitVisualization.useEffect": (el)=>{
                    const component = componentsGroup.append('g').attr('transform', `translate(${el.x}, ${el.y})${el.rotation ? ` rotate(${el.rotation})` : ''}`).attr('class', el.type);
                    let symbolId;
                    let width = 40;
                    let height = 20;
                    switch(el.type){
                        case 'battery':
                            symbolId = 'battery';
                            break;
                        case 'resistor':
                            symbolId = 'resistor';
                            break;
                        case 'bulb':
                            symbolId = 'bulb';
                            height = 30;
                            break;
                        case 'switch':
                            symbolId = el.state === 'closed' ? 'switch-closed' : 'switch-open';
                            break;
                        default:
                            return; // Skip unknown components
                    }
                    component.append('use').attr('href', `#${symbolId}`).attr('width', width).attr('height', height).attr('x', -width / 2).attr('y', -height / 2);
                    // Add value label for components that have values
                    if (el.value !== undefined) {
                        component.append('text').attr('x', 0).attr('y', height / 2 + 15).attr('text-anchor', 'middle').attr('font-size', 10).text(el.type === 'resistor' ? `${el.value} Ω` : el.type === 'battery' ? `${el.value} V` : `${el.value}`);
                    }
                    // Add interactivity for switches
                    if (el.type === 'switch') {
                        component.style('cursor', 'pointer');
                        component.on('click', {
                            "CircuitVisualization.useEffect": function() {
                                // In a real implementation, we would update the state and re-render
                                console.log(`Switch ${el.id} clicked`);
                            }
                        }["CircuitVisualization.useEffect"]);
                    }
                }
            }["CircuitVisualization.useEffect"]);
            return ({
                "CircuitVisualization.useEffect": ()=>{
                // Clean up animations on component unmount
                }
            })["CircuitVisualization.useEffect"];
        }
    }["CircuitVisualization.useEffect"], [
        elements,
        connections,
        width,
        height,
        animate
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `circuit-visualization ${className}`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            ref: svgRef,
            className: "w-full h-full"
        }, void 0, false, {
            fileName: "[project]/src/components/visualizations/CircuitVisualization.tsx",
            lineNumber: 338,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/visualizations/CircuitVisualization.tsx",
        lineNumber: 337,
        columnNumber: 5
    }, this);
}
_s(CircuitVisualization, "89Ty783ABEwsfMbSOeu9vscWF34=");
_c = CircuitVisualization;
var _c;
__turbopack_context__.k.register(_c, "CircuitVisualization");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/visualizations/WaveformVisualization.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>WaveformVisualization)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3/src/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-selection/src/select.js [app-client] (ecmascript) <export default as select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/linear.js [app-client] (ecmascript) <export default as scaleLinear>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-axis/src/axis.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__line$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-shape/src/line.js [app-client] (ecmascript) <export default as line>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$curve$2f$monotone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__monotoneX__as__curveMonotoneX$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-shape/src/curve/monotone.js [app-client] (ecmascript) <export monotoneX as curveMonotoneX>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function WaveformVisualization({ width = 600, height = 300, className = '', interactive = true, animate = true, showControls = true }) {
    _s();
    const svgRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [frequency, setFrequency] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [amplitude, setAmplitude] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [phase, setPhase] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [waveType, setWaveType] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('sine');
    const animationRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "WaveformVisualization.useEffect": ()=>{
            if (!svgRef.current) return;
            const svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current);
            svg.selectAll("*").remove();
            const margin = {
                top: 20,
                right: 20,
                bottom: 40,
                left: 50
            };
            const innerWidth = width - margin.left - margin.right;
            const innerHeight = height - margin.top - margin.bottom;
            // Create scales
            const xScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
                0,
                4 * Math.PI
            ]).range([
                0,
                innerWidth
            ]);
            const yScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
                -2,
                2
            ]).range([
                innerHeight,
                0
            ]);
            // Create main group
            const g = svg.append('g').attr('transform', `translate(${margin.left},${margin.top})`);
            // Add axes
            const xAxis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["axisBottom"])(xScale).tickFormat({
                "WaveformVisualization.useEffect.xAxis": (d)=>`${(d / Math.PI).toFixed(1)}π`
            }["WaveformVisualization.useEffect.xAxis"]);
            const yAxis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["axisLeft"])(yScale);
            g.append('g').attr('class', 'x-axis').attr('transform', `translate(0,${innerHeight})`).call(xAxis);
            g.append('g').attr('class', 'y-axis').call(yAxis);
            // Add axis labels
            g.append('text').attr('class', 'axis-label').attr('x', innerWidth / 2).attr('y', innerHeight + 35).style('text-anchor', 'middle').text('Time (radians)');
            g.append('text').attr('class', 'axis-label').attr('transform', 'rotate(-90)').attr('x', -innerHeight / 2).attr('y', -35).style('text-anchor', 'middle').text('Amplitude');
            // Generate waveform data
            const generateWaveData = {
                "WaveformVisualization.useEffect.generateWaveData": (timeOffset = 0)=>{
                    const data = [];
                    const numPoints = 200;
                    for(let i = 0; i <= numPoints; i++){
                        const x = i / numPoints * 4 * Math.PI;
                        let y = 0;
                        switch(waveType){
                            case 'sine':
                                y = amplitude * Math.sin(frequency * x + phase + timeOffset);
                                break;
                            case 'square':
                                y = amplitude * Math.sign(Math.sin(frequency * x + phase + timeOffset));
                                break;
                            case 'triangle':
                                y = amplitude * (2 / Math.PI) * Math.asin(Math.sin(frequency * x + phase + timeOffset));
                                break;
                        }
                        data.push({
                            x,
                            y
                        });
                    }
                    return data;
                }
            }["WaveformVisualization.useEffect.generateWaveData"];
            // Create line generator
            const line = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__line$3e$__["line"])().x({
                "WaveformVisualization.useEffect.line": (d)=>xScale(d.x)
            }["WaveformVisualization.useEffect.line"]).y({
                "WaveformVisualization.useEffect.line": (d)=>yScale(d.y)
            }["WaveformVisualization.useEffect.line"]).curve(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$curve$2f$monotone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__monotoneX__as__curveMonotoneX$3e$__["curveMonotoneX"]);
            // Add waveform path
            const path = g.append('path').attr('class', 'waveform').attr('fill', 'none').attr('stroke', '#2563eb').attr('stroke-width', 2);
            // Animation function
            const animateWave = {
                "WaveformVisualization.useEffect.animateWave": ()=>{
                    if (!animate) return;
                    let startTime = Date.now();
                    const updateWave = {
                        "WaveformVisualization.useEffect.animateWave.updateWave": ()=>{
                            const elapsed = (Date.now() - startTime) / 1000;
                            const timeOffset = elapsed * 2; // Animation speed
                            const data = generateWaveData(timeOffset);
                            path.datum(data).attr('d', line);
                            animationRef.current = requestAnimationFrame(updateWave);
                        }
                    }["WaveformVisualization.useEffect.animateWave.updateWave"];
                    updateWave();
                }
            }["WaveformVisualization.useEffect.animateWave"];
            // Initial render
            const initialData = generateWaveData();
            path.datum(initialData).attr('d', line);
            // Start animation
            if (animate) {
                animateWave();
            }
            // Add grid lines
            g.selectAll('.grid-line-x').data(xScale.ticks(8)).enter().append('line').attr('class', 'grid-line-x').attr('x1', {
                "WaveformVisualization.useEffect": (d)=>xScale(d)
            }["WaveformVisualization.useEffect"]).attr('x2', {
                "WaveformVisualization.useEffect": (d)=>xScale(d)
            }["WaveformVisualization.useEffect"]).attr('y1', 0).attr('y2', innerHeight).attr('stroke', '#e5e7eb').attr('stroke-width', 0.5);
            g.selectAll('.grid-line-y').data(yScale.ticks(6)).enter().append('line').attr('class', 'grid-line-y').attr('x1', 0).attr('x2', innerWidth).attr('y1', {
                "WaveformVisualization.useEffect": (d)=>yScale(d)
            }["WaveformVisualization.useEffect"]).attr('y2', {
                "WaveformVisualization.useEffect": (d)=>yScale(d)
            }["WaveformVisualization.useEffect"]).attr('stroke', '#e5e7eb').attr('stroke-width', 0.5);
            // Cleanup function
            return ({
                "WaveformVisualization.useEffect": ()=>{
                    if (animationRef.current) {
                        cancelAnimationFrame(animationRef.current);
                    }
                }
            })["WaveformVisualization.useEffect"];
        }
    }["WaveformVisualization.useEffect"], [
        frequency,
        amplitude,
        phase,
        waveType,
        animate,
        width,
        height
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `waveform-visualization ${className}`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white border border-gray-200 rounded-lg p-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                    className: "text-lg font-semibold mb-4",
                    children: "Waveform Generator"
                }, void 0, false, {
                    fileName: "[project]/src/components/visualizations/WaveformVisualization.tsx",
                    lineNumber: 188,
                    columnNumber: 9
                }, this),
                showControls && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "controls mb-4 space-y-3",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 md:grid-cols-4 gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "block text-sm font-medium text-gray-700 mb-1",
                                        children: "Wave Type"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/visualizations/WaveformVisualization.tsx",
                                        lineNumber: 194,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                        value: waveType,
                                        onChange: (e)=>setWaveType(e.target.value),
                                        className: "w-full px-3 py-1 border border-gray-300 rounded-md text-sm",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "sine",
                                                children: "Sine"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/visualizations/WaveformVisualization.tsx",
                                                lineNumber: 202,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "square",
                                                children: "Square"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/visualizations/WaveformVisualization.tsx",
                                                lineNumber: 203,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "triangle",
                                                children: "Triangle"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/visualizations/WaveformVisualization.tsx",
                                                lineNumber: 204,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/visualizations/WaveformVisualization.tsx",
                                        lineNumber: 197,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/visualizations/WaveformVisualization.tsx",
                                lineNumber: 193,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "block text-sm font-medium text-gray-700 mb-1",
                                        children: [
                                            "Frequency: ",
                                            frequency.toFixed(1)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/visualizations/WaveformVisualization.tsx",
                                        lineNumber: 209,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "range",
                                        min: "0.1",
                                        max: "3",
                                        step: "0.1",
                                        value: frequency,
                                        onChange: (e)=>setFrequency(parseFloat(e.target.value)),
                                        className: "w-full"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/visualizations/WaveformVisualization.tsx",
                                        lineNumber: 212,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/visualizations/WaveformVisualization.tsx",
                                lineNumber: 208,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "block text-sm font-medium text-gray-700 mb-1",
                                        children: [
                                            "Amplitude: ",
                                            amplitude.toFixed(1)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/visualizations/WaveformVisualization.tsx",
                                        lineNumber: 224,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "range",
                                        min: "0.1",
                                        max: "2",
                                        step: "0.1",
                                        value: amplitude,
                                        onChange: (e)=>setAmplitude(parseFloat(e.target.value)),
                                        className: "w-full"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/visualizations/WaveformVisualization.tsx",
                                        lineNumber: 227,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/visualizations/WaveformVisualization.tsx",
                                lineNumber: 223,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "block text-sm font-medium text-gray-700 mb-1",
                                        children: [
                                            "Phase: ",
                                            (phase * 180 / Math.PI).toFixed(0),
                                            "°"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/visualizations/WaveformVisualization.tsx",
                                        lineNumber: 239,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "range",
                                        min: "0",
                                        max: 2 * Math.PI,
                                        step: "0.1",
                                        value: phase,
                                        onChange: (e)=>setPhase(parseFloat(e.target.value)),
                                        className: "w-full"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/visualizations/WaveformVisualization.tsx",
                                        lineNumber: 242,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/visualizations/WaveformVisualization.tsx",
                                lineNumber: 238,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/visualizations/WaveformVisualization.tsx",
                        lineNumber: 192,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/visualizations/WaveformVisualization.tsx",
                    lineNumber: 191,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "visualization-container",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                        ref: svgRef,
                        width: width,
                        height: height,
                        className: "border border-gray-100 rounded"
                    }, void 0, false, {
                        fileName: "[project]/src/components/visualizations/WaveformVisualization.tsx",
                        lineNumber: 257,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/visualizations/WaveformVisualization.tsx",
                    lineNumber: 256,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-3 text-sm text-gray-600",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: "This visualization shows different types of electrical waveforms commonly found in AC circuits. Adjust the controls to see how frequency, amplitude, and phase affect the waveform shape."
                    }, void 0, false, {
                        fileName: "[project]/src/components/visualizations/WaveformVisualization.tsx",
                        lineNumber: 266,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/visualizations/WaveformVisualization.tsx",
                    lineNumber: 265,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/visualizations/WaveformVisualization.tsx",
            lineNumber: 187,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/visualizations/WaveformVisualization.tsx",
        lineNumber: 186,
        columnNumber: 5
    }, this);
}
_s(WaveformVisualization, "A7Y7hoY5lfQqKmYFoy+iPdm0/zs=");
_c = WaveformVisualization;
var _c;
__turbopack_context__.k.register(_c, "WaveformVisualization");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/visualizations/PowerTriangleVisualization.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>PowerTriangleVisualization)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3/src/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-selection/src/select.js [app-client] (ecmascript) <export default as select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__line$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-shape/src/line.js [app-client] (ecmascript) <export default as line>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$arc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__arc$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-shape/src/arc.js [app-client] (ecmascript) <export default as arc>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function PowerTriangleVisualization({ width = 400, height = 400, className = '', interactive = true, showVectors = true }) {
    _s();
    const svgRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [realPower, setRealPower] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(300); // P (Watts)
    const [reactivePower, setReactivePower] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(400); // Q (VAR)
    const [powerFactor, setPowerFactor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0.75);
    // Calculate derived values
    const apparentPower = Math.sqrt(realPower * realPower + reactivePower * reactivePower); // S (VA)
    const phaseAngle = Math.atan2(reactivePower, realPower) * (180 / Math.PI); // θ in degrees
    const calculatedPF = realPower / apparentPower;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PowerTriangleVisualization.useEffect": ()=>{
            if (!svgRef.current) return;
            const svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current);
            svg.selectAll("*").remove();
            const margin = {
                top: 40,
                right: 40,
                bottom: 40,
                left: 40
            };
            const innerWidth = width - margin.left - margin.right;
            const innerHeight = height - margin.top - margin.bottom;
            const centerX = innerWidth / 2;
            const centerY = innerHeight / 2;
            // Create main group
            const g = svg.append('g').attr('transform', `translate(${margin.left},${margin.top})`);
            // Scale factor for visualization
            const maxPower = Math.max(realPower, reactivePower, apparentPower);
            const scale = Math.min(centerX, centerY) * 0.8 / maxPower;
            // Calculate triangle points
            const origin = {
                x: centerX - realPower * scale / 2,
                y: centerY + reactivePower * scale / 2
            };
            const realPoint = {
                x: origin.x + realPower * scale,
                y: origin.y
            };
            const reactivePoint = {
                x: origin.x,
                y: origin.y - reactivePower * scale
            };
            // Draw coordinate system
            g.append('line').attr('x1', 0).attr('x2', innerWidth).attr('y1', centerY).attr('y2', centerY).attr('stroke', '#e5e7eb').attr('stroke-width', 1);
            g.append('line').attr('x1', centerX).attr('x2', centerX).attr('y1', 0).attr('y2', innerHeight).attr('stroke', '#e5e7eb').attr('stroke-width', 1);
            // Draw power triangle
            const triangleData = [
                origin,
                realPoint,
                reactivePoint,
                origin
            ];
            const line = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__line$3e$__["line"])().x({
                "PowerTriangleVisualization.useEffect.line": (d)=>d.x
            }["PowerTriangleVisualization.useEffect.line"]).y({
                "PowerTriangleVisualization.useEffect.line": (d)=>d.y
            }["PowerTriangleVisualization.useEffect.line"]);
            // Triangle outline
            g.append('path').datum(triangleData).attr('d', line).attr('fill', 'rgba(59, 130, 246, 0.1)').attr('stroke', '#3b82f6').attr('stroke-width', 2);
            // Draw individual vectors
            if (showVectors) {
                // Real Power (P) - horizontal red vector
                g.append('line').attr('x1', origin.x).attr('x2', realPoint.x).attr('y1', origin.y).attr('y2', realPoint.y).attr('stroke', '#dc2626').attr('stroke-width', 3).attr('marker-end', 'url(#arrowhead-red)');
                // Reactive Power (Q) - vertical blue vector
                g.append('line').attr('x1', origin.x).attr('x2', reactivePoint.x).attr('y1', origin.y).attr('y2', reactivePoint.y).attr('stroke', '#2563eb').attr('stroke-width', 3).attr('marker-end', 'url(#arrowhead-blue)');
                // Apparent Power (S) - diagonal green vector
                g.append('line').attr('x1', origin.x).attr('x2', reactivePoint.x).attr('y1', origin.y).attr('y2', reactivePoint.y).attr('stroke', '#16a34a').attr('stroke-width', 3).attr('marker-end', 'url(#arrowhead-green)');
            }
            // Add arrowhead markers
            const defs = svg.append('defs');
            [
                'red',
                'blue',
                'green'
            ].forEach({
                "PowerTriangleVisualization.useEffect": (color, index)=>{
                    const colors = [
                        '#dc2626',
                        '#2563eb',
                        '#16a34a'
                    ];
                    defs.append('marker').attr('id', `arrowhead-${color}`).attr('viewBox', '0 -5 10 10').attr('refX', 8).attr('refY', 0).attr('markerWidth', 6).attr('markerHeight', 6).attr('orient', 'auto').append('path').attr('d', 'M0,-5L10,0L0,5').attr('fill', colors[index]);
                }
            }["PowerTriangleVisualization.useEffect"]);
            // Add labels
            const labelOffset = 15;
            // Real Power label
            g.append('text').attr('x', (origin.x + realPoint.x) / 2).attr('y', origin.y + labelOffset).attr('text-anchor', 'middle').attr('class', 'power-label').style('font-size', '12px').style('font-weight', 'bold').style('fill', '#dc2626').text(`P = ${realPower.toFixed(0)} W`);
            // Reactive Power label
            g.append('text').attr('x', origin.x - labelOffset).attr('y', (origin.y + reactivePoint.y) / 2).attr('text-anchor', 'middle').attr('class', 'power-label').style('font-size', '12px').style('font-weight', 'bold').style('fill', '#2563eb').text(`Q = ${reactivePower.toFixed(0)} VAR`);
            // Apparent Power label
            g.append('text').attr('x', (origin.x + reactivePoint.x) / 2 - 20).attr('y', (origin.y + reactivePoint.y) / 2 - 10).attr('text-anchor', 'middle').attr('class', 'power-label').style('font-size', '12px').style('font-weight', 'bold').style('fill', '#16a34a').text(`S = ${apparentPower.toFixed(0)} VA`);
            // Phase angle arc
            const arcRadius = 40;
            const arc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$arc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__arc$3e$__["arc"])().innerRadius(0).outerRadius(arcRadius).startAngle(0).endAngle(phaseAngle * Math.PI / 180);
            g.append('path').attr('d', arc).attr('transform', `translate(${origin.x},${origin.y})`).attr('fill', 'rgba(251, 191, 36, 0.3)').attr('stroke', '#f59e0b').attr('stroke-width', 1);
            // Phase angle label
            g.append('text').attr('x', origin.x + arcRadius + 10).attr('y', origin.y - 5).attr('class', 'angle-label').style('font-size', '11px').style('fill', '#f59e0b').text(`θ = ${phaseAngle.toFixed(1)}°`);
        }
    }["PowerTriangleVisualization.useEffect"], [
        realPower,
        reactivePower,
        width,
        height,
        showVectors
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `power-triangle-visualization ${className}`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white border border-gray-200 rounded-lg p-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                    className: "text-lg font-semibold mb-4",
                    children: "AC Power Triangle"
                }, void 0, false, {
                    fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                    lineNumber: 204,
                    columnNumber: 9
                }, this),
                interactive && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "controls mb-4 space-y-3",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "block text-sm font-medium text-gray-700 mb-1",
                                        children: [
                                            "Real Power (P): ",
                                            realPower.toFixed(0),
                                            " W"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                                        lineNumber: 210,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "range",
                                        min: "100",
                                        max: "500",
                                        step: "10",
                                        value: realPower,
                                        onChange: (e)=>setRealPower(parseFloat(e.target.value)),
                                        className: "w-full"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                                        lineNumber: 213,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                                lineNumber: 209,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "block text-sm font-medium text-gray-700 mb-1",
                                        children: [
                                            "Reactive Power (Q): ",
                                            reactivePower.toFixed(0),
                                            " VAR"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                                        lineNumber: 225,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "range",
                                        min: "0",
                                        max: "500",
                                        step: "10",
                                        value: reactivePower,
                                        onChange: (e)=>setReactivePower(parseFloat(e.target.value)),
                                        className: "w-full"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                                        lineNumber: 228,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                                lineNumber: 224,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                        lineNumber: 208,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                    lineNumber: 207,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "visualization-container mb-4",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                        ref: svgRef,
                        width: width,
                        height: height,
                        className: "border border-gray-100 rounded"
                    }, void 0, false, {
                        fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                        lineNumber: 243,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                    lineNumber: 242,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "power-calculations bg-gray-50 p-3 rounded-lg",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                            className: "font-medium text-gray-800 mb-2",
                            children: "Power Calculations:"
                        }, void 0, false, {
                            fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                            lineNumber: 252,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid grid-cols-2 md:grid-cols-4 gap-3 text-sm",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-red-600 font-medium",
                                            children: "Real Power (P):"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                                            lineNumber: 255,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                            fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                                            lineNumber: 256,
                                            columnNumber: 15
                                        }, this),
                                        realPower.toFixed(0),
                                        " W"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                                    lineNumber: 254,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-blue-600 font-medium",
                                            children: "Reactive Power (Q):"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                                            lineNumber: 260,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                            fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                                            lineNumber: 261,
                                            columnNumber: 15
                                        }, this),
                                        reactivePower.toFixed(0),
                                        " VAR"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                                    lineNumber: 259,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-green-600 font-medium",
                                            children: "Apparent Power (S):"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                                            lineNumber: 265,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                            fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                                            lineNumber: 266,
                                            columnNumber: 15
                                        }, this),
                                        apparentPower.toFixed(0),
                                        " VA"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                                    lineNumber: 264,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-yellow-600 font-medium",
                                            children: "Power Factor:"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                                            lineNumber: 270,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                            fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                                            lineNumber: 271,
                                            columnNumber: 15
                                        }, this),
                                        calculatedPF.toFixed(3)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                                    lineNumber: 269,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                            lineNumber: 253,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-3 text-xs text-gray-600",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                            children: "Formula:"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                                            lineNumber: 277,
                                            columnNumber: 16
                                        }, this),
                                        " S² = P² + Q²"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                                    lineNumber: 277,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                            children: "Power Factor:"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                                            lineNumber: 278,
                                            columnNumber: 16
                                        }, this),
                                        " cos(θ) = P/S = ",
                                        calculatedPF.toFixed(3)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                                    lineNumber: 278,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                            children: "Phase Angle:"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                                            lineNumber: 279,
                                            columnNumber: 16
                                        }, this),
                                        " θ = arctan(Q/P) = ",
                                        phaseAngle.toFixed(1),
                                        "°"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                                    lineNumber: 279,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                            lineNumber: 276,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                    lineNumber: 251,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-3 text-sm text-gray-600",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: "The power triangle shows the relationship between real power (P), reactive power (Q), and apparent power (S) in AC circuits. Adjust the sliders to see how changes affect the power factor and phase angle."
                    }, void 0, false, {
                        fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                        lineNumber: 284,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
                    lineNumber: 283,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
            lineNumber: 203,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/visualizations/PowerTriangleVisualization.tsx",
        lineNumber: 202,
        columnNumber: 5
    }, this);
}
_s(PowerTriangleVisualization, "HCzgSq1LHzjKSJxLtKXHHAG1We8=");
_c = PowerTriangleVisualization;
var _c;
__turbopack_context__.k.register(_c, "PowerTriangleVisualization");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/visualizations/VisualizationRenderer.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>VisualizationRenderer)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$visualizations$2f$OhmsLawVisualization$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/visualizations/OhmsLawVisualization.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$visualizations$2f$AtomicModelVisualization$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/visualizations/AtomicModelVisualization.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$visualizations$2f$CircuitVisualization$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/visualizations/CircuitVisualization.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$visualizations$2f$WaveformVisualization$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/visualizations/WaveformVisualization.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$visualizations$2f$PowerTriangleVisualization$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/visualizations/PowerTriangleVisualization.tsx [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
function VisualizationRenderer({ visualization, className = '' }) {
    const { type, configData = {} } = visualization;
    switch(type){
        case 'circuit':
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$visualizations$2f$CircuitVisualization$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                elements: configData.elements || [],
                connections: configData.connections || [],
                width: configData.width || 600,
                height: configData.height || 400,
                className: className,
                animate: configData.animate !== false
            }, void 0, false, {
                fileName: "[project]/src/components/visualizations/VisualizationRenderer.tsx",
                lineNumber: 29,
                columnNumber: 9
            }, this);
        case 'atomic':
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$visualizations$2f$AtomicModelVisualization$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                element: configData.element || 'Generic',
                protons: configData.protons || 4,
                neutrons: configData.neutrons || 5,
                electrons: configData.electrons || 4,
                shells: configData.shells || [
                    2,
                    2
                ],
                width: configData.width || 400,
                height: configData.height || 400,
                className: className
            }, void 0, false, {
                fileName: "[project]/src/components/visualizations/VisualizationRenderer.tsx",
                lineNumber: 41,
                columnNumber: 9
            }, this);
        case 'waveform':
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$visualizations$2f$WaveformVisualization$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: className,
                ...configData
            }, void 0, false, {
                fileName: "[project]/src/components/visualizations/VisualizationRenderer.tsx",
                lineNumber: 55,
                columnNumber: 9
            }, this);
        case 'power-triangle':
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$visualizations$2f$PowerTriangleVisualization$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: className,
                ...configData
            }, void 0, false, {
                fileName: "[project]/src/components/visualizations/VisualizationRenderer.tsx",
                lineNumber: 63,
                columnNumber: 9
            }, this);
        case 'graph':
            if (configData.type === 'ohms-law') {
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$visualizations$2f$OhmsLawVisualization$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    initialVoltage: configData.voltage || 5,
                    initialCurrent: configData.current || 0.5,
                    initialResistance: configData.resistance || 10
                }, void 0, false, {
                    fileName: "[project]/src/components/visualizations/VisualizationRenderer.tsx",
                    lineNumber: 72,
                    columnNumber: 11
                }, this);
            }
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `visualization-placeholder ${className}`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: [
                        'Graph visualization type "',
                        configData.type,
                        '" not implemented yet'
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/visualizations/VisualizationRenderer.tsx",
                    lineNumber: 81,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/visualizations/VisualizationRenderer.tsx",
                lineNumber: 80,
                columnNumber: 9
            }, this);
        default:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `visualization-placeholder ${className}`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: [
                        'Visualization type "',
                        type,
                        '" not implemented yet'
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/visualizations/VisualizationRenderer.tsx",
                    lineNumber: 88,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/visualizations/VisualizationRenderer.tsx",
                lineNumber: 87,
                columnNumber: 9
            }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `visualization-container ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "visualization-header mb-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-semibold text-gray-800",
                        children: visualization.title
                    }, void 0, false, {
                        fileName: "[project]/src/components/visualizations/VisualizationRenderer.tsx",
                        lineNumber: 96,
                        columnNumber: 9
                    }, this),
                    visualization.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-gray-600 mt-1",
                        children: visualization.description
                    }, void 0, false, {
                        fileName: "[project]/src/components/visualizations/VisualizationRenderer.tsx",
                        lineNumber: 100,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/visualizations/VisualizationRenderer.tsx",
                lineNumber: 95,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "visualization-content"
            }, void 0, false, {
                fileName: "[project]/src/components/visualizations/VisualizationRenderer.tsx",
                lineNumber: 105,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/visualizations/VisualizationRenderer.tsx",
        lineNumber: 94,
        columnNumber: 5
    }, this);
}
_c = VisualizationRenderer;
var _c;
__turbopack_context__.k.register(_c, "VisualizationRenderer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/quiz/QuizComponent.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>QuizComponent)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function QuizComponent({ questions, onComplete, className = '', showHints = true, allowRetry = true }) {
    _s();
    const [currentQuestionIndex, setCurrentQuestionIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [selectedAnswer, setSelectedAnswer] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [textAnswer, setTextAnswer] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [isAnswered, setIsAnswered] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isCorrect, setIsCorrect] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [score, setScore] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [showExplanation, setShowExplanation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showHint, setShowHint] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [quizCompleted, setQuizCompleted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [quizResults, setQuizResults] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [questionStartTime, setQuestionStartTime] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(Date.now());
    const [attempts, setAttempts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    // Get the current question
    const currentQuestion = questions[currentQuestionIndex];
    // Check if this is the last question
    const isLastQuestion = currentQuestionIndex === questions.length - 1;
    // Progress calculation
    const progress = (currentQuestionIndex + (isAnswered ? 1 : 0)) / questions.length * 100;
    // Reset question timer when question changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "QuizComponent.useEffect": ()=>{
            setQuestionStartTime(Date.now());
        }
    }["QuizComponent.useEffect"], [
        currentQuestionIndex
    ]);
    /**
   * Handle submission of an answer
   */ const handleSubmitAnswer = ()=>{
        const answer = currentQuestion.type === 'multiple-choice' ? selectedAnswer : textAnswer;
        let correct = false;
        // Validate that an answer was provided
        if (!answer.trim()) {
            alert('Please provide an answer before submitting.');
            return;
        }
        // Check if the answer is correct
        if (currentQuestion.type === 'multiple-choice') {
            correct = answer === currentQuestion.correctAnswer;
        } else {
            // For text input, check if the answer matches any of the acceptable answers
            const acceptableAnswers = Array.isArray(currentQuestion.correctAnswer) ? currentQuestion.correctAnswer : [
                currentQuestion.correctAnswer
            ];
            correct = acceptableAnswers.some((correctAns)=>answer.toLowerCase().trim() === correctAns.toLowerCase().trim());
        }
        // Calculate time spent on this question
        const timeSpent = Date.now() - questionStartTime;
        // Create result record
        const result = {
            questionId: currentQuestion.id,
            question: currentQuestion.question,
            userAnswer: answer,
            correctAnswer: Array.isArray(currentQuestion.correctAnswer) ? currentQuestion.correctAnswer[0] : currentQuestion.correctAnswer,
            isCorrect: correct,
            timeSpent
        };
        // Update state based on answer correctness
        setIsAnswered(true);
        setIsCorrect(correct);
        setShowExplanation(true);
        setAttempts((prev)=>prev + 1);
        if (correct) {
            setScore((prev)=>prev + 1);
        }
        // Add result to quiz results
        setQuizResults((prev)=>[
                ...prev,
                result
            ]);
    };
    /**
   * Handle retry for current question (if allowed)
   */ const handleRetryQuestion = ()=>{
        setSelectedAnswer('');
        setTextAnswer('');
        setIsAnswered(false);
        setShowExplanation(false);
        setShowHint(false);
        setQuestionStartTime(Date.now());
    };
    /**
   * Move to the next question or complete the quiz
   */ const handleNextQuestion = ()=>{
        if (isLastQuestion) {
            setQuizCompleted(true);
            onComplete?.(score, questions.length, quizResults);
        } else {
            setCurrentQuestionIndex((prev)=>prev + 1);
            setSelectedAnswer('');
            setTextAnswer('');
            setIsAnswered(false);
            setShowExplanation(false);
            setShowHint(false);
            setAttempts(0);
        }
    };
    /**
   * Reset the quiz to start over
   */ const handleResetQuiz = ()=>{
        setCurrentQuestionIndex(0);
        setSelectedAnswer('');
        setTextAnswer('');
        setIsAnswered(false);
        setIsCorrect(false);
        setScore(0);
        setShowExplanation(false);
        setShowHint(false);
        setQuizCompleted(false);
        setQuizResults([]);
        setAttempts(0);
        setQuestionStartTime(Date.now());
    };
    /**
   * Toggle hint visibility
   */ const handleToggleHint = ()=>{
        setShowHint((prev)=>!prev);
    };
    // If no questions are provided, show a message
    if (questions.length === 0) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: `quiz-container ${className} p-6 bg-white rounded-lg shadow-sm border`,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center text-gray-500",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-4xl mb-4",
                        children: "📝"
                    }, void 0, false, {
                        fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                        lineNumber: 176,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-medium mb-2",
                        children: "No Practice Questions Available"
                    }, void 0, false, {
                        fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                        lineNumber: 177,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm",
                        children: "Practice questions will appear here when available for this section."
                    }, void 0, false, {
                        fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                        lineNumber: 178,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                lineNumber: 175,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/quiz/QuizComponent.tsx",
            lineNumber: 174,
            columnNumber: 7
        }, this);
    }
    // Quiz completion screen
    if (quizCompleted) {
        const percentage = Math.round(score / questions.length * 100);
        const performanceLevel = percentage >= 80 ? 'excellent' : percentage >= 60 ? 'good' : 'needs-improvement';
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: `quiz-container ${className} p-6 bg-white rounded-lg shadow-sm border`,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-6xl mb-4",
                        children: performanceLevel === 'excellent' ? '🎉' : performanceLevel === 'good' ? '👍' : '📚'
                    }, void 0, false, {
                        fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                        lineNumber: 192,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-2xl font-bold mb-4",
                        children: "Quiz Complete!"
                    }, void 0, false, {
                        fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                        lineNumber: 195,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-gray-50 rounded-lg p-4 mb-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-3xl font-bold text-blue-600 mb-2",
                                children: [
                                    score,
                                    "/",
                                    questions.length
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                                lineNumber: 198,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-lg text-gray-700 mb-1",
                                children: [
                                    percentage,
                                    "% Correct"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                                lineNumber: 199,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-sm text-gray-500",
                                children: [
                                    performanceLevel === 'excellent' && 'Excellent work! You have a strong understanding of this topic.',
                                    performanceLevel === 'good' && 'Good job! You understand most of the concepts.',
                                    performanceLevel === 'needs-improvement' && 'Keep studying! Review the material and try again.'
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                                lineNumber: 200,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                        lineNumber: 197,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-left mb-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                className: "font-semibold mb-3",
                                children: "Question Review:"
                            }, void 0, false, {
                                fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                                lineNumber: 209,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "space-y-2 max-h-60 overflow-y-auto",
                                children: quizResults.map((result, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: `p-3 rounded border-l-4 ${result.isCorrect ? 'border-green-500 bg-green-50' : 'border-red-500 bg-red-50'}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-sm font-medium",
                                                children: [
                                                    "Q",
                                                    index + 1,
                                                    ": ",
                                                    result.question
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                                                lineNumber: 215,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-xs text-gray-600 mt-1",
                                                children: [
                                                    "Your answer: ",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: result.isCorrect ? 'text-green-700' : 'text-red-700',
                                                        children: result.userAnswer
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                                                        lineNumber: 217,
                                                        columnNumber: 34
                                                    }, this),
                                                    !result.isCorrect && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "ml-2",
                                                        children: [
                                                            "(Correct: ",
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-green-700",
                                                                children: result.correctAnswer
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                                                                lineNumber: 222,
                                                                columnNumber: 35
                                                            }, this),
                                                            ")"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                                                        lineNumber: 221,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                                                lineNumber: 216,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, result.questionId, true, {
                                        fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                                        lineNumber: 212,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                                lineNumber: 210,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                        lineNumber: 208,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3 justify-center",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: handleResetQuiz,
                            className: "px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors",
                            children: "Try Again"
                        }, void 0, false, {
                            fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                            lineNumber: 232,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                        lineNumber: 231,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                lineNumber: 191,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/quiz/QuizComponent.tsx",
            lineNumber: 190,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `quiz-container ${className} p-6 bg-white rounded-lg shadow-sm border`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-between items-center mb-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-sm font-medium text-gray-700",
                                children: [
                                    "Question ",
                                    currentQuestionIndex + 1,
                                    " of ",
                                    questions.length
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                                lineNumber: 249,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-sm text-gray-500",
                                children: [
                                    "Score: ",
                                    score,
                                    "/",
                                    currentQuestionIndex + (isAnswered && isCorrect ? 1 : 0)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                                lineNumber: 252,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                        lineNumber: 248,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-full bg-gray-200 rounded-full h-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-blue-600 h-2 rounded-full transition-all duration-300",
                            style: {
                                width: `${progress}%`
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                            lineNumber: 257,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                        lineNumber: 256,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                lineNumber: 247,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-semibold mb-4 text-gray-800",
                        children: currentQuestion.question
                    }, void 0, false, {
                        fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                        lineNumber: 266,
                        columnNumber: 9
                    }, this),
                    currentQuestion.type === 'multiple-choice' && currentQuestion.options && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-3",
                        children: currentQuestion.options.map((option, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: `flex items-center p-3 border rounded-lg cursor-pointer transition-colors ${selectedAnswer === option ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'} ${isAnswered ? 'cursor-not-allowed' : ''}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "radio",
                                        name: "answer",
                                        value: option,
                                        checked: selectedAnswer === option,
                                        onChange: (e)=>setSelectedAnswer(e.target.value),
                                        disabled: isAnswered,
                                        className: "mr-3"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                                        lineNumber: 282,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: isAnswered ? 'text-gray-600' : 'text-gray-800',
                                        children: option
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                                        lineNumber: 291,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, index, true, {
                                fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                                lineNumber: 274,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                        lineNumber: 272,
                        columnNumber: 11
                    }, this),
                    currentQuestion.type === 'text-input' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                            value: textAnswer,
                            onChange: (e)=>setTextAnswer(e.target.value),
                            disabled: isAnswered,
                            placeholder: "Enter your answer here...",
                            className: "w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-100 disabled:text-gray-600",
                            rows: 3
                        }, void 0, false, {
                            fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                            lineNumber: 302,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                        lineNumber: 301,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                lineNumber: 265,
                columnNumber: 7
            }, this),
            showHints && currentQuestion.hint && !isAnswered && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handleToggleHint,
                        className: "text-sm text-blue-600 hover:text-blue-800 flex items-center",
                        children: [
                            "💡 ",
                            showHint ? 'Hide Hint' : 'Show Hint'
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                        lineNumber: 317,
                        columnNumber: 11
                    }, this),
                    showHint && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-2 p-3 bg-yellow-50 border border-yellow-200 rounded-lg",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-sm text-yellow-800",
                            children: currentQuestion.hint
                        }, void 0, false, {
                            fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                            lineNumber: 325,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                        lineNumber: 324,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                lineNumber: 316,
                columnNumber: 9
            }, this),
            showExplanation && currentQuestion.explanation && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `mb-4 p-4 rounded-lg border-l-4 ${isCorrect ? 'bg-green-50 border-green-500' : 'bg-red-50 border-red-500'}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `font-medium mb-2 ${isCorrect ? 'text-green-800' : 'text-red-800'}`,
                        children: isCorrect ? '✅ Correct!' : '❌ Incorrect'
                    }, void 0, false, {
                        fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                        lineNumber: 338,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: `text-sm ${isCorrect ? 'text-green-700' : 'text-red-700'}`,
                        children: currentQuestion.explanation
                    }, void 0, false, {
                        fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                        lineNumber: 343,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                lineNumber: 333,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-3 justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            !isAnswered && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleSubmitAnswer,
                                disabled: currentQuestion.type === 'multiple-choice' && !selectedAnswer || currentQuestion.type === 'text-input' && !textAnswer.trim(),
                                className: "px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors",
                                children: "Submit Answer"
                            }, void 0, false, {
                                fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                                lineNumber: 355,
                                columnNumber: 13
                            }, this),
                            isAnswered && !isCorrect && allowRetry && attempts < 2 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleRetryQuestion,
                                className: "px-4 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 transition-colors mr-3",
                                children: "Try Again"
                            }, void 0, false, {
                                fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                                lineNumber: 368,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                        lineNumber: 353,
                        columnNumber: 9
                    }, this),
                    isAnswered && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handleNextQuestion,
                        className: "px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors",
                        children: isLastQuestion ? 'Complete Quiz' : 'Next Question'
                    }, void 0, false, {
                        fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                        lineNumber: 378,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/quiz/QuizComponent.tsx",
                lineNumber: 352,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/quiz/QuizComponent.tsx",
        lineNumber: 245,
        columnNumber: 5
    }, this);
}
_s(QuizComponent, "pzaqOramXHU5gAD1TQuZm2Vzwjk=");
_c = QuizComponent;
var _c;
__turbopack_context__.k.register(_c, "QuizComponent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/content/ContentPanel.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>ContentPanel)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$visualizations$2f$VisualizationRenderer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/visualizations/VisualizationRenderer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$quiz$2f$QuizComponent$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/quiz/QuizComponent.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function ContentPanel({ sections, currentSection, onSectionChange }) {
    _s();
    const [isSidebarOpen, setIsSidebarOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [readingMode, setReadingMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('normal');
    const currentIndex = sections.findIndex((section)=>section.id === currentSection?.id);
    const hasNext = currentIndex < sections.length - 1;
    const hasPrevious = currentIndex > 0;
    const handleNext = ()=>{
        if (hasNext) {
            onSectionChange(sections[currentIndex + 1]);
        }
    };
    const handlePrevious = ()=>{
        if (hasPrevious) {
            onSectionChange(sections[currentIndex - 1]);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex h-full bg-gray-50",
        role: "main",
        "aria-label": "Educational content",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                id: "navigation",
                className: `
          flex-shrink-0 bg-white border-r-2 border-neutral-200 transition-all duration-300 overflow-y-auto shadow-gentle
          ${isSidebarOpen ? 'w-72 lg:w-80' : 'w-0'}
        `,
                role: "navigation",
                "aria-label": "Course sections",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-4 lg:p-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between mb-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-lg lg:text-xl font-semibold text-neutral-800",
                                    children: "Course Contents"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/content/ContentPanel.tsx",
                                    lineNumber: 53,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-sm text-neutral-600 bg-neutral-100 px-3 py-1 rounded-full",
                                    children: [
                                        currentIndex + 1,
                                        " of ",
                                        sections.length
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/content/ContentPanel.tsx",
                                    lineNumber: 56,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/content/ContentPanel.tsx",
                            lineNumber: 52,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex justify-between text-sm text-neutral-600 mb-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: "Progress"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/content/ContentPanel.tsx",
                                            lineNumber: 64,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: [
                                                Math.round((currentIndex + 1) / sections.length * 100),
                                                "%"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/content/ContentPanel.tsx",
                                            lineNumber: 65,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/content/ContentPanel.tsx",
                                    lineNumber: 63,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-full bg-neutral-200 rounded-full h-2",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "bg-gradient-to-r from-voltage-500 to-current-500 h-2 rounded-full transition-all duration-500",
                                        style: {
                                            width: `${(currentIndex + 1) / sections.length * 100}%`
                                        },
                                        role: "progressbar",
                                        "aria-valuenow": currentIndex + 1,
                                        "aria-valuemin": 0,
                                        "aria-valuemax": sections.length,
                                        "aria-label": `Course progress: ${currentIndex + 1} of ${sections.length} sections completed`
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/content/ContentPanel.tsx",
                                        lineNumber: 68,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/content/ContentPanel.tsx",
                                    lineNumber: 67,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/content/ContentPanel.tsx",
                            lineNumber: 62,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-2",
                            children: sections.map((section, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>onSectionChange(section),
                                    className: `
                  w-full px-4 py-3 rounded-lg text-left transition-all duration-200 focus-visible-ring
                  ${currentSection?.id === section.id ? 'bg-voltage-100 text-voltage-800 border-2 border-voltage-300 shadow-moderate' : 'text-neutral-700 hover:bg-neutral-100 border-2 border-transparent hover:border-neutral-200'}
                `,
                                    "aria-current": currentSection?.id === section.id ? 'page' : undefined,
                                    "aria-describedby": `section-${index}-description`,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-start space-x-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: `
                    flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold mt-0.5
                    ${currentSection?.id === section.id ? 'bg-voltage-600 text-white' : index < currentIndex ? 'bg-current-500 text-white' : 'bg-neutral-300 text-neutral-600'}
                  `,
                                                children: index < currentIndex ? '✓' : index + 1
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/content/ContentPanel.tsx",
                                                lineNumber: 96,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex-1 min-w-0",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                        className: "font-medium text-sm lg:text-base leading-tight mb-1",
                                                        children: section.title
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/content/ContentPanel.tsx",
                                                        lineNumber: 107,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        id: `section-${index}-description`,
                                                        className: "text-xs lg:text-sm text-neutral-600 line-clamp-2",
                                                        children: [
                                                            section.rawContent.substring(0, 100),
                                                            "..."
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/content/ContentPanel.tsx",
                                                        lineNumber: 110,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/content/ContentPanel.tsx",
                                                lineNumber: 106,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/content/ContentPanel.tsx",
                                        lineNumber: 95,
                                        columnNumber: 17
                                    }, this)
                                }, section.id, false, {
                                    fileName: "[project]/src/components/content/ContentPanel.tsx",
                                    lineNumber: 83,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/src/components/content/ContentPanel.tsx",
                            lineNumber: 81,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/content/ContentPanel.tsx",
                    lineNumber: 50,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/content/ContentPanel.tsx",
                lineNumber: 41,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-1 flex flex-col overflow-hidden",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-white border-b-2 border-neutral-200 px-4 lg:px-6 py-4 shadow-gentle",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>setIsSidebarOpen(!isSidebarOpen),
                                    className: "lg:hidden p-2 rounded-md text-neutral-600 hover:bg-neutral-100 focus-visible-ring",
                                    "aria-label": isSidebarOpen ? 'Close navigation' : 'Open navigation',
                                    "aria-expanded": isSidebarOpen,
                                    "aria-controls": "navigation",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-5 h-5",
                                        fill: "currentColor",
                                        viewBox: "0 0 24 24",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            d: "M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/content/ContentPanel.tsx",
                                            lineNumber: 138,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/content/ContentPanel.tsx",
                                        lineNumber: 137,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/content/ContentPanel.tsx",
                                    lineNumber: 130,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center space-x-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            htmlFor: "reading-mode",
                                            className: "text-sm font-medium text-neutral-700",
                                            children: "Reading Mode:"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/content/ContentPanel.tsx",
                                            lineNumber: 144,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                            id: "reading-mode",
                                            value: readingMode,
                                            onChange: (e)=>setReadingMode(e.target.value),
                                            className: "text-sm border-2 border-neutral-300 rounded-md px-3 py-1 bg-white focus-visible-ring",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                    value: "normal",
                                                    children: "Normal"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/content/ContentPanel.tsx",
                                                    lineNumber: 153,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                    value: "focus",
                                                    children: "Focus Mode"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/content/ContentPanel.tsx",
                                                    lineNumber: 154,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                    value: "guided",
                                                    children: "Guided Reading"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/content/ContentPanel.tsx",
                                                    lineNumber: 155,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/content/ContentPanel.tsx",
                                            lineNumber: 147,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/content/ContentPanel.tsx",
                                    lineNumber: 143,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center space-x-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: handlePrevious,
                                            disabled: !hasPrevious,
                                            className: "px-3 py-2 text-sm font-medium text-neutral-700 bg-white border-2 border-neutral-300 rounded-md hover:bg-neutral-50 disabled:opacity-50 disabled:cursor-not-allowed focus-visible-ring",
                                            "aria-label": "Go to previous section",
                                            children: "← Previous"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/content/ContentPanel.tsx",
                                            lineNumber: 161,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: handleNext,
                                            disabled: !hasNext,
                                            className: "px-3 py-2 text-sm font-medium text-white bg-voltage-600 border-2 border-voltage-600 rounded-md hover:bg-voltage-700 disabled:opacity-50 disabled:cursor-not-allowed focus-visible-ring",
                                            "aria-label": "Go to next section",
                                            children: "Next →"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/content/ContentPanel.tsx",
                                            lineNumber: 169,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/content/ContentPanel.tsx",
                                    lineNumber: 160,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/content/ContentPanel.tsx",
                            lineNumber: 128,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/content/ContentPanel.tsx",
                        lineNumber: 127,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        id: "main-content",
                        className: "flex-1 overflow-y-auto p-4 lg:p-6",
                        role: "main",
                        "aria-live": "polite",
                        "aria-label": "Section content",
                        children: currentSection ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContentRenderer, {
                            section: currentSection,
                            readingMode: readingMode
                        }, void 0, false, {
                            fileName: "[project]/src/components/content/ContentPanel.tsx",
                            lineNumber: 190,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-center h-full",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-16 h-16 bg-neutral-200 rounded-full flex items-center justify-center mx-auto mb-4",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            className: "w-8 h-8 text-neutral-400",
                                            fill: "currentColor",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                d: "M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/content/ContentPanel.tsx",
                                                lineNumber: 199,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/content/ContentPanel.tsx",
                                            lineNumber: 198,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/content/ContentPanel.tsx",
                                        lineNumber: 197,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-xl font-semibold text-neutral-800 mb-2",
                                        children: "Welcome to Basic Electricity Tutor"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/content/ContentPanel.tsx",
                                        lineNumber: 202,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-neutral-600 max-w-md",
                                        children: "Select a section from the navigation to begin your learning journey."
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/content/ContentPanel.tsx",
                                        lineNumber: 205,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/content/ContentPanel.tsx",
                                lineNumber: 196,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/content/ContentPanel.tsx",
                            lineNumber: 195,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/content/ContentPanel.tsx",
                        lineNumber: 182,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/content/ContentPanel.tsx",
                lineNumber: 125,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/content/ContentPanel.tsx",
        lineNumber: 39,
        columnNumber: 5
    }, this);
}
_s(ContentPanel, "IlqRvv/Aa2S7SBeajGtBqGPD2JU=");
_c = ContentPanel;
function ContentRenderer({ section, readingMode }) {
    const contentClass = readingMode === 'focus' ? 'focus-mode' : '';
    const guidedClass = readingMode === 'guided' ? 'reading-guide' : '';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
        className: `max-w-4xl mx-auto ${contentClass}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: "mb-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-2xl lg:text-3xl font-semibold text-neutral-800 mb-4 leading-tight",
                        children: section.title
                    }, void 0, false, {
                        fileName: "[project]/src/components/content/ContentPanel.tsx",
                        lineNumber: 225,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center space-x-4 text-sm text-neutral-600",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "flex items-center space-x-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    className: "w-4 h-4",
                                    fill: "currentColor",
                                    viewBox: "0 0 24 24",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        d: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/content/ContentPanel.tsx",
                                        lineNumber: 231,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/content/ContentPanel.tsx",
                                    lineNumber: 230,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: [
                                        "Reading Time: ~",
                                        Math.ceil(section.rawContent.length / 1000),
                                        " min"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/content/ContentPanel.tsx",
                                    lineNumber: 233,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/content/ContentPanel.tsx",
                            lineNumber: 229,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/content/ContentPanel.tsx",
                        lineNumber: 228,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/content/ContentPanel.tsx",
                lineNumber: 224,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `prose prose-lg max-w-none ${guidedClass}`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-chunk",
                    dangerouslySetInnerHTML: {
                        __html: section.contentHtml
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/content/ContentPanel.tsx",
                    lineNumber: 240,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/content/ContentPanel.tsx",
                lineNumber: 239,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-8 space-y-6",
                children: [
                    section.visualizations && section.visualizations.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "bg-white rounded-lg border-2 border-neutral-200 p-6 shadow-gentle",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-xl font-semibold text-neutral-800 mb-4",
                                children: "Interactive Visualization"
                            }, void 0, false, {
                                fileName: "[project]/src/components/content/ContentPanel.tsx",
                                lineNumber: 251,
                                columnNumber: 13
                            }, this),
                            section.visualizations.map((visualization)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$visualizations$2f$VisualizationRenderer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    visualization: visualization
                                }, visualization.id, false, {
                                    fileName: "[project]/src/components/content/ContentPanel.tsx",
                                    lineNumber: 255,
                                    columnNumber: 15
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/content/ContentPanel.tsx",
                        lineNumber: 250,
                        columnNumber: 11
                    }, this),
                    section.practiceQuestions && section.practiceQuestions.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "bg-white rounded-lg border-2 border-neutral-200 p-6 shadow-gentle",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-xl font-semibold text-neutral-800 mb-4",
                                children: "Knowledge Check"
                            }, void 0, false, {
                                fileName: "[project]/src/components/content/ContentPanel.tsx",
                                lineNumber: 266,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$quiz$2f$QuizComponent$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                questions: section.practiceQuestions
                            }, void 0, false, {
                                fileName: "[project]/src/components/content/ContentPanel.tsx",
                                lineNumber: 269,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/content/ContentPanel.tsx",
                        lineNumber: 265,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/content/ContentPanel.tsx",
                lineNumber: 247,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/content/ContentPanel.tsx",
        lineNumber: 222,
        columnNumber: 5
    }, this);
}
_c1 = ContentRenderer;
var _c, _c1;
__turbopack_context__.k.register(_c, "ContentPanel");
__turbopack_context__.k.register(_c1, "ContentRenderer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/lib/aiService.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/**
 * AI Service for the Basic Electricity Tutor
 * Handles communication with OpenAI API for the chatbot functionality
 */ __turbopack_context__.s({
    "AIService": (()=>AIService),
    "getAIService": (()=>getAIService)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
// Default system prompt that instructs the AI on its role
const DEFAULT_SYSTEM_PROMPT = `
You are an AI tutor specialized in teaching basic electricity concepts.
Your goal is to help students understand fundamental electrical principles through clear explanations,
analogies, and guided problem-solving. Be patient, encouraging, and adapt your explanations to the
student's level of understanding. 

Key teaching principles:
- Use simple analogies (water flow for current, pressure for voltage, etc.)
- Break complex concepts into digestible steps
- Encourage questions and provide positive reinforcement
- Reference visualizations and examples from the course content when helpful
- Guide students to discover answers rather than just providing them
- Use practical, real-world examples to make concepts relatable

When appropriate, refer to visualizations and examples from the course content to reinforce learning.
If a student seems confused, try a different approach or analogy.
Always maintain an encouraging and supportive tone.
`;
class AIService {
    apiKey;
    model;
    maxTokens;
    temperature;
    currentSection = null;
    conversationHistory = [];
    constructor(config = {}){
        this.apiKey = config.apiKey || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_OPENAI_API_KEY || '';
        this.model = config.model || 'gpt-4o';
        this.maxTokens = config.maxTokens || 1000;
        this.temperature = config.temperature || 0.7;
    }
    /**
   * Set the current section being viewed by the user
   * This provides context for the AI responses
   */ setCurrentSection(section) {
        this.currentSection = section;
    }
    /**
   * Get conversation history for context
   */ getConversationHistory() {
        return this.conversationHistory;
    }
    /**
   * Clear conversation history
   */ clearConversationHistory() {
        this.conversationHistory = [];
    }
    /**
   * Generate a comprehensive system prompt based on the current section
   */ generateSystemPrompt() {
        let systemPrompt = DEFAULT_SYSTEM_PROMPT;
        if (this.currentSection) {
            systemPrompt += `\n\n=== CURRENT LESSON CONTEXT ===\n`;
            systemPrompt += `Section: ${this.currentSection.title}\n`;
            // Add key concepts from the content
            const contentPreview = this.currentSection.rawContent.substring(0, 500);
            systemPrompt += `Key concepts in this section: ${contentPreview}...\n`;
            // Add information about visualizations if they exist
            if (this.currentSection.visualizations && this.currentSection.visualizations.length > 0) {
                systemPrompt += '\n=== AVAILABLE VISUALIZATIONS ===\n';
                this.currentSection.visualizations.forEach((vis)=>{
                    systemPrompt += `- ${vis.title}: ${vis.description}\n`;
                });
                systemPrompt += 'You can reference these visualizations to help explain concepts.\n';
            }
            // Add information about practice questions if they exist
            if (this.currentSection.practiceQuestions && this.currentSection.practiceQuestions.length > 0) {
                systemPrompt += '\n=== PRACTICE QUESTIONS AVAILABLE ===\n';
                systemPrompt += `There are ${this.currentSection.practiceQuestions.length} practice questions for this section.\n`;
                systemPrompt += 'You can suggest students try these questions to test their understanding.\n';
            }
            systemPrompt += '\n=== TEACHING GUIDELINES ===\n';
            systemPrompt += '- Always relate explanations back to the current section content\n';
            systemPrompt += '- Use the visualizations to enhance understanding\n';
            systemPrompt += '- Encourage hands-on learning with practice questions\n';
            systemPrompt += '- If students ask about topics not in the current section, gently guide them back or suggest they explore other sections\n';
        }
        return systemPrompt;
    }
    /**
   * Send a message to the AI and get a response with enhanced error handling
   */ async sendMessage(messages) {
        // Check if API key is available
        if (!this.apiKey) {
            console.error('OpenAI API key is not configured');
            return {
                role: 'assistant',
                content: 'I apologize, but the AI tutoring service is not properly configured. Please check that your OpenAI API key is set up correctly in your environment variables.'
            };
        }
        try {
            // Update conversation history
            const newUserMessage = messages[messages.length - 1];
            if (newUserMessage) {
                this.conversationHistory.push(newUserMessage);
            }
            // Prepare the messages array with system prompt and recent history
            const systemPrompt = this.generateSystemPrompt();
            const recentHistory = this.conversationHistory.slice(-6); // Keep last 6 messages for context
            const apiMessages = [
                {
                    role: 'system',
                    content: systemPrompt
                },
                ...recentHistory.map((msg)=>({
                        role: msg.role,
                        content: msg.content
                    }))
            ];
            // Call the OpenAI API
            const response = await fetch('https://api.openai.com/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.apiKey}`
                },
                body: JSON.stringify({
                    model: this.model,
                    messages: apiMessages,
                    max_tokens: this.maxTokens,
                    temperature: this.temperature,
                    presence_penalty: 0.1,
                    frequency_penalty: 0.1
                })
            });
            if (!response.ok) {
                const errorData = await response.json().catch(()=>({}));
                console.error('OpenAI API error:', response.status, errorData);
                if (response.status === 401) {
                    return {
                        role: 'assistant',
                        content: 'I apologize, but there seems to be an authentication issue with the AI service. Please check your API key configuration.'
                    };
                } else if (response.status === 429) {
                    return {
                        role: 'assistant',
                        content: 'I apologize, but the AI service is currently experiencing high demand. Please try again in a moment.'
                    };
                } else {
                    return {
                        role: 'assistant',
                        content: 'I apologize, but I encountered an error while processing your request. Please try again.'
                    };
                }
            }
            const data = await response.json();
            const assistantMessage = {
                role: 'assistant',
                content: data.choices[0]?.message?.content || 'I apologize, but I was unable to generate a response. Please try again.'
            };
            // Add assistant response to history
            this.conversationHistory.push(assistantMessage);
            return assistantMessage;
        } catch (error) {
            console.error('Error calling OpenAI API:', error);
            return {
                role: 'assistant',
                content: 'I apologize, but I encountered a technical error. Please check your internet connection and try again.'
            };
        }
    }
    /**
   * Generate a helpful suggestion based on the current section
   */ generateSectionSuggestion() {
        if (!this.currentSection) {
            return "Feel free to ask me any questions about electricity! I'm here to help you learn.";
        }
        const suggestions = [
            `Let's explore ${this.currentSection.title}. What would you like to understand better?`,
            `I can help explain the concepts in "${this.currentSection.title}". What questions do you have?`,
            `Ready to dive into ${this.currentSection.title}? Ask me anything about this topic!`
        ];
        if (this.currentSection.visualizations && this.currentSection.visualizations.length > 0) {
            suggestions.push(`Check out the interactive visualizations for ${this.currentSection.title} - they really help illustrate these concepts!`);
        }
        if (this.currentSection.practiceQuestions && this.currentSection.practiceQuestions.length > 0) {
            suggestions.push(`Once you understand ${this.currentSection.title}, try the practice questions to test your knowledge!`);
        }
        return suggestions[Math.floor(Math.random() * suggestions.length)];
    }
    /**
   * Generate helpful suggestions based on the current section
   */ async getSuggestions(section) {
        // Check if API key is available
        if (!this.apiKey || this.apiKey === 'your-openai-api-key-here') {
            console.warn('OpenAI API key not configured, using default suggestions');
            return this.getDefaultSuggestions(section);
        }
        try {
            const prompt = `Based on the following electrical concepts section, generate 4 helpful questions that a student might want to ask to better understand the topic. Make them specific, educational, and engaging.

Section: ${section.title}
Content preview: ${section.rawContent.substring(0, 500)}...

Available visualizations: ${section.visualizations?.map((v)=>v.title).join(', ') || 'None'}
Available practice questions: ${section.practiceQuestions?.length || 0} questions

Generate exactly 4 questions that would help students:
1. Understand the core concept better
2. See real-world applications
3. Connect to related topics
4. Practice or test their knowledge

Format as a simple list, one question per line.`;
            const response = await fetch('https://api.openai.com/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.apiKey}`
                },
                body: JSON.stringify({
                    model: 'gpt-3.5-turbo',
                    messages: [
                        {
                            role: 'system',
                            content: 'You are an educational AI that generates helpful study questions. Be concise and educational.'
                        },
                        {
                            role: 'user',
                            content: prompt
                        }
                    ],
                    max_tokens: 300,
                    temperature: 0.7
                })
            });
            if (!response.ok) {
                if (response.status === 401) {
                    console.warn('OpenAI API authentication failed. Please check your API key.');
                    return this.getDefaultSuggestions(section);
                }
                throw new Error(`API request failed with status ${response.status}`);
            }
            const data = await response.json();
            const content = data.choices?.[0]?.message?.content;
            if (!content) {
                console.warn('No content received from OpenAI API');
                return this.getDefaultSuggestions(section);
            }
            // Parse the response into individual questions
            const suggestions = content.split('\n').map((line)=>line.replace(/^\d+\.\s*/, '').trim()).filter((line)=>line.length > 0 && line.length < 100).slice(0, 4);
            return suggestions.length > 0 ? suggestions : this.getDefaultSuggestions(section);
        } catch (error) {
            console.error('Error generating suggestions:', error);
            return this.getDefaultSuggestions(section);
        }
    }
    /**
   * Get default suggestions when AI generation fails
   */ getDefaultSuggestions(section) {
        const suggestions = [
            `Tell me more about ${section.title}`,
            'Can you explain this concept differently?',
            'What are some real-world applications?',
            'How does this relate to other electrical concepts?'
        ];
        // Add visualization-specific suggestions if available
        if (section.visualizations && section.visualizations.length > 0) {
            suggestions[1] = `Explain the ${section.visualizations[0].title} visualization`;
        }
        // Add practice question suggestion if available
        if (section.practiceQuestions && section.practiceQuestions.length > 0) {
            suggestions[3] = 'Can you help me with the practice questions?';
        }
        return suggestions;
    }
}
// Create a singleton instance for use throughout the app
let aiServiceInstance = null;
function getAIService(config) {
    if (!aiServiceInstance) {
        aiServiceInstance = new AIService(config);
    }
    return aiServiceInstance;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/ai/ChatPanel.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>ChatPanel)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$aiService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/aiService.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function ChatPanel({ currentSection }) {
    _s();
    const [messages, setMessages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([
        {
            role: 'assistant',
            content: 'Hello! I\'m your Basic Electricity tutor. I can help you understand electrical concepts, explain visualizations, and guide you through practice questions. What would you like to learn about?'
        }
    ]);
    const [inputValue, setInputValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [suggestions, setSuggestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [showSuggestions, setShowSuggestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const messagesEndRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Scroll to bottom of chat when messages change
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatPanel.useEffect": ()=>{
            messagesEndRef.current?.scrollIntoView({
                behavior: 'smooth'
            });
        }
    }["ChatPanel.useEffect"], [
        messages
    ]);
    // Update AI service and get suggestions when section changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatPanel.useEffect": ()=>{
            const aiService = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$aiService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAIService"])();
            aiService.setCurrentSection(currentSection || null);
            // Get AI suggestions for the current section
            if (currentSection) {
                loadSuggestions();
            } else {
                setSuggestions([
                    "What is electric current?",
                    "How does voltage work?",
                    "Explain Ohm's law",
                    "What are the different types of circuits?"
                ]);
            }
        }
    }["ChatPanel.useEffect"], [
        currentSection
    ]);
    /**
   * Load AI-generated suggestions for the current section
   */ const loadSuggestions = async ()=>{
        if (!currentSection) return;
        try {
            const aiService = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$aiService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAIService"])();
            const sectionSuggestions = await aiService.getSuggestions(currentSection);
            setSuggestions(sectionSuggestions);
        } catch (error) {
            console.error('Error loading suggestions:', error);
            // Fallback suggestions
            setSuggestions([
                `Tell me more about ${currentSection.title}`,
                "Can you explain this concept differently?",
                "What are some real-world applications?",
                "How does this relate to other electrical concepts?"
            ]);
        }
    };
    /**
   * Handles sending a new message to the AI assistant
   */ const handleSendMessage = async (messageContent)=>{
        const content = messageContent || inputValue;
        if (!content.trim()) return;
        const userMessage = {
            role: 'user',
            content: content,
            timestamp: new Date()
        };
        setMessages((prev)=>[
                ...prev,
                userMessage
            ]);
        setInputValue('');
        setIsLoading(true);
        setShowSuggestions(false);
        try {
            // Get AI service and send the message
            const aiService = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$aiService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAIService"])();
            const currentMessages = [
                ...messages,
                userMessage
            ];
            const response = await aiService.sendMessage(currentMessages);
            // Add timestamp to the response
            response.timestamp = new Date();
            setMessages((prev)=>[
                    ...prev,
                    response
                ]);
        } catch (error) {
            console.error('Error fetching AI response:', error);
            setMessages((prev)=>[
                    ...prev,
                    {
                        role: 'assistant',
                        content: 'I apologize, but I encountered an error while processing your request. Please try again or check your API configuration.',
                        timestamp: new Date()
                    }
                ]);
        } finally{
            setIsLoading(false);
        }
    };
    /**
   * Handle form submission
   */ const handleSubmit = (e)=>{
        e.preventDefault();
        handleSendMessage();
    };
    /**
   * Handle suggestion click
   */ const handleSuggestionClick = (suggestion)=>{
        handleSendMessage(suggestion);
    };
    /**
   * Clear chat history
   */ const handleClearChat = ()=>{
        setMessages([
            {
                role: 'assistant',
                content: 'Chat cleared! How can I help you with electrical concepts?'
            }
        ]);
        setShowSuggestions(true);
    };
    /**
   * Format message content with basic markdown support
   */ const formatMessageContent = (content)=>{
        // Simple markdown formatting
        return content.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\*(.*?)\*/g, '<em>$1</em>').replace(/`(.*?)`/g, '<code class="bg-gray-200 px-1 rounded">$1</code>').replace(/\n/g, '<br />');
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col h-full bg-white",
        role: "region",
        "aria-label": "Chat with AI Electricity Tutor",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-4 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-indigo-50",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex justify-between items-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-xl font-semibold text-gray-800 flex items-center",
                                    id: "chat-title",
                                    children: "🤖 AI Electricity Tutor"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ai/ChatPanel.tsx",
                                    lineNumber: 165,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-gray-600 mt-1",
                                    id: "chat-context",
                                    children: currentSection ? `Currently discussing: ${currentSection.title}` : 'Ask me anything about electricity'
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ai/ChatPanel.tsx",
                                    lineNumber: 168,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/ai/ChatPanel.tsx",
                            lineNumber: 164,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: handleClearChat,
                            className: "text-sm text-gray-500 hover:text-gray-700 px-3 py-1 rounded-lg hover:bg-white/50 transition-colors",
                            title: "Clear chat history",
                            children: "🗑️ Clear"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ai/ChatPanel.tsx",
                            lineNumber: 174,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ai/ChatPanel.tsx",
                    lineNumber: 163,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/ai/ChatPanel.tsx",
                lineNumber: 162,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50",
                role: "log",
                "aria-live": "polite",
                "aria-label": "Chat messages",
                "aria-labelledby": "chat-title",
                children: [
                    messages.map((message, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: `flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`,
                            role: "article",
                            "aria-label": `${message.role} message`,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `max-w-[85%] rounded-2xl p-4 shadow-sm ${message.role === 'user' ? 'bg-blue-600 text-white ml-4' : 'bg-white text-gray-800 mr-4 border border-gray-200'}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: `${message.role === 'assistant' ? 'prose prose-sm max-w-none' : ''}`,
                                        dangerouslySetInnerHTML: {
                                            __html: formatMessageContent(message.content)
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ai/ChatPanel.tsx",
                                        lineNumber: 205,
                                        columnNumber: 15
                                    }, this),
                                    message.timestamp && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: `text-xs mt-2 ${message.role === 'user' ? 'text-blue-100' : 'text-gray-400'}`,
                                        children: message.timestamp.toLocaleTimeString()
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ai/ChatPanel.tsx",
                                        lineNumber: 212,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ai/ChatPanel.tsx",
                                lineNumber: 199,
                                columnNumber: 13
                            }, this)
                        }, index, false, {
                            fileName: "[project]/src/components/ai/ChatPanel.tsx",
                            lineNumber: 193,
                            columnNumber: 11
                        }, this)),
                    isLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-start",
                        "aria-live": "polite",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "max-w-[85%] rounded-2xl p-4 bg-white mr-4 border border-gray-200 shadow-sm",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex space-x-2 items-center",
                                "aria-label": "Assistant is typing",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-2 h-2 rounded-full bg-blue-400 animate-bounce"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ai/ChatPanel.tsx",
                                        lineNumber: 229,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-2 h-2 rounded-full bg-blue-400 animate-bounce delay-100"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ai/ChatPanel.tsx",
                                        lineNumber: 230,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-2 h-2 rounded-full bg-blue-400 animate-bounce delay-200"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ai/ChatPanel.tsx",
                                        lineNumber: 231,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-sm text-gray-500 ml-2",
                                        children: "Thinking..."
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ai/ChatPanel.tsx",
                                        lineNumber: 232,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ai/ChatPanel.tsx",
                                lineNumber: 225,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/ai/ChatPanel.tsx",
                            lineNumber: 224,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ai/ChatPanel.tsx",
                        lineNumber: 223,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: messagesEndRef
                    }, void 0, false, {
                        fileName: "[project]/src/components/ai/ChatPanel.tsx",
                        lineNumber: 238,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ai/ChatPanel.tsx",
                lineNumber: 185,
                columnNumber: 7
            }, this),
            showSuggestions && suggestions.length > 0 && messages.length <= 2 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "px-4 py-2 border-t border-gray-200 bg-white",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-sm text-gray-600 mb-2",
                        children: "💡 Suggested questions:"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ai/ChatPanel.tsx",
                        lineNumber: 244,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-wrap gap-2",
                        children: suggestions.slice(0, 3).map((suggestion, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>handleSuggestionClick(suggestion),
                                className: "text-sm px-3 py-2 bg-blue-50 text-blue-700 rounded-full hover:bg-blue-100 transition-colors border border-blue-200",
                                disabled: isLoading,
                                children: suggestion
                            }, index, false, {
                                fileName: "[project]/src/components/ai/ChatPanel.tsx",
                                lineNumber: 247,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/src/components/ai/ChatPanel.tsx",
                        lineNumber: 245,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ai/ChatPanel.tsx",
                lineNumber: 243,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                onSubmit: handleSubmit,
                className: "p-4 border-t border-gray-200 bg-white",
                "aria-label": "Chat message form",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-end space-x-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    ref: inputRef,
                                    type: "text",
                                    value: inputValue,
                                    onChange: (e)=>setInputValue(e.target.value),
                                    placeholder: "Ask about electrical concepts, visualizations, or practice questions...",
                                    className: "w-full border border-gray-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none",
                                    "aria-label": "Type your message",
                                    disabled: isLoading
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ai/ChatPanel.tsx",
                                    lineNumber: 268,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/ai/ChatPanel.tsx",
                                lineNumber: 267,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "submit",
                                disabled: isLoading || !inputValue.trim(),
                                className: "bg-blue-600 text-white px-6 py-3 rounded-xl hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center space-x-2",
                                "aria-label": "Send message",
                                children: isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ai/ChatPanel.tsx",
                                    lineNumber: 286,
                                    columnNumber: 15
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: "Send"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ai/ChatPanel.tsx",
                                    lineNumber: 288,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/ai/ChatPanel.tsx",
                                lineNumber: 279,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ai/ChatPanel.tsx",
                        lineNumber: 266,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex space-x-2 mt-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>handleSuggestionClick("Explain this section in simple terms"),
                                className: "text-xs px-3 py-1 bg-gray-100 text-gray-600 rounded-full hover:bg-gray-200 transition-colors",
                                disabled: isLoading || !currentSection,
                                children: "📝 Simplify"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ai/ChatPanel.tsx",
                                lineNumber: 295,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>handleSuggestionClick("Show me a real-world example"),
                                className: "text-xs px-3 py-1 bg-gray-100 text-gray-600 rounded-full hover:bg-gray-200 transition-colors",
                                disabled: isLoading,
                                children: "🌍 Examples"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ai/ChatPanel.tsx",
                                lineNumber: 303,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>handleSuggestionClick("What should I study next?"),
                                className: "text-xs px-3 py-1 bg-gray-100 text-gray-600 rounded-full hover:bg-gray-200 transition-colors",
                                disabled: isLoading,
                                children: "📚 Study Guide"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ai/ChatPanel.tsx",
                                lineNumber: 311,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ai/ChatPanel.tsx",
                        lineNumber: 294,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ai/ChatPanel.tsx",
                lineNumber: 261,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ai/ChatPanel.tsx",
        lineNumber: 160,
        columnNumber: 5
    }, this);
}
_s(ChatPanel, "kpAVwjCr87CItQq4Ouy5SbwH8lo=");
_c = ChatPanel;
var _c;
__turbopack_context__.k.register(_c, "ChatPanel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/lib/contentParser.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "parseContentFile": (()=>parseContentFile)
});
async function parseContentFile() {
    try {
        console.log('Client-side: Fetching content from API');
        // Fetch content from the API route instead of directly using fs
        const response = await fetch('/api/content', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            },
            // Use cache: 'no-store' to ensure we always get fresh content
            cache: 'no-store'
        });
        if (!response.ok) {
            throw new Error(`Failed to fetch content: ${response.status}`);
        }
        const data = await response.json();
        console.log('Client-side: Received data from API:', data);
        console.log('Client-side: Number of sections:', data.sections ? data.sections.length : 0);
        if (data.sections && data.sections.length > 0) {
            console.log('Client-side: First section title:', data.sections[0].title);
            console.log('Client-side: First section has content HTML:', !!data.sections[0].contentHtml);
        }
        return data.sections || [];
    } catch (error) {
        console.error('Error fetching content:', error);
        return [];
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Home)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$SplitScreenLayout$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/layout/SplitScreenLayout.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$content$2f$ContentPanel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/content/ContentPanel.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ai$2f$ChatPanel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ai/ChatPanel.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$contentParser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/contentParser.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$aiService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/aiService.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function Home() {
    _s();
    const [sections, setSections] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [currentSection, setCurrentSection] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Initialize AIService
    const aiService = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$aiService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAIService"])({
        temperature: 0.7
    });
    // Load content on component mount - client-side only
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Home.useEffect": ()=>{
            async function loadContent() {
                try {
                    setError(null);
                    const loadedSections = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$contentParser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseContentFile"])();
                    setSections(loadedSections);
                    // Set initial section to the first one
                    if (loadedSections.length > 0) {
                        setCurrentSection(loadedSections[0]);
                    } else {
                        setError('No content sections found. Please check the content file.');
                    }
                } catch (error) {
                    console.error('Error loading content:', error);
                    setError('Failed to load educational content. Please refresh the page.');
                } finally{
                    setIsLoading(false);
                }
            }
            // Only run in the browser to avoid hydration mismatch
            if ("TURBOPACK compile-time truthy", 1) {
                loadContent();
            }
        }
    }["Home.useEffect"], []);
    // Update AI service with current section when it changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Home.useEffect": ()=>{
            aiService.setCurrentSection(currentSection);
        }
    }["Home.useEffect"], [
        currentSection,
        aiService
    ]);
    // Handle section changes
    const handleSectionChange = (section)=>{
        setCurrentSection(section);
        setIsMobileMenuOpen(false); // Close mobile menu when section changes
    };
    // Handle retry loading
    const handleRetryLoad = ()=>{
        setIsLoading(true);
        setError(null);
        // Trigger reload by calling the effect again
        window.location.reload();
    };
    // Loading state
    if (isLoading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center p-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative mb-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-16 h-16 border-4 border-blue-200 rounded-full animate-spin border-t-blue-600 mx-auto"
                            }, void 0, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 76,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute inset-0 w-16 h-16 border-4 border-transparent rounded-full animate-pulse border-t-blue-400 mx-auto"
                            }, void 0, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 77,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 75,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-xl font-semibold text-gray-800 mb-2",
                        children: "Loading Basic Electricity Tutor"
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 79,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-600",
                        children: "Preparing your interactive learning experience..."
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 80,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-4 flex justify-center space-x-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-2 h-2 bg-blue-400 rounded-full animate-bounce"
                            }, void 0, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 82,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-2 h-2 bg-blue-400 rounded-full animate-bounce delay-100"
                            }, void 0, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 83,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-2 h-2 bg-blue-400 rounded-full animate-bounce delay-200"
                            }, void 0, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 84,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 81,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 74,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/page.tsx",
            lineNumber: 73,
            columnNumber: 7
        }, this);
    }
    // Error state
    if (error) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "h-screen bg-gradient-to-br from-red-50 to-pink-100 flex items-center justify-center",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center p-8 max-w-md",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-6xl mb-4",
                        children: "⚡"
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 96,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-2xl font-bold text-gray-800 mb-4",
                        children: "Oops! Something went wrong"
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 97,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-600 mb-6",
                        children: error
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 98,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handleRetryLoad,
                        className: "px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium",
                        children: "Try Again"
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 99,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 95,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/page.tsx",
            lineNumber: 94,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "h-screen overflow-hidden flex flex-col bg-gray-50",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: "bg-white border-b border-gray-200 shadow-sm z-10",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "px-4 sm:px-6 lg:px-8",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex justify-between items-center h-16",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center space-x-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-8 h-8 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-white font-bold text-sm",
                                                children: "⚡"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/page.tsx",
                                                lineNumber: 119,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/page.tsx",
                                            lineNumber: 118,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                                    className: "text-xl font-bold text-gray-900",
                                                    children: "Basic Electricity Tutor"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/page.tsx",
                                                    lineNumber: 122,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-gray-500 hidden sm:block",
                                                    children: "Interactive Learning Experience"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/page.tsx",
                                                    lineNumber: 123,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/page.tsx",
                                            lineNumber: 121,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/page.tsx",
                                    lineNumber: 117,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "hidden md:flex items-center space-x-4",
                                    children: currentSection && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-right",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-sm font-medium text-gray-900",
                                                children: currentSection.title
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/page.tsx",
                                                lineNumber: 131,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-xs text-gray-500",
                                                children: [
                                                    "Section ",
                                                    sections.findIndex((s)=>s.id === currentSection.id) + 1,
                                                    " of ",
                                                    sections.length
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/page.tsx",
                                                lineNumber: 132,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/page.tsx",
                                        lineNumber: 130,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/page.tsx",
                                    lineNumber: 128,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>setIsMobileMenuOpen(!isMobileMenuOpen),
                                    className: "md:hidden p-2 rounded-lg text-gray-600 hover:text-gray-900 hover:bg-gray-100",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-6 h-6",
                                        fill: "none",
                                        stroke: "currentColor",
                                        viewBox: "0 0 24 24",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M4 6h16M4 12h16M4 18h16"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/page.tsx",
                                            lineNumber: 145,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/page.tsx",
                                        lineNumber: 144,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/page.tsx",
                                    lineNumber: 140,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 115,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 114,
                        columnNumber: 9
                    }, this),
                    isMobileMenuOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "md:hidden border-t border-gray-200 bg-white",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "px-4 py-3",
                            children: [
                                currentSection && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mb-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-sm font-medium text-gray-900",
                                            children: currentSection.title
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/page.tsx",
                                            lineNumber: 157,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-xs text-gray-500",
                                            children: [
                                                "Section ",
                                                sections.findIndex((s)=>s.id === currentSection.id) + 1,
                                                " of ",
                                                sections.length
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/page.tsx",
                                            lineNumber: 158,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/page.tsx",
                                    lineNumber: 156,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-xs text-gray-500",
                                    children: "Swipe or use navigation to explore different sections"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/page.tsx",
                                    lineNumber: 163,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 154,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 153,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 113,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                className: "flex-1 overflow-hidden",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$SplitScreenLayout$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    contentPanel: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$content$2f$ContentPanel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        sections: sections,
                        currentSection: currentSection,
                        onSectionChange: handleSectionChange
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 175,
                        columnNumber: 13
                    }, void 0),
                    aiChatPanel: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ai$2f$ChatPanel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        currentSection: currentSection
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 182,
                        columnNumber: 13
                    }, void 0)
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 173,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 172,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
                className: "md:hidden bg-white border-t border-gray-200 px-4 py-2",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex justify-between items-center text-xs text-gray-500",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: " 2024 Basic Electricity Tutor"
                        }, void 0, false, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 192,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: [
                                sections.length,
                                " sections available"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 193,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 191,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 190,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/page.tsx",
        lineNumber: 111,
        columnNumber: 5
    }, this);
}
_s(Home, "L9Dj2Cxk2edHkqviX5e7Rop0zhs=");
_c = Home;
var _c;
__turbopack_context__.k.register(_c, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_13ebe45a._.js.map