module.exports = {

"[project]/.next-internal/server/app/api/content/route/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/fs [external] (fs, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}}),
"[externals]/path [external] (path, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}}),
"[externals]/buffer [external] (buffer, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}}),
"[externals]/tty [external] (tty, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("tty", () => require("tty"));

module.exports = mod;
}}),
"[externals]/util [external] (util, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}}),
"[externals]/os [external] (os, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}}),
"[externals]/node:path [external] (node:path, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:path", () => require("node:path"));

module.exports = mod;
}}),
"[externals]/node:path [external] (node:path, cjs) <export default as minpath>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "minpath": (()=>__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"])
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
}}),
"[externals]/node:process [external] (node:process, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:process", () => require("node:process"));

module.exports = mod;
}}),
"[externals]/node:process [external] (node:process, cjs) <export default as minproc>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "minproc": (()=>__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$process__$5b$external$5d$__$28$node$3a$process$2c$__cjs$29$__["default"])
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$process__$5b$external$5d$__$28$node$3a$process$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:process [external] (node:process, cjs)");
}}),
"[externals]/node:url [external] (node:url, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:url", () => require("node:url"));

module.exports = mod;
}}),
"[externals]/node:url [external] (node:url, cjs) <export fileURLToPath as urlToPath>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "urlToPath": (()=>__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$url__$5b$external$5d$__$28$node$3a$url$2c$__cjs$29$__["fileURLToPath"])
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$url__$5b$external$5d$__$28$node$3a$url$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:url [external] (node:url, cjs)");
}}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/src/app/api/content/route.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "GET": (()=>GET)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$gray$2d$matter$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/gray-matter/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$remark$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/remark/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$remark$2d$html$2f$lib$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/remark-html/lib/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
;
;
;
;
;
;
// Use absolute path to content directory within the Next.js project
const contentDirectory = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), 'content');
console.log('Content directory path:', contentDirectory);
/**
 * Extract visualization instructions from content using Visual Aid markers
 */ function extractVisualizations(content) {
    const visualAidRegex = /> \*\*Visual Aid Instruction:\*\* (.+?)(?=\n\n|$)/g;
    const visualizations = [];
    let match;
    let visualId = 0;
    while((match = visualAidRegex.exec(content)) !== null){
        visualId++;
        const description = match[1].trim();
        // Determine visualization type and configuration based on keywords in description
        let type = 'animation'; // Default
        let configData = {};
        if (description.toLowerCase().includes('circuit')) {
            type = 'circuit';
            configData = {
                elements: extractCircuitElements(description),
                animate: true,
                showCurrentFlow: true,
                width: 600,
                height: 400
            };
        } else if (description.toLowerCase().includes('3d model') || description.toLowerCase().includes('three.js')) {
            type = '3d';
            configData = {
                interactive: true,
                animate: true,
                width: 500,
                height: 400
            };
        } else if (description.toLowerCase().includes('graph') || description.toLowerCase().includes('chart')) {
            type = 'graph';
            configData = {
                interactive: true,
                showAxes: true,
                width: 500,
                height: 300
            };
        } else if (description.toLowerCase().includes('atom') || description.toLowerCase().includes('electron')) {
            type = 'atomic';
            configData = extractAtomicConfig(description);
        } else if (description.toLowerCase().includes('oscillator') || description.toLowerCase().includes('waveform')) {
            type = 'waveform';
            configData = {
                interactive: true,
                animate: true,
                showControls: true,
                width: 600,
                height: 300
            };
        } else if (description.toLowerCase().includes('power') && description.toLowerCase().includes('triangle')) {
            type = 'power-triangle';
            configData = {
                interactive: true,
                showVectors: true,
                width: 400,
                height: 400
            };
        }
        visualizations.push({
            id: `viz-${visualId}`,
            type,
            title: extractVisualizationTitle(description),
            description,
            configData
        });
    }
    return visualizations;
}
/**
 * Extract atomic model configuration from description
 */ function extractAtomicConfig(description) {
    const config = {
        interactive: true,
        animate: true,
        width: 400,
        height: 400
    };
    // Extract element type
    if (description.toLowerCase().includes('copper')) {
        config.element = 'Copper';
        config.protons = 29;
        config.neutrons = 34;
        config.electrons = 29;
        config.shells = [
            2,
            8,
            18,
            1
        ];
    } else if (description.toLowerCase().includes('silicon')) {
        config.element = 'Silicon';
        config.protons = 14;
        config.neutrons = 14;
        config.electrons = 14;
        config.shells = [
            2,
            8,
            4
        ];
    } else if (description.toLowerCase().includes('rubber') || description.toLowerCase().includes('insulator')) {
        config.element = 'Carbon';
        config.protons = 6;
        config.neutrons = 6;
        config.electrons = 6;
        config.shells = [
            2,
            4
        ];
    } else {
        // Generic atom
        config.element = 'Generic';
        config.protons = 4;
        config.neutrons = 5;
        config.electrons = 4;
        config.shells = [
            2,
            2
        ];
    }
    return config;
}
/**
 * Extract circuit elements from description
 */ function extractCircuitElements(description) {
    const elements = [];
    if (description.toLowerCase().includes('resistor')) {
        elements.push({
            type: 'resistor',
            value: '100Ω',
            position: {
                x: 100,
                y: 100
            }
        });
    }
    if (description.toLowerCase().includes('battery') || description.toLowerCase().includes('voltage')) {
        elements.push({
            type: 'battery',
            value: '12V',
            position: {
                x: 50,
                y: 100
            }
        });
    }
    if (description.toLowerCase().includes('capacitor')) {
        elements.push({
            type: 'capacitor',
            value: '10μF',
            position: {
                x: 150,
                y: 100
            }
        });
    }
    if (description.toLowerCase().includes('inductor')) {
        elements.push({
            type: 'inductor',
            value: '1mH',
            position: {
                x: 200,
                y: 100
            }
        });
    }
    return elements;
}
/**
 * Extract a meaningful title from the visualization description
 */ function extractVisualizationTitle(description) {
    if (description.toLowerCase().includes('atom')) {
        return 'Atomic Structure Model';
    } else if (description.toLowerCase().includes('circuit')) {
        return 'Interactive Circuit Diagram';
    } else if (description.toLowerCase().includes('oscillator')) {
        return 'Oscillator Waveforms';
    } else if (description.toLowerCase().includes('power triangle')) {
        return 'AC Power Triangle';
    } else if (description.toLowerCase().includes('current flow')) {
        return 'Current Flow Animation';
    } else {
        return 'Interactive Visualization';
    }
}
/**
 * Extract practice questions from content sections
 */ function extractPracticeQuestions(content) {
    const questionsRegex = /\*\*Practice Questions\*\*:([\s\S]+?)(?=##|\*\*|$)/g;
    const individualQuestionRegex = /(\d+)\.\s+([\s\S]+?)(?=\d+\.\s+|$)/g;
    const questions = [];
    // Find the practice questions section
    const questionsMatch = questionsRegex.exec(content);
    if (!questionsMatch) return [];
    const questionsContent = questionsMatch[1];
    // Extract individual questions
    let questionMatch;
    while((questionMatch = individualQuestionRegex.exec(questionsContent)) !== null){
        const questionNumber = questionMatch[1];
        const questionText = questionMatch[2].trim();
        questions.push({
            id: `q-${questionNumber}`,
            question: questionText,
            type: 'multiple-choice',
            options: [
                'Option A',
                'Option B',
                'Option C',
                'Option D'
            ],
            correctAnswer: 'Option A',
            explanation: 'Explanation will be provided by the instructor.',
            difficulty: 'basic' // Default difficulty
        });
    }
    return questions;
}
/**
 * Parse the main content file and extract section information
 * Converts markdown content into structured sections with HTML
 */ async function parseContentFile() {
    // Use the direct path to the content file
    const filePath = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), 'content', 'Basic_Electricity_Tutor_Content.md');
    console.log('Using file path:', filePath);
    const fileContents = __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].readFileSync(filePath, 'utf8');
    // Use gray-matter to parse the metadata section
    const { content } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$gray$2d$matter$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])(fileContents);
    // Split content by H2 headers and process each section
    const sections = [];
    // Split the content by H2 headers (## Section)
    const sectionParts = content.split(/^## /gm);
    // Remove the first empty part (content before first H2)
    sectionParts.shift();
    for(let i = 0; i < sectionParts.length; i++){
        const sectionId = i + 1;
        const part = sectionParts[i];
        // Extract title (first line) and content (rest)
        const lines = part.split('\n');
        const title = lines[0].trim();
        const sectionContent = lines.slice(1).join('\n').trim();
        // Process markdown to HTML
        const processedContent = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$remark$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["remark"])().use(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$remark$2d$html$2f$lib$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"]).process(sectionContent);
        const contentHtml = processedContent.toString();
        // Debug log the content HTML length
        console.log(`Section "${title}" HTML length: ${contentHtml.length}`);
        // Log a sample of the HTML to check format
        if (contentHtml.length > 0) {
            console.log(`HTML sample: ${contentHtml.substring(0, 100)}...`);
        } else {
            console.error(`No HTML content generated for section "${title}"`);
            console.log(`Raw content length: ${sectionContent.length}`);
            console.log(`Raw content sample: ${sectionContent.substring(0, 200)}...`);
        }
        // Extract subsections (H3 headers)
        const subsectionRegex = /^### (.+?)$([\s\S]*?)(?=^### |\s*$)/gm;
        const subsections = [];
        let subsectionMatch;
        let subsectionId = 0;
        while((subsectionMatch = subsectionRegex.exec(sectionContent)) !== null){
            subsectionId++;
            const subsectionTitle = subsectionMatch[1].trim();
            const subsectionContent = subsectionMatch[2].trim();
            // Process markdown to HTML for subsection
            const processedSubContent = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$remark$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["remark"])().use(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$remark$2d$html$2f$lib$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"]).process(subsectionContent);
            const subContentHtml = processedSubContent.toString();
            // Extract visualizations if they exist using the Visual Aid Instruction comments
            const visualizations = extractVisualizations(subsectionContent);
            // Extract practice questions if they exist
            const practiceQuestions = extractPracticeQuestions(subsectionContent);
            subsections.push({
                id: `${sectionId}.${subsectionId}`,
                title: subsectionTitle,
                contentHtml: subContentHtml,
                rawContent: subsectionContent,
                visualizations,
                practiceQuestions
            });
        }
        // Add section with its subsections
        sections.push({
            id: String(sectionId),
            title,
            contentHtml,
            rawContent: sectionContent,
            subsections: subsections.length > 0 ? subsections : undefined
        });
    }
    return sections;
}
async function GET() {
    try {
        console.log('API route GET handler called');
        const filePath = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(contentDirectory, 'Basic_Electricity_Tutor_Content.md');
        console.log('Checking if file exists:', filePath);
        // Check if file exists
        if (!__TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].existsSync(filePath)) {
            console.error('Content file does not exist:', filePath);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'Content file not found'
            }, {
                status: 404
            });
        }
        console.log('Content file exists, parsing...');
        const sections = await parseContentFile();
        console.log(`Parsed ${sections.length} sections`);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            sections
        });
    } catch (error) {
        console.error('Error parsing content:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: 'Failed to parse content',
            details: error instanceof Error ? error.message : String(error)
        }, {
            status: 500
        });
    }
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__97857c2c._.js.map