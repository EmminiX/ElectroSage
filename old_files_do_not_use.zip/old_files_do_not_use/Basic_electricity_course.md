Introduction to Basic Electricity
Electricity powers our modern world, from household appliances to advanced technologies. Understanding its basic principles is essential for safety, efficiency, and innovation. This document provides an accessible introduction to electricity, covering atomic structure, electrical units, voltage production, circuit components, and measurement techniques.
What is Electricity?
Electricity is the movement of electric charge, primarily carried by electrons through conductors. To grasp this concept, we start with the atom—the fundamental unit of matter.
Why Study Basic Theories?

Safety: Prevents electrical hazards.
Efficiency: Improves system design and troubleshooting.
Foundation: Enables advanced learning and technological development.


Atomic Structure
Electricity begins at the atomic level. This section explores the atom and its role in electrical phenomena.
Structure of the Atom
An atom consists of:

Nucleus: Contains protons (positive charge) and neutrons (neutral).
Electrons: Negatively charged particles orbiting the nucleus.

The number of protons defines the element, while electrons influence electrical behavior.
(Insert image: Diagram of an atom showing nucleus with protons and neutrons, surrounded by electron shells)
Electron Shells
Electrons occupy energy levels or shells. The valence shell (outermost shell) determines conductivity:

Full shells = stable, non-conductive (e.g., insulators).
Incomplete shells = conductive (e.g., metals like copper).

Electric Charge
Charge is a property of matter:

Positive: More protons than electrons.
Negative: More electrons than protons.
Interaction: Like charges repel; opposite charges attract.

Charge Transfer
Rubbing a balloon on hair transfers electrons, making the balloon negative and hair positive. This demonstrates static electricity.
(Insert image: Illustration of balloon sticking to hair due to static charge)
Conservation of Charge
Charge is neither created nor destroyed, only transferred.
Coulomb's Law
Coulomb's law quantifies the force between charges:
[ F = k \frac{q_1 q_2}{r^2} ]

( F ): Force (newtons).
( q_1, q_2 ): Charges (coulombs).
( r ): Distance (meters).
( k ): Coulomb’s constant (( 8.99 \times 10^9 , \text{N·m}^2/\text{C}^2 )).

This explains attraction and repulsion strength.

Electrical Units
Key concepts in electricity include voltage, current, and resistance.
Voltage
Voltage (or electromotive force, EMF) is the potential difference driving electron flow, measured in volts (V).
Analogy
Voltage is like water pressure in a pipe—higher pressure moves more water (electrons).
Current
Current is the rate of charge flow, measured in amperes (A) (1 A = 1 coulomb/second).
Direction
Conventionally, current flows from positive to negative, though electrons move oppositely.
Resistance
Resistance opposes current flow, measured in ohms (Ω). Conductors (low resistance) allow flow; insulators (high resistance) resist it.
Factors

Material: Copper conducts well; rubber resists.
Length: Longer wires increase resistance.
Area: Thicker wires reduce resistance.
Temperature: Resistance rises with heat in most conductors.


Producing Voltage
Voltage sources convert energy into electrical potential.
Batteries
Batteries use chemical reactions to produce voltage via an anode, cathode, and electrolyte.
(Insert image: Diagram of a battery cell with labeled parts)
Solar Cells
Solar cells convert sunlight into voltage through the photovoltaic effect.
(Insert image: Photo of a solar panel)
Generators
Generators use mechanical energy (e.g., turbine rotation) and electromagnetic induction to create voltage.
(Insert image: Diagram of a simple generator with coils and magnets)
Thermocouples
Thermocouples produce voltage from temperature differences between two metal junctions.
(Insert image: Illustration of a thermocouple setup)

Electrical Components
Components manage and protect circuits.
Wires
Wires (e.g., copper) conduct current and are insulated for safety.
Wire Gauge
Thicker wires (lower gauge numbers) carry more current with less resistance.
Fuses and Circuit Breakers

Fuses: Melt under excess current to break the circuit.
Circuit Breakers: Trip mechanically to interrupt flow.

(Insert image: Pictures of a fuse and a circuit breaker)
Ground
Grounding directs excess current safely to the earth, preventing shocks.
Types

Equipment Grounding: Protects metal casings.
System Grounding: Stabilizes voltage.


Measurement Devices
Meters measure electrical properties.
Using Meters
Multimeters
Multimeters measure voltage, current, and resistance.
(Insert image: Photo of a multimeter with probes)
Measuring Voltage
Connect in parallel to measure potential difference.
Measuring Current
Connect in series to measure flow.
Measuring Resistance
Test de-energized components directly.
(Insert images: Diagrams showing multimeter connections for voltage, current, and resistance)

Basic Circuit Concepts
Circuits apply electrical theory practically.
Ohm's Law
[ I = \frac{V}{R} ]

( I ): Current (A).
( V ): Voltage (V).
( R ): Resistance (Ω).

Example: A 12 V battery with a 4 Ω resistor yields 3 A.
Series and Parallel Circuits
Series
Components align end-to-end; total resistance sums up.
Parallel
Components share voltage; total resistance decreases.
(Insert images: Diagrams of series and parallel circuits)
Power
Power measures energy conversion rate:
[ P = V \cdot I ]

( P ): Power (watts).
Example: 12 V × 3 A = 36 W.


Safety Tips

De-energize circuits before work.
Use insulated tools and PPE (e.g., gloves).
Verify grounding to avoid shocks.


This document compiles the essentials of "Basic Electricity," enriched with analogies and context. To include images, search for:

"Atom structure diagram"
"Balloon hair static electricity"
"Battery cell diagram"
"Solar panel photo"
"Generator diagram"
"Thermocouple illustration"
"Fuse and circuit breaker pictures"
"Multimeter photo"
"Multimeter connection diagrams"
"Series and parallel circuit diagrams"




<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" class="logo" width="120"/>

# Basic Electricity for Electricians: A Comprehensive Educational Guide

This comprehensive guide covers the fundamental principles of electricity, from atomic structure to practical circuit analysis and measurement techniques. Based on the open educational resource "Basic Electricity for Electricians" from BCcampus, this document provides a thorough foundation for understanding electrical concepts, enhanced with additional context and visual aids to support AI-assisted learning.

## Atomic Structure and Electrical Fundamentals

### Understanding the Atom

Electricity is a phenomenon we encounter daily through home appliances, cellular phones, computers, and vehicles[^3]. To comprehend what electricity truly is, we must examine the fundamental building blocks of all matter: atoms[^4]. The **atom** represents the smallest particle of any matter, and everything around us consists of these microscopic components[^4]. Understanding atomic structure provides the foundation for grasping electrical concepts, as all electrical phenomena originate from the behavior of subatomic particles[^16][^17][^18].

Atoms consist of three main types of subatomic particles that determine their electrical properties[^4][^17][^19]. **Protons** are positively charged particles that reside in the atom's center, forming part of the **nucleus**[^4][^17]. These particles carry a positive charge of +1 and have a mass approximately equal to one atomic mass unit[^19][^20]. **Neutrons** are uncharged particles that also occupy the nucleus alongside protons[^4][^17]. Unlike protons and electrons, neutrons carry no electrical charge but contribute significantly to the atom's mass[^19][^20]. **Electrons** are negatively charged particles that orbit around the nucleus, similar to how planets orbit the sun in our solar system[^4][^17]. These particles possess a negative charge of -1, equal in magnitude but opposite to the proton's charge[^19][^20].

The arrangement of these particles creates an electrically neutral atom under normal conditions[^16][^19]. Atoms maintain electrical neutrality because they contain equal numbers of protons and electrons, causing the positive and negative charges to cancel each other out[^19][^20]. However, this balance can be disrupted through various processes, leading to the formation of ions—atoms with electrons added or removed[^16][^20]. The fundamental charge of an electron is $1.602 \times 10^{-19}$ coulombs, establishing the basic unit of electrical charge[^16].

### Electron Shells and Valence Properties

Electrons arrange themselves in specific energy levels or shells surrounding the nucleus[^4]. Each shell can accommodate a maximum number of electrons: the first shell holds 2 electrons, the second shell holds 8 electrons, the third shell holds 18 electrons, the fourth shell holds 32 electrons, and the fifth shell holds 50 electrons[^4]. While these specific numbers are important for understanding atomic structure, electricians primarily focus on the outermost shell, known as the **valence shell**[^4].

The valence shell determines a material's electrical properties and can contain a maximum of 8 valence electrons[^4]. The number of valence electrons categorizes materials into three fundamental types based on their electrical conductivity[^4][^21][^22]. **Conductors** possess 1-3 valence electrons, allowing electrons to move freely through the material under the influence of an electric field[^4][^21]. Common conductors include metals like copper and aluminum, which are extensively used in electrical wiring due to their low resistance to electron flow[^21][^22]. **Semiconductors** contain exactly 4 valence electrons, exhibiting electrical properties between conductors and insulators[^4][^21]. These materials, such as silicon and germanium, form the foundation of modern electronics and can be modified through doping to enhance their conductivity[^21][^22]. **Insulators** have 5-8 valence electrons, with their electrons tightly bound to atoms, preventing easy current flow[^4][^21]. Materials like rubber, glass, and ceramics serve as insulators in electrical systems, providing safety and preventing unwanted current paths[^21][^22].

### Electrical Charge and Charge Interaction

**Electrical charge** represents the electrical characteristic of matter caused by an excess or deficiency of electrons[^5]. When objects gain or lose electrons, they develop an electrical charge that creates forces between charged particles[^5][^23]. This fundamental concept explains many everyday electrical phenomena, from static electricity to the operation of electronic devices.

A practical demonstration of electrical charge involves rubbing a balloon against hair[^5]. During this process, electrons transfer from the hair to the balloon, creating an imbalance of charge[^5]. The hair, having lost electrons, becomes positively charged due to an excess of protons, while the balloon becomes negatively charged due to an excess of electrons[^5]. This charge separation creates an attractive force between the hair and balloon, demonstrating the fundamental principle that opposite charges attract[^5].

Three fundamental rules govern the behavior of electrical charges[^5][^23]. First, positive charges repel each other, creating a force that pushes like charges apart[^5][^23]. Second, negative charges also repel each other, following the same principle of like-charge repulsion[^5][^23]. Third, opposite charges attract each other, with positive charges drawn to negative charges and vice versa[^5][^23]. These principles form the foundation for understanding electrical phenomena, from the behavior of electrons in circuits to the operation of electrical devices.

### Coulomb's Law and Charge Quantification

Charles Augustin Coulomb established the mathematical relationship describing the force between charged particles[^6][^23]. **Coulomb's Law** states that a force exists between two point-source charges that is directly proportional to the product of the two charges and inversely proportional to the square of the distance between them[^6][^23]. This relationship can be expressed mathematically as:

$F = k\frac{|q_1 q_2|}{r^2}$

where $F$ represents the electrostatic force, $q_1$ and $q_2$ are the charges, $r$ is the distance between charges, and $k$ is Coulomb's constant (approximately $8.99 \times 10^9$ Nm²/C²)[^23].

A **coulomb** serves as the standard unit of electrical charge, symbolized by C[^6]. One coulomb equals the total charge carried by $6.25 \times 10^{18}$ electrons[^6]. This enormous number demonstrates the incredibly small charge carried by individual electrons. To calculate the charge in coulombs for a specific number of electrons, we use the formula:

$Q = \frac{\text{Number of electrons}}{6.25 \times 10^{18}}$

For example, $65.5 \times 10^{31}$ electrons would carry a charge of $104.8 \times 10^{12}$ coulombs[^6]. This quantification of charge provides the foundation for understanding current, which measures the flow of charge over time.

## Basic Electrical Units and Properties

### Voltage: The Driving Force of Electricity

**Voltage** represents the fundamental driving force in electrical systems, defined as the potential difference between two points in a conducting path[^8][^24][^25]. Voltage measures the electromotive force (EMF) or potential difference that creates the "pressure" necessary to move electrons through a circuit[^8][^25][^26]. This electrical pressure can be compared to water pressure in a hydraulic system—just as water pressure pushes water through pipes, voltage pushes electrons through conductors[^25][^27].

One volt represents the amount of potential necessary to cause one coulomb of charge to produce one joule of work[^8]. This relationship establishes voltage as a measure of energy per unit charge, quantifying the work required to move electrical charges between two points[^24][^26]. Voltage does not flow through circuits; instead, it provides the force that causes current to flow[^8][^25]. The presence of voltage is essential for current flow—without voltage, electrons move randomly within conductors and no useful current can be established[^8][^28].

The relationship between voltage and current demonstrates a fundamental electrical principle: current is directly proportional to voltage[^8]. When voltage increases in a circuit, current increases proportionally, assuming resistance remains constant[^8]. Conversely, when voltage decreases, current decreases accordingly[^8]. This proportional relationship forms part of Ohm's Law, one of the most important principles in electrical theory[^29].

![Common electrical circuit symbols including those for switches, lamps, fuses, diodes, meters, resistors, cells, and batteries.](https://pplx-res.cloudinary.com/image/upload/v1750069512/pplx_project_search_images/d94499139ff379c311172c3be22d5f9b79de289d.jpg)

Common electrical circuit symbols including those for switches, lamps, fuses, diodes, meters, resistors, cells, and batteries.

The symbols **E** or **V** represent voltage in electrical formulas and circuit diagrams[^8]. The letter E originates from "electromotive force," reflecting voltage's historical terminology, while V directly represents the unit of measurement[^8][^25]. In modern electrical practice, both symbols are commonly used, with V more prevalent in contemporary applications[^25][^30].

### Methods of Voltage Production

Electrical systems require sources of electromotive force to create the voltage necessary for current flow[^9]. Six primary methods exist for producing voltage, each converting different forms of energy into electrical energy[^9]. Understanding these methods provides insight into how various electrical devices and power generation systems operate.

**Friction EMF** operates on the triboelectric effect, where rubbing two dissimilar materials together causes electron transfer between them[^9]. This process creates a charge imbalance, with one material becoming negatively charged (electron surplus) and the other positively charged (electron deficiency)[^9]. The resulting electrostatic discharge can create dramatic effects, such as lightning, where charge buildup in clouds creates an electric field strong enough to ionize air and create a conducting path to earth[^9].

**Chemical EMF** forms the basis of battery operation through ionization processes[^9]. Batteries contain chemicals that create particles with positive and negative charges (ions)[^9]. Metal plates within the battery take on these charges, creating a potential difference between the battery terminals[^9]. This process enables portable electrical energy storage and provides power for countless electronic devices.

**Pressure EMF**, also known as piezoelectricity, generates voltage when mechanical stress is applied to certain materials[^9]. The word "piezoelectricity" literally means "electricity from pressure"[^9]. When pressure displaces positive and negative charges in otherwise neutral materials, a voltage is created[^9]. Common applications include electric cigarette lighters, where a spring-loaded hammer strikes a piezoelectric crystal to generate sufficient voltage for ignition[^9]. Microphones and guitar pickups also utilize this principle, converting sound waves or vibrations into electrical signals[^9].

**Heat EMF** utilizes the thermoelectric effect, where two dissimilar metals at different temperatures generate voltage[^9]. This occurs because electrons from the hot metal (negative side) tend to migrate toward the cold metal (positive side)[^9]. Thermocouples in furnaces exemplify this principle—when the pilot light heats the thermocouple, it generates voltage that enables a safety relay to control gas flow[^9]. If the pilot light extinguishes, no voltage is produced, and the safety system prevents gas flow[^9].

**Light EMF** employs the photovoltaic effect to convert light energy directly into electrical energy[^9]. Photovoltaic cells use semiconductor materials, typically silicon, which has four valence electrons[^9]. When light strikes these cells, the energy knocks electrons loose, allowing them to flow freely and create current[^9]. This technology has become increasingly important for renewable energy generation, as it produces electricity without requiring fossil fuels[^9].

**Magnetism EMF** represents the primary source of electrical energy in modern power systems[^9]. When magnetic field lines are cut by a conductor, an EMF is generated[^9]. This principle powers steam turbines, hydroelectric dams, wind generators, and other large-scale electrical generation systems[^9]. The mechanical energy that moves conductors through magnetic fields gets converted into electrical energy that powers our electrical infrastructure.

All six voltage production methods achieve the same fundamental goals: they impart energy to electrons, push electrons against electrostatic fields, and create electron surplus at one terminal while creating electron deficiency at another terminal[^9]. This charge separation stores energy that can later be used to perform useful work in electrical circuits[^9].

### Current: The Flow of Electrical Charge

**Current** represents the rate of charge flow in electrical systems, measuring how much electrical charge passes a specific point over a given time period[^10][^28][^31]. In mathematical terms, current equals charge divided by time: $I = Q/t$[^10]. This fundamental relationship establishes current as a measure of electron movement through conductors[^28][^31].

Under normal conditions, free electrons in conductors move randomly without creating useful current[^10]. However, when voltage is applied to a material, electrons begin moving in a directed manner from negative toward positive potential[^10][^28]. Since electrons carry negative charge, they are repelled by the negative terminal of a voltage source and attracted to the positive terminal[^10][^28]. This directed electron movement constitutes electrical current[^10][^28].

An **ampere** (commonly called an amp) serves as the standard unit for measuring current[^10][^28][^31]. One ampere represents the flow of one coulomb of charge past a point in one second[^28][^31]. To put this in perspective, one ampere means that $6.24 \times 10^{18}$ electrons (6.24 billion billion electrons) flow past a single point in a circuit every second[^28][^31]. This enormous number illustrates the incredible quantity of electrons involved in even modest electrical currents.

Current measurement uses various submultiples for different applications[^28][^31]. **Milliamperes (mA)** represent thousandths of an ampere (0.001 A) and are commonly used for measuring current in electronic circuits[^28][^31]. **Microamperes (µA)** represent millionths of an ampere (0.000001 A) and are used for very small currents in sensitive electronic applications[^28][^31]. In electrical formulas such as Ohm's Law, current is represented by the symbol **I**, which stands for "intensity"[^28][^31].

The unit "ampere" honors French mathematician and physicist André-Marie Ampère (1775-1836), who made fundamental discoveries about the relationship between electricity and magnetism[^28][^31]. Ampère proved that current flowing through a conductor generates a magnetic field around it, and that the strength of this magnetic field is directly proportional to the amount of current flowing[^28][^31]. These discoveries laid the groundwork for understanding electromagnetic phenomena and enabled the development of electric motors, generators, and transformers.

### Resistance: Opposition to Current Flow

**Resistance** represents the opposition to electron flow in electrical circuits[^11][^30][^29]. Just as rocks and debris in a river reduce water flow speed and energy, resistance in electrical circuits impedes current flow and dissipates electrical energy[^11]. This fundamental property affects how electrical circuits operate and determines how much current flows for a given voltage[^11][^30].

The relationship between resistance and current demonstrates an inverse proportionality: as resistance increases in a circuit, current decreases proportionally[^11]. Conversely, when resistance decreases, current increases[^11]. This relationship, combined with voltage and current relationships, forms the foundation of Ohm's Law, which states that voltage equals current multiplied by resistance ($V = I \times R$)[^29].

Resistance is designated by the symbol **R** and measured in **ohms**, represented by the Greek letter omega (Ω)[^11][^29]. One ohm of resistance allows one ampere of current to flow when one volt is applied across it[^29]. This relationship provides a practical way to understand the interaction between voltage, current, and resistance in electrical circuits[^29].

The resistance of materials depends on several factors, including the material's atomic structure, temperature, and physical dimensions[^21][^22]. Conductors have low resistance because their valence electrons are loosely bound and can move freely[^21]. Insulators have high resistance because their valence electrons are tightly bound to atoms, preventing easy electron movement[^21]. Semiconductors exhibit intermediate resistance that can be modified through temperature changes or the addition of impurities[^21][^22].

**Resistors** are devices specifically designed to introduce controlled amounts of resistance into circuits[^11]. They serve multiple purposes: limiting current flow, dividing voltage, and generating heat for specific applications[^11]. Resistors are categorized into two main types: fixed resistors and variable resistors[^11].

**Fixed resistors** have predetermined resistance values that cannot be changed during normal operation[^11]. They are available in a wide range of resistance values and are manufactured using various technologies, including carbon-composite, metal film, and chip array configurations[^11]. The most commonly used type is the carbon-composite resistor, which uses color-coded bands to indicate its resistance value and tolerance[^11].

The color coding system for resistors provides a standardized method for identifying resistance values[^11]. Four-band resistors use the first two bands to represent digits, the third band as a multiplier (number of zeros), and the fourth band to indicate tolerance[^11]. Five-band resistors use the first three bands for digits, the fourth band as a multiplier, and the fifth band for tolerance[^11]. For example, a four-band resistor with red, green, brown, and gold bands would have a resistance of 250 ohms with ±5% tolerance[^11].

**Variable resistors** allow resistance values to be adjusted during operation[^11]. They serve two primary functions: as **potentiometers** for voltage division and as **rheostats** for current control[^11]. A potentiometer has three terminals and uses a moving contact (wiper) to tap different voltages from a fixed resistance element[^11]. Potentiometers are commonly used in volume controls, speed controls for DC motors, and various adjustment circuits[^11]. Rheostats are similar but are typically designed for higher current applications and focus on controlling current rather than voltage[^11].

![Digital multimeter with test leads and a 9-volt battery, commonly used for various electrical measurements.](https://pplx-res.cloudinary.com/image/upload/v1749379858/pplx_project_search_images/1a915b1cb172af2d12ae88e4e2fbe4bee4b6c64d.jpg)

Digital multimeter with test leads and a 9-volt battery, commonly used for various electrical measurements.

## Circuit Components and Analysis

### Basic Circuit Components

Electrical circuits require specific components to enable controlled electron flow and useful work[^12]. The term "circuit" means circular journey or loop, describing the path electrons travel through electrical systems[^12]. Understanding the essential components of electrical circuits provides the foundation for analyzing and designing electrical systems.

A **source** provides the electromotive force that drives electrons through the circuit[^12]. Sources convert other forms of energy into electrical energy, creating the electrical pressure necessary for current flow[^12]. Common examples include batteries, solar cells, generators, and thermocouples[^12]. Each type of source operates on different principles but serves the same fundamental purpose of providing voltage to drive current through the circuit[^12].

**Switches** control the opening and closing of electrical circuits[^12]. A **closed circuit** provides a complete path for current flow, enabling electrons to travel from the source through the circuit components and back to the source[^12]. An **open circuit** contains a break in the current path, preventing electron flow and stopping circuit operation[^12]. Switches provide manual or automatic control over circuit operation, allowing users to turn electrical devices on and off as needed[^12].

**Fuses and circuit breakers** provide essential protection in electrical circuits[^12]. These devices are designed to open automatically when current exceeds safe levels, protecting circuit components and preventing dangerous conditions[^12]. Fuses contain a metal element that melts when excessive current flows, creating an open circuit that stops current flow[^12]. Once a fuse operates, it must be replaced before the circuit can function again[^12]. Circuit breakers use mechanical or electromagnetic mechanisms to open when excessive current is detected[^12]. Unlike fuses, circuit breakers can be reset and reused after they operate[^12].

A **load** converts electrical energy into other useful forms of energy[^12]. Loads represent the components that perform the actual work in electrical circuits, such as lights that convert electricity to illumination, heaters that convert electricity to thermal energy, and motors that convert electricity to mechanical energy[^12]. The load creates the useful output that justifies the existence of the electrical circuit[^12].

**Conductors** complete the path for electron flow between circuit components[^12]. Conductors can take various forms, including wire, busbar, copper strips, and aluminum conductors[^12]. The choice of conductor depends on factors such as current capacity, installation environment, and cost considerations[^12]. Proper conductor selection ensures safe and efficient current flow throughout the circuit[^12].

![Common electrical circuit symbols for components such as batteries, resistors, capacitors, and switches.](https://pplx-res.cloudinary.com/image/upload/v1748697892/pplx_project_search_images/c7e4b8b2345bdc93431565d2b09ea85f13e69fcf.jpg)

Common electrical circuit symbols for components such as batteries, resistors, capacitors, and switches.

### Polarity and Current Direction

Understanding **polarity** is crucial for proper circuit analysis and component connection[^12]. Polarity refers to the electrical charge at one point with respect to another point in the circuit[^12]. In electrical circuits, we identify the polarity of different points to ensure proper meter connections and correct operation of polarity-sensitive devices[^12].

Current flow direction depends on the type of circuit component[^12]. In loads, current flows from negative to positive, following the conventional direction of electron movement[^12]. However, in sources, current flows from positive to negative as the source provides energy to drive electrons through the external circuit[^12]. This apparent contradiction resolves when we consider that sources and loads have opposite functions—sources provide energy while loads consume energy[^12].

**Direct current (DC)** maintains constant polarity over time[^12]. In DC circuits, electrons flow in only one direction, and the voltage polarity remains fixed[^12]. Examples of DC sources include batteries, thermocouples, DC generators, and solar cells[^12]. DC circuits are commonly used in electronic devices, automotive systems, and applications requiring stable voltage levels[^12].

**Alternating current (AC)** changes direction continuously at regular intervals[^12]. AC current reverses its direction periodically, with the voltage polarity alternating between positive and negative[^12]. The AC power used in homes operates at 60 cycles per second (60 Hz), meaning the voltage changes polarity 120 times per second, producing 60 complete cycles[^12]. This alternating characteristic makes AC ideal for power transmission over long distances and enables the use of transformers for voltage level changes[^12].

### Series Circuit Analysis

Series circuits represent one of the two fundamental circuit configurations[^13]. In series circuits, components are connected end-to-end in a single path, creating only one route for current flow[^13]. Understanding series circuit behavior is essential for electrical analysis and troubleshooting[^13].

Three fundamental laws govern series circuit behavior[^13]. **Series resistance law** states that the total resistance equals the sum of all individual resistances: $R_T = R_1 + R_2 + R_3...$[^13]. This occurs because each resistor presents additional opposition to current flow, and since current must pass through each resistor sequentially, their resistances add together[^13]. For example, three resistors with values of 15Ω, 5Ω, and 20Ω connected in series would have a total resistance of 40Ω[^13].

**Series current law** establishes that current remains constant throughout a series circuit[^13]. Since only one path exists for electron flow, the same current that leaves the voltage source must pass through each component in the circuit[^13]. Mathematically, this is expressed as: $I_T = I_1 = I_2 = I_3...$[^13]. Using Ohm's Law with a 120V source and 40Ω total resistance yields a current of 3A throughout the entire circuit[^13].

**Series voltage law** explains how voltage divides among series components[^13]. The total source voltage equals the sum of all individual voltage drops across circuit components: $E_T = E_1 + E_2 + E_3...$[^13]. Each resistor develops a voltage drop proportional to its resistance value[^13]. In our example, the 15Ω resistor drops 45V (3A × 15Ω), the 5Ω resistor drops 15V (3A × 5Ω), and the 20Ω resistor drops 60V (3A × 20Ω)[^13]. The sum of these voltage drops (45V + 15V + 60V = 120V) equals the source voltage[^13].

Series circuits exhibit specific characteristics that affect their practical applications[^13]. If any component fails or an open circuit occurs anywhere in the series path, current flow stops throughout the entire circuit[^13]. This makes series circuits less reliable for applications where continuous operation is critical[^13]. However, series circuits are useful for applications like holiday lights, where the failure of one component can serve as a safety feature by shutting down the entire string[^13].

**Line drop** and **line loss** represent important practical considerations in series circuits[^13]. Line drop refers to the voltage lost across conductor resistance, expressed in volts[^13]. As current flows through conductors with resistance, small voltage drops occur that reduce the voltage available to the load[^13]. Line loss represents the power dissipated in conductors due to their resistance, expressed in watts[^13]. This power loss converts electrical energy to heat and represents inefficiency in the electrical system[^13]. Using larger conductors with lower resistance can minimize both line drop and line loss[^13].

### Parallel Circuit Analysis

Parallel circuits represent the second fundamental circuit configuration and are the most common type encountered in electrical systems[^14]. In parallel circuits, components are connected so that each component has the same voltage across it, creating multiple paths for current flow[^14]. Understanding parallel circuit behavior is crucial for analyzing power distribution systems and residential wiring[^14].

![Comparison of series and parallel electrical circuits, highlighting their key characteristics and common applications.](https://pplx-res.cloudinary.com/image/upload/v1748697892/pplx_project_search_images/96a2bec5c4d3085ba3616b40fad1ae265b04f973.jpg)

Comparison of series and parallel electrical circuits, highlighting their key characteristics and common applications.

Three fundamental laws govern parallel circuit behavior[^14]. **Parallel voltage law** states that voltage across each branch equals the source voltage[^14]. Since each component connects directly across the voltage source, all components experience the same potential difference[^14]. This relationship is expressed as: $E_T = E_1 = E_2 = E_3...$[^14]. In a 120V parallel circuit, each branch would have 120V across it regardless of the number of branches[^14].

**Parallel current law** establishes that total current equals the sum of all branch currents[^14]. Since multiple paths exist for current flow, the source must provide current equal to the sum of currents through all branches[^14]. This relationship is expressed as: $I_T = I_1 + I_2 + I_3...$[^14]. For example, if three branches draw 6A, 3A, and 2A respectively, the total current would be 11A[^14].

**Parallel resistance law** demonstrates that total resistance is always less than the smallest individual resistance[^14]. The reciprocal formula calculates total resistance: $1/R_T = 1/R_1 + 1/R_2 + 1/R_3...$[^14]. This occurs because adding parallel paths provides additional routes for current flow, effectively reducing the overall opposition to current[^14]. Modern calculators with inverse functions simplify these calculations significantly[^14].

Parallel circuits offer significant advantages over series circuits[^14]. If one branch fails or opens, current continues to flow through the remaining branches[^14]. This makes parallel circuits more reliable for applications requiring continuous operation[^14]. Additionally, each branch can be controlled independently, allowing individual components to be switched on or off without affecting other branches[^14]. These characteristics make parallel circuits ideal for residential and commercial wiring systems[^14].

## Measurement Techniques and Practical Applications

### Electrical Meters and Safety Precautions

Electrical measurements require precision instruments capable of safely and accurately quantifying electrical parameters[^15]. Since electricity cannot be seen directly, we can only observe its effects through appropriate measuring instruments[^15]. Meters serve as the primary tools for diagnosing electrical problems, verifying circuit operation, and ensuring system safety[^15].

Proper meter handling requires careful attention to environmental and operational factors[^15]. Shock and vibration can damage sensitive meter components and affect measurement accuracy[^15]. Temperature, humidity, and dust levels must be considered when using meters, as extreme conditions can compromise their performance[^15]. Magnetic fields from nearby electrical equipment can cause inaccurate readings, so meters should be positioned away from strong magnetic sources[^15].

![A digital multimeter with its test leads and a 9V battery, essential tools for electrical measurements.](https://pplx-res.cloudinary.com/image/upload/v1750874026/pplx_project_search_images/9b2c4a7635faedec47fef13b2aa61f389d8a1002.jpg)

A digital multimeter with its test leads and a 9V battery, essential tools for electrical measurements.

Several critical safety precautions must be observed when using electrical meters[^15]. Never use an ohmmeter on live circuits, as ohmmeters contain their own power source and energizing them from external sources can damage the meter or create safety hazards[^15]. Always match the meter type to the electrical system being measured—use DC meters for DC systems and AC meters for AC systems[^15]. When working with DC meters, observe proper polarity connections to prevent damage and ensure accurate readings[^15]. Verify that meters are properly oriented for reading, as some are designed to be read in specific positions[^15]. Read meters while looking straight at them to avoid parallax errors that can cause measurement inaccuracies[^15]. Turn meters off when measurements are complete to preserve battery life and prevent accidental damage[^15].

### Specific Meter Types and Applications

**Voltmeters** measure potential difference between two points in electrical circuits[^15]. These instruments are essentially high-resistance devices that draw minimal current from the circuit being measured[^15]. Voltmeters must be connected in parallel with the component or circuit section being measured[^15]. Before using a voltmeter, test it on a known voltage source to verify proper operation[^15]. This verification step helps identify meter problems before attempting critical measurements[^15].

**Ammeters** measure current flow through electrical circuits[^15]. These instruments are designed with very low internal resistance to avoid adding unwanted opposition to current flow[^15]. Ammeters must be connected in series with the circuit being measured, requiring the circuit to be opened to insert the meter[^15]. Never connect an ammeter in parallel, as this would create a short circuit that could damage the meter and create dangerous conditions[^15]. The low resistance of ammeters makes them vulnerable to damage from excessive current, so proper fuse protection is essential[^15].

**Wattmeters** measure electrical power by simultaneously monitoring both voltage and current[^15]. These instruments have four test leads: two for current measurement and two for voltage measurement[^15]. Power equals the product of voltage and current, so wattmeters measure both parameters and multiply them internally to display power[^15]. Connect the voltage coil in parallel with the load and the current coil in series with the load[^15]. Never exceed the power rating of the wattmeter, as this can damage the instrument[^15].

**Ohmmeters** measure resistance and require special handling procedures[^15]. These instruments contain their own EMF source (battery) and must never be used on live circuits[^15]. The ohmmeter scale typically reads backwards compared to other meters, with zero resistance on the right and infinite resistance on the left[^15]. Many ohmmeters include a zero adjustment feature that should be used before each measurement session[^15]. Zero the meter by shorting the test leads together and adjusting the zero control until the meter reads zero ohms[^15].

Understanding meter ratings and limitations is crucial for safe operation[^15]. Different meters are designed for different voltage and current ranges, and exceeding these ratings can damage the instrument or create safety hazards[^15]. High-quality meters designed for professional electrical work often include additional safety features and higher voltage ratings compared to basic multimeters[^15]. When working in industrial or commercial environments, ensure that meters meet appropriate safety standards for the voltage levels and working conditions encountered[^15].

## Advanced Circuit Concepts and Applications

### Power and Energy Relationships

Electrical power represents the rate at which electrical energy is converted to other forms of energy[^29]. Understanding power relationships is essential for designing efficient electrical systems and ensuring safe operation within component ratings. Power is measured in watts (W) and can be calculated using several related formulas that derive from the fundamental relationships between voltage, current, and resistance.

The basic power formula states that power equals voltage multiplied by current: $P = V \times I$[^29]. This relationship shows that power increases when either voltage or current increases. By substituting Ohm's Law relationships, we can derive additional power formulas: $P = I^2 \times R$ and $P = V^2/R$[^29]. These alternative formulas allow power calculations when different electrical parameters are known.

Power calculations have practical implications for electrical system design and operation. When current flows through resistance, electrical energy converts to heat energy, representing power loss in the system[^13]. This power loss, calculated as $P = I^2 \times R$, explains why electrical systems use higher voltages for power transmission—higher voltage allows the same power to be transmitted with lower current, reducing $I^2R$ losses[^13].

### Electrical Safety Principles

Electrical safety encompasses understanding the hazards associated with electrical energy and implementing appropriate protective measures. Electrical shock occurs when current passes through the human body, and the severity depends on current magnitude, duration, and path through the body. Even relatively small currents can be dangerous, making electrical safety a critical concern in all electrical work.

Ground fault protection systems detect imbalances between hot and neutral conductors, indicating current leakage that could represent a shock hazard. Circuit breakers and fuses provide overcurrent protection, preventing dangerous current levels that could cause fires or equipment damage. Proper grounding ensures that electrical equipment maintains a safe reference potential and provides a path for fault currents to flow safely.

Personal protective equipment (PPE) plays a crucial role in electrical safety. Insulated tools prevent accidental contact with energized conductors. Safety glasses protect eyes from arc flash hazards. Appropriate clothing materials prevent static electricity buildup and provide protection from electrical burns. Understanding and following lockout/tagout procedures ensures that electrical equipment is properly de-energized before maintenance work begins.

### Future Developments in Electrical Technology

Modern electrical systems continue to evolve with advancing technology. Smart grid systems integrate digital communication and control capabilities with traditional electrical distribution networks, enabling more efficient and reliable power delivery. Renewable energy sources, including solar panels and wind generators, are becoming increasingly important components of electrical systems.

Energy storage technologies, particularly battery systems, are advancing rapidly and enabling new applications for electrical energy. Electric vehicles represent a growing load on electrical systems while also providing potential energy storage resources. Power electronics devices continue to improve efficiency and enable better control of electrical energy conversion and utilization.

Understanding fundamental electrical principles provides the foundation for adapting to these technological advances. While the specific technologies may change, the basic relationships between voltage, current, resistance, and power remain constant. Students who master these fundamentals will be well-prepared to work with both current and future electrical technologies.

## Conclusion

This comprehensive guide has explored the fundamental principles of electricity from atomic structure through practical circuit analysis and measurement techniques. Understanding begins with atomic structure and the behavior of electrons, protons, and neutrons that create electrical charge and enable current flow[^4][^5]. The three basic electrical parameters—voltage, current, and resistance—form the foundation for all electrical analysis and applications[^8][^10][^11].

Voltage provides the driving force that pushes electrons through circuits, with various methods available for generating electrical pressure including friction, chemical reactions, pressure, heat, light, and magnetism[^8][^9]. Current represents the actual flow of electrical charge, measured in amperes and governed by the applied voltage and circuit resistance[^10]. Resistance opposes current flow and can be controlled through the selection of appropriate materials and component values[^11].

Circuit analysis requires understanding both series and parallel configurations, each with distinct characteristics and applications[^13][^14]. Series circuits provide a single path for current flow with voltage dividing among components, while parallel circuits offer multiple current paths with constant voltage across each branch[^13][^14]. These fundamental configurations form the building blocks for more complex electrical systems.

Practical electrical work depends on accurate measurement techniques using appropriate instruments[^15]. Voltmeters, ammeters, wattmeters, and ohmmeters each serve specific purposes and require proper connection methods and safety precautions[^15]. Understanding meter limitations and proper usage ensures accurate measurements and safe working conditions[^15].

The principles covered in this guide provide a solid foundation for further electrical study and practical application. Whether pursuing advanced electrical engineering topics or applying these concepts in trade applications, mastery of these fundamentals enables successful work with electrical systems. As electrical technology continues to advance with smart grids, renewable energy, and electric vehicles, these basic principles remain essential for understanding and working with both current and future electrical systems.

The knowledge presented here serves as a stepping stone to more advanced topics while providing practical skills immediately applicable to real-world electrical work. Students who thoroughly understand these concepts will be well-prepared for the challenges and opportunities in the evolving field of electrical technology.

