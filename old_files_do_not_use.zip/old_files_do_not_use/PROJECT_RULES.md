# Basic Electricity Tutor - Project Rules

## Project Overview
This project creates an interactive educational web application for teaching electricity concepts with a split-screen design: educational content on the left and an AI chatbot assistant on the right.

## Technology Decisions

### Framework & Languages
- **Next.js**: Required for this project
- **TypeScript**: Required for all code files
- **React**: Use functional components with hooks

### Code Standards
- Use ESLint with the project's configuration
- Follow Prettier formatting rules
- Maximum line length: 100 characters
- Use 2-space indentation

### File Structure
- Place components in `src/components/`
- Group components by feature or purpose
- Place utilities in `src/lib/`
- Store types in `src/types/`
- Keep visualization components in `src/components/visualizations/`
- AI integration code belongs in `src/lib/ai/`

### Component Guidelines
- Create single-responsibility components
- Use named exports for all components
- Extract reusable logic into custom hooks
- Document complex components with JSDoc

### Naming Conventions
- React Components: PascalCase
- Files containing React components: PascalCase
- Other files: camelCase
- CSS modules: camelCase.module.css
- Interfaces: Prefix with "I" (e.g., IUserData)
- Types: PascalCase without prefix

### State Management
- Use React Context for global state
- Prefer useState and useReducer for component state
- Avoid prop drilling more than 2 levels deep

### Styling
- Use Tailwind CSS for styling
- Create reusable design tokens
- Use CSS variables for theming
- Ensure responsive design for various screen sizes

### Accessibility & Design Requirements
- **Default Font**: LEXEND for improved reading proficiency
- **Font Options**: Include OpenDyslexic and Dyslexie for dyslexia support
- **Font Size Controls**: 14px, 16px (default), 18px, 20px options
- **Color Contrast**: Minimum 4.5:1 ratio, high contrast mode available
- **Keyboard Navigation**: All functionality must be keyboard accessible
- **Screen Reader Support**: Proper ARIA labels and semantic HTML
- **Progress Tracking**: Visual indicators for section completion and overall progress
- **Focus Management**: Visible focus indicators and logical tab order
- **Reduced Motion**: Respect prefers-reduced-motion media query
- **Touch Targets**: Minimum 44x44px for mobile accessibility

### AI Integration
- Handle API failures gracefully
- Implement proper rate limiting
- Keep context window manageable
- Log failed AI responses for improvement

### Visualization Best Practices
- Ensure all visualizations are accessible
- Provide text alternatives for complex visuals
- Keep animations performant (use requestAnimationFrame)
- Support touch interactions for all interactive elements

### Testing
- Write unit tests for all utility functions
- Create component tests for interactive elements
- Test AI interactions with mock responses
- Maintain >80% test coverage

### Documentation
- Document all non-obvious code
- Include examples for complex functions
- Maintain up-to-date README
- Document component props with PropTypes or TypeScript

## Performance Requirements
- Achieve Lighthouse score >90 for Performance
- First Contentful Paint < 1.5s
- Time to Interactive < 3s
- Bundle size < 500KB (main bundle)
- Lazy load all visualization libraries
- Implement proper code splitting

## Accessibility Requirements
- Meet WCAG 2.1 AA standards
- Ensure keyboard navigability
- Maintain proper heading hierarchy
- Use semantic HTML elements
- Provide appropriate ARIA attributes
- Ensure sufficient color contrast (4.5:1 minimum)

## Committed Libraries
- Next.js
- React
- TypeScript
- Tailwind CSS
- D3.js
- Three.js
- react-markdown
- AI tutor system prompt in `system_prompt_electricity_tutor.md`
